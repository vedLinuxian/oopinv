<?php
/**
 * =====================================================================================
 * User Management Page
 * =====================================================================================
 *
 * This page provides an interface for administrators to manage user accounts.
 * - Requires 'Admin' role or 'manage_users' permission.
 * - Allows creating new users, editing existing user details (username, role),
 *   and deleting users.
 *
 */

// Step 1: Bootstrap and Authenticate
require_once __DIR__ . '/config/config.php';
$db = Database::getInstance();
$auth = new Auth($db);
$auth->requireLogin();
$currentUser = $auth->getUser();

// Step 2: Authorization (RBAC)
// Check if the current user has permission to manage users.
// We are hard-coding the check for the 'Admin' role for now.
if (strtolower($currentUser->getRole()->name) !== 'admin') {
    // If not, set a flash message and redirect to the dashboard.
    set_flash_message('error', 'You do not have permission to access the User Management page.');
    header('Location: ' . BASE_URL . 'index.php');
    exit();
}

// Step 3: Fetch Data for the View
$pageTitle = 'User Management';

// Get all users and all available roles for the forms
$allUsers = User::findAll($db);
$allRoles = Role::findAll($db);

$company = new Company($db);
$company->loadByUser($currentUser->id);

// Step 4: Include Header
require_once __DIR__ . '/partials/header.php';
?>

<!-- Main Content Wrapper -->
<div class="content-wrapper">

    <!-- Sidebar Partial -->
    <?php require_once __DIR__ . '/partials/sidebar.php'; ?>

    <!-- Main Content Area -->
    <div class="main-content">
        <div class="card">
            <div class="card-body">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-lg font-semibold">System Users</h2>
                    <button type="button" class="btn btn-primary btn-sm" onclick="openUserModal()">
                        <i class="fas fa-user-plus btn-icon"></i> Add New User
                    </button>
                </div>

                <!-- User List Table -->
                <div class="table-responsive">
                    <table id="users-table">
                        <thead>
                            <tr>
                                <th>Username</th>
                                <th>Role</th>
                                <th>Date Created</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="users-table-body">
                            <?php if (!empty($allUsers)): ?>
                                <?php foreach ($allUsers as $user): ?>
                                    <tr>
                                        <td class="font-semibold"><?php echo h($user->username); ?></td>
                                        <td><?php echo h($user->getRole()->name ?? 'N/A'); ?></td>
                                        <td><?php echo format_date($user->created_at); ?></td>
                                        <td class="text-center">
                                            <div class="btn-group">
                                                <button class="btn btn-outline btn-sm" title="Edit User" onclick='openUserModal(<?php echo json_encode(["id" => $user->id, "username" => $user->username, "role_id" => $user->role_id], JSON_HEX_APOS); ?>)'>
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <!-- Prevent the admin from deleting themselves -->
                                                <?php if ($currentUser->id !== $user->id): ?>
                                                <button class="btn btn-danger btn-sm" title="Delete User" onclick="deleteUser(<?php echo $user->id; ?>, this)">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" class="empty-table">No users found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

            </div> <!-- /.card-body -->
        </div> <!-- /.card -->
    </div> <!-- /.main-content -->
</div> <!-- /.content-wrapper -->

<!-- User Add/Edit Modal (Should be moved to modals.php later) -->
<div id="user-modal" class="modal">
    <div class="modal-content" style="max-width: 500px;">
        <form id="user-form" onsubmit="event.preventDefault(); saveUser(this);">
            <div class="modal-header">
                <h2 class="modal-title" id="user-modal-title">Add New User</h2>
                <button type="button" class="modal-close" onclick="closeUserModal()">&times;</button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="user_form_id" name="id" value="">
                
                <div class="form-group">
                    <label for="user_username">Username <span class="text-danger">*</span></label>
                    <input type="text" id="user_username" name="username" required>
                </div>
                
                <div class="form-group">
                    <label for="user_password">Password</label>
                    <input type="password" id="user_password" name="password" autocomplete="new-password">
                    <small class="text-muted text-xs">Leave blank to keep the current password when editing.</small>
                </div>
                
                <div class="form-group">
                    <label for="user_role_id">Role <span class="text-danger">*</span></label>
                    <select id="user_role_id" name="role_id" required>
                        <option value="">-- Select a Role --</option>
                        <?php foreach ($allRoles as $role): ?>
                        <option value="<?php echo $role->id; ?>"><?php echo h($role->name); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeUserModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Save User</button>
            </div>
        </form>
    </div>
</div>

<?php
// Include main modals and footer
require_once __DIR__ . '/partials/modals.php';
require_once __DIR__ . '/partials/footer.php';
?>