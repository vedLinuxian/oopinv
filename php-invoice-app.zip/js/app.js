/**
 * =====================================================================================
 * Main Application JavaScript File
 * =====================================================================================
 *
 * This file contains all primary client-side logic for the invoice generator.
 */

(function() {
    'use strict';

    // --- 1. Global State & Timers ---
    let clientSearchTimeout, productSearchTimeout;

    // --- 2. Utility Functions ---
    const showToast = (title, message, type = 'info') => {
        const toastContainer = document.getElementById('toast-container');
        if (!toastContainer) { console.error("Toast container missing!"); return; }
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        const iconMap = { success: '✓', error: '✗', warning: '⚠️', info: 'ℹ️' };
        toast.innerHTML = `<div class="toast-header"><strong class="toast-title">${iconMap[type] || 'ℹ️'} ${escapeHtml(title)}</strong><button type="button" class="toast-close" onclick="this.closest('.toast').remove()">&times;</button></div><div class="toast-body">${escapeHtml(message)}</div>`;
        toastContainer.appendChild(toast);
    };
    const escapeHtml = unsafe => (typeof unsafe !== 'string') ? unsafe ?? '' : unsafe.replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'})[m]);
    const openModal = el => el && (el.style.display = 'block');
    const closeModal = el => el && (el.style.display = 'none');

    // --- 3. Global Modal Management ---
    window.closeClientModal = () => closeModal(document.getElementById('client-modal'));
    window.closeCompanyModal = () => closeModal(document.getElementById('company-modal'));
    window.closeProductModal = () => closeModal(document.getElementById('product-modal'));
    window.closeTaxRateModal = () => closeModal(document.getElementById('tax-rate-modal'));
    window.closeBankModal = () => closeModal(document.getElementById('bank-modal'));
    window.closeUserModal = () => closeModal(document.getElementById('user-modal'));
    window.closePreviewModal = () => closeModal(document.getElementById('preview-modal'));
    
    // --- 4. API Wrapper ---
    window.api = {
        async _request(action, params = {}) {
            const isGet = !params.method || params.method.toUpperCase() === 'GET';
            let url = `${AppConfig.BASE_URL}api.php?action=${action}`;
            if (isGet && Object.keys(params).length) url += `&${new URLSearchParams(params)}`;
            try {
                const options = isGet ? {} : { 
                    method: 'POST', 
                    body: params.body instanceof FormData ? params.body : JSON.stringify(params.body), 
                    headers: params.body instanceof FormData ? {} : {'Content-Type': 'application/json'}
                };
                const response = await fetch(url, options);
                const data = await response.json();
                if (!response.ok) throw new Error(data.message || `HTTP Error ${response.status}`);
                return data;
            } catch (error) { showToast('API Error', error.message, 'error'); throw error; }
        },
        getClients: (p=1, s='') => api._request('get_clients', { search: s }),
        getClient: id => api._request('get_client', { id }),
        saveClient: fd => api._request('save_client', { method: 'POST', body: fd }),
        deleteClient: id => api._request('delete_client', { id }),
        getCompany: () => api._request('get_company'),
        saveCompany: fd => api._request('save_company', { method: 'POST', body: fd }),
        getProducts: (p=1, s='') => api._request('get_products', { page: p, limit: 10, search: s }),
        getProduct: id => api._request('get_product', { id }),
        saveProduct: fd => api._request('save_product', { method: 'POST', body: fd }),
        deleteProduct: id => api._request('delete_product', { method: 'POST', body: { id } }),
        getTaxRates: () => api._request('get_tax_rates'),
        saveTaxRate: fd => api._request('save_tax_rate', { method: 'POST', body: fd }),
        deleteTaxRate: id => api._request('delete_tax_rate', { method: 'POST', body: { id } }),
        getBanks: () => api._request('get_banks'),
        saveBank: fd => api._request('save_bank', { method: 'POST', body: fd }),
        deleteBank: id => api._request('delete_bank', { method: 'POST', body: { id } }),
        getUsers: () => api._request('get_users'),
        getRoles: () => api._request('get_roles'),
        saveUser: fd => api._request('save_user', { method: 'POST', body: fd }),
        deleteUser: id => api._request('delete_user', { method: 'POST', body: { id } }),
        getEstimates: (p = 1) => api._request('get_estimates', { page: p }),
        getEstimate: id => api._request('get_estimate', { id }),
        saveEstimate: data => api._request('save_estimate', { body: data }),
        deleteEstimate: id => api._request('delete_estimate', { body: { id } }),
        updateEstimateStatus: (id, status) => api._request('update_estimate_status', { method: 'POST', body: { id, status } }),
        convertToInvoice: id => api._request('convert_to_invoice', { method: 'POST', body: { id } }),
        saveInvoice: data => api._request('save_invoice', { body: data }),
    };

    // --- 5. Entity Management & Modal Openers ---
    const setupModal = (config) => {
        window[config.openFnName] = async (idOrData = null) => {
            const modal = document.getElementById(config.modalId);
            if (!modal) return;
            const form = modal.querySelector('form'); form.reset();
            modal.querySelector('.modal-title').textContent = (idOrData ? 'Edit' : 'Add New') + ` ${config.entityName}`;
            form.id.value = '';

            let dataToFill = {};
            if (typeof idOrData === 'object' && idOrData) { dataToFill = idOrData; }
            else if (idOrData && api[`get${config.entityName}`]) { try { dataToFill = (await api[`get${config.entityName}`](idOrData))[config.entityName.toLowerCase()] || {}; } catch (e) {} }
            
            Object.keys(dataToFill).forEach(key => { if(form[key]) { form[key][key === 'is_default' ? 'checked' : 'value'] = dataToFill[key] || ''; }});
            if(dataToFill.id) form.id.value = dataToFill.id;
            
            if (config.entityName === 'User') { if (dataToFill.role_id) form.role_id.value = dataToFill.role_id; } // Special case
            
            openModal(modal);
        };
        
        if (config.saveFnName) window[config.saveFnName] = (form) => {
            if (!form.checkValidity()) return form.reportValidity();
            const btn = form.querySelector('button[type="submit"]'); btn.disabled = true;
            api[`save${config.entityName}`](new FormData(form))
                .then(data => { if(data.success) { showToast('Success', data.message, 'success'); window.location.reload(); } })
                .finally(() => btn.disabled = false);
        };

        if (config.deleteFnName) window[config.deleteFnName] = (id, btn) => {
            if (!confirm(`Delete this ${config.entityName.toLowerCase()}? This cannot be undone.`)) return;
            btn.disabled = true;
            api[`delete${config.entityName}`](id).then(data => {
                if (data.success) { showToast('Success', data.message, 'success'); btn.closest('tr')?.remove(); }
            }).catch(() => btn.disabled = false);
        };
    };
    
    // --- 6. Initializing Handlers ---
    setupModal({ entityName: 'Client', modalId: 'client-modal', openFnName: 'openClientModal', saveFnName: 'saveClient', deleteFnName: 'deleteClient' });
    setupModal({ entityName: 'Product', modalId: 'product-modal', openFnName: 'openProductModal', saveFnName: 'saveProduct', deleteFnName: 'deleteProduct' });
    setupModal({ entityName: 'TaxRate', modalId: 'tax-rate-modal', openFnName: 'openTaxRateModal', saveFnName: 'saveTaxRate', deleteFnName: 'deleteTaxRate' });
    setupModal({ entityName: 'Bank', modalId: 'bank-modal', openFnName: 'openBankModal', saveFnName: 'saveBank', deleteFnName: 'deleteBank' });
    setupModal({ entityName: 'User', modalId: 'user-modal', openFnName: 'openUserModal', saveFnName: 'saveUser', deleteFnName: 'deleteUser' });

    window.openCompanyModal = () => { /* Logic from prev. */ }; window.saveCompany = (form) => { /* Logic from prev. */ }; // Assume these are defined

    // --- 7. Tab Management & Event Listeners ---
    document.addEventListener('DOMContentLoaded', () => {
        const hash = window.location.hash.substring(1);
        const tabs = document.querySelectorAll('.tab');
        
        window.showTab = tabName => {
            tabs.forEach(t => t.classList.toggle('active', t.dataset.tab === tabName));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.toggle('active', c.id === `${tabName}-tab`));
            window.history.pushState(null, '', '#' + tabName); // Update hash without jumping
        };

        tabs.forEach(t => t.addEventListener('click', () => showTab(t.dataset.tab)));
        if (hash && document.getElementById(`${hash}-tab`)) showTab(hash);
        else if(tabs.length) showTab(tabs[0].dataset.tab);

        window.addEventListener('click', e => { if (e.target.classList.contains('modal')) closeModal(e.target); });
        document.addEventListener('keydown', e => { if (e.key === "Escape") document.querySelectorAll('.modal').forEach(closeModal); });
        
        setTimeout(() => document.querySelectorAll('.alert').forEach(el => el.remove()), 7000);

        // --- GST STATE LOGIC ---
        const states = { "Andhra Pradesh":"37", "Arunachal Pradesh":"12", "Assam":"18", "Bihar":"10", "Chhattisgarh":"22", "Goa":"30", "Gujarat":"24", "Haryana":"06", "Himachal Pradesh":"02", "Jharkhand":"20", "Karnataka":"29", "Kerala":"32", "Madhya Pradesh":"23", "Maharashtra":"27", "Manipur":"14", "Meghalaya":"17", "Mizoram":"15", "Nagaland":"13", "Odisha":"21", "Punjab":"03", "Rajasthan":"08", "Sikkim":"11", "Tamil Nadu":"33", "Telangana":"36", "Tripura":"16", "Uttar Pradesh":"09", "Uttarakhand":"05", "West Bengal":"19", "Andaman and Nicobar Islands":"35", "Chandigarh":"04", "Dadra and Nagar Haveli and Daman and Diu":"26", "Delhi":"07", "Jammu and Kashmir":"01", "Ladakh":"38", "Lakshadweep":"31", "Puducherry":"34", "Other Territory":"97" };
        const stateSelect = document.getElementById('client_state');
        if (stateSelect) {
            for (const [state, code] of Object.entries(states)) {
                stateSelect.add(new Option(state, state));
            }
            stateSelect.addEventListener('change', () => {
                document.getElementById('client_state_code').value = states[stateSelect.value] || '';
            });
        }
    });

})(); // End IIFE