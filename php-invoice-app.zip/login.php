<?php

/**
 * =====================================================================================
 * Login Page
 * =====================================================================================
 *
 * This script serves as the entry point for user authentication.
 * - It handles both displaying the login form (GET request) and processing
 *   the login credentials (POST request).
 * - Utilizes the Auth class for secure login verification.
 * - Redirects authenticated users to the dashboard (index.php).
 * - Shows an error message on login failure.
 *
 */

// Include the master configuration file, which also handles session start and class autoloading.
require_once __DIR__ . '/config/config.php';

// Instantiate the database and auth objects
$db = Database::getInstance();
$auth = new Auth($db);

// If the user is already logged in, redirect them to the dashboard immediately.
if ($auth->isLoggedIn()) {
    header('Location: ' . BASE_URL . 'index.php');
    exit();
}

// Initialize error variable
$error = '';

// Process form submission if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // Attempt to log the user in using the Auth class
    if ($auth->login($username, $password)) {
        // Login was successful, redirect to the dashboard.
        header('Location: ' . BASE_URL . 'index.php');
        exit();
    } else {
        // Login failed, set an error message to display on the form.
        $error = 'Invalid username or password.';
    }
}

// No header partial is used here as the login page has a unique, simpler layout.

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Invoice Generator</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Scoped styles specifically for the login page for simplicity */
        body.login-page {
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            background-color: var(--body-bg, #f1f5f9);
        }

        .login-container {
            width: 100%;
            max-width: 400px;
            margin: 0 auto;
            padding: 2rem;
        }

        .login-header {
            text-align: center;
            margin-bottom: 2rem;
        }

        .login-header h1 {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary, #1e40af);
            margin-bottom: 0.5rem;
        }

        .login-header p {
            color: var(--text-secondary, #64748b);
        }

        .login-form {
            background: var(--card-bg, #ffffff);
            border-radius: var(--radius-lg, 0.5rem);
            box-shadow: var(--shadow-md, 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06));
            padding: 2.5rem 2rem;
        }
        
        .alert-login-error {
            background-color: rgba(239, 68, 68, 0.1);
            color: var(--danger, #ef4444);
            padding: 0.75rem 1rem;
            border-radius: var(--radius-md, 0.375rem);
            margin-bottom: 1.5rem;
            text-align: center;
            font-size: 0.875rem;
            border: 1px solid rgba(239, 68, 68, 0.2);
        }
    </style>
</head>
<body class="login-page">

    <div class="login-container">
        <div class="login-header">
            <h1>Invoice System</h1>
            <p>Please log in to continue</p>
        </div>

        <div class="login-form">
            <?php if (!empty($error)): ?>
                <div class="alert-login-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <form action="login.php" method="post" novalidate>
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required autocomplete="username">
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required autocomplete="current-password">
                </div>

                <div class="form-group" style="margin-top: 2rem;">
                    <button type="submit" class="btn btn-primary btn-block">Login</button>
                </div>
            </form>
        </div>
    </div>

</body>
</html>