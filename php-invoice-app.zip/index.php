<?php

/**
 * =====================================================================================
 * Dashboard - Main Application Entry Point
 * =====================================================================================
 *
 * This script serves as the primary dashboard for logged-in users.
 *
 * Key Responsibilities:
 * - Requires a user to be logged in, redirecting to login.php if not.
 * - Fetches initial data required for the dashboard view (e.g., invoices, company info).
 * - Acts as the main 'controller' for the dashboard layout.
 * - Includes reusable partials for header, footer, and modals.
 *
 */

// Step 1: Bootstrap the application
// This includes config, starts session, and sets up autoloading.
require_once __DIR__ . '/config/config.php';

// Step 2: Authentication and Authorization
// Check if the user is logged in. Redirect if they are not.
$db = Database::getInstance();
$auth = new Auth($db);
$auth->requireLogin();

// Get the current logged-in user object
$currentUser = $auth->getUser();


// Step 3: Fetch Data for the View using our new Model classes

// Fetch company details
$company = new Company($db);
$company->loadByUser($currentUser->id);

// Fetch invoices for the invoice list tab (using Paginator class later)
// For now, let's just get the latest few. A full Paginator class will replace this logic.
$invoiceModel = new Invoice($db);
$latestInvoices = $invoiceModel->findAllForUser($currentUser->id, 15, 0); // Limit 15, Offset 0
$totalInvoices = $invoiceModel->countForUser($currentUser->id);
// Simple pagination variables for now
$invoices_per_page = 15;
$total_invoice_pages = ceil($totalInvoices / $invoices_per_page);
$current_invoice_page = isset($_GET['invoice_page']) ? max(1, (int)$_GET['invoice_page']) : 1;


// Fetch next invoice number for display on the "Create" tab
$nextInvoiceNumber = $invoiceModel->generateNextInvoiceNumber($currentUser->id);


// Step 4: Include the Header Partial
// This contains the top part of the HTML document, CSS links, etc.
$pageTitle = 'Dashboard'; // Set a title for the header
require_once __DIR__ . '/partials/header.php';

// At this point, PHP processing is done, and the view (HTML) begins.
?>

<!-- Main Content Wrapper -->
<div class="content-wrapper">
    <!-- Sidebar Partial -->
    <?php require_once __DIR__ . '/partials/sidebar.php'; ?>

    <!-- Main Content Area -->
    <div class="main-content">
        <!-- Display flash messages if any -->
        <?php // The session helper/logic to display flashes will be in header.php or a dedicated helper ?>

        <div class="card">
            <div class="tabs">
                <div class="tab" data-tab="invoices">Invoices</div>
                <div class="tab" data-tab="clients">Clients</div>
                <div class="tab" data-tab="create-invoice">Create Invoice</div>
            </div>

            <!-- Invoices Tab -->
            <div class="tab-content" id="invoices-tab">
                <div class="card-body">
                    <div class="flex justify-between items-center mb-4">
                        <h2 class="text-lg font-semibold">Your Invoices (<?php echo $totalInvoices; ?>)</h2>
                        <button type="button" class="btn btn-primary btn-sm" onclick="showTab('create-invoice')">
                            <i class="fas fa-plus btn-icon"></i> New Invoice
                        </button>
                    </div>

                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>Invoice #</th>
                                    <th>Date</th>
                                    <th>Client</th>
                                    <th class="text-right">Total (₹)</th>
                                    <th class="text-center">Status</th>
                                    <th class="text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="invoice-list-tbody">
                                <!-- Data will be loaded via AJAX for full pagination, this is a server-rendered first page -->
                                <?php if (!empty($latestInvoices)): ?>
                                    <?php foreach ($latestInvoices as $invoice): ?>
                                    <tr>
                                        <td class="font-semibold"><?php echo htmlspecialchars($invoice['invoice_number']); ?></td>
                                        <td><?php echo date('d-m-Y', strtotime($invoice['invoice_date'])); ?></td>
                                        <td><?php echo htmlspecialchars($invoice['client_name'] ?? 'N/A'); ?></td>
                                        <td class="text-right"><?php echo number_format($invoice['total_amount'], 2); ?></td>
                                        <td class="text-center">
                                            <span class="status-badge status-<?php echo str_replace('_', '-', $invoice['status']); ?>">
                                                <?php echo ucfirst(str_replace('_', ' ', $invoice['status'])); ?>
                                            </span>
                                        </td>
                                        <td class="text-center">
                                            <!-- Action buttons (JS functions to be defined later) -->
                                            <div class="btn-group">
                                                <button type="button" class="btn btn-outline btn-sm" title="View & Download PDF"><i class="fas fa-eye"></i></button>
                                                <a href="invoices.php?action=edit&id=<?php echo $invoice['id']; ?>" class="btn btn-outline btn-sm" title="Edit Invoice"><i class="fas fa-edit"></i></a>
                                                <button type="button" class="btn btn-danger btn-sm" title="Delete Invoice"><i class="fas fa-trash"></i></button>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="6" class="empty-table">No invoices created yet.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Basic pagination (will be enhanced by Paginator class later) -->
                    <?php if ($total_invoice_pages > 1): ?>
                    <div class="pagination">
                        <?php if ($current_invoice_page > 1): ?>
                            <a href="?invoice_page=<?php echo $current_invoice_page - 1; ?>#invoices">« Prev</a>
                        <?php endif; ?>
                        
                        <span>Page <?php echo $current_invoice_page; ?> of <?php echo $total_invoice_pages; ?></span>
                        
                        <?php if ($current_invoice_page < $total_invoice_pages): ?>
                            <a href="?invoice_page=<?php echo $current_invoice_page + 1; ?>#invoices">Next »</a>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                </div>
            </div>

            <!-- Clients Tab (Placeholder - will be in clients.php) -->
            <div class="tab-content" id="clients-tab">
                <div class="card-body">
                    <p>Client management will be handled on the <a href="clients.php">Clients Page</a>.</p>
                </div>
            </div>

            <!-- Create Invoice Tab (Placeholder - will be in invoices.php?action=create) -->
            <div class="tab-content" id="create-invoice-tab">
                <div class="card-body">
                    <p>The invoice creation form will be located at <a href="invoices.php?action=create">Create Invoice Page</a>.</p>
                    <p>Next auto-generated invoice number: <strong><?php echo htmlspecialchars($nextInvoiceNumber); ?></strong></p>
                </div>
            </div>

        </div> <!-- /.card -->
    </div> <!-- /.main-content -->
</div> <!-- /.content-wrapper -->

<!-- Modals Partial -->
<?php require_once __DIR__ . '/partials/modals.php'; ?>

<!-- Footer Partial -->
<?php require_once __DIR__ . '/partials/footer.php'; ?>