<?php

/**
 * =====================================================================================
 * Main Configuration File
 * =====================================================================================
 *
 * This file contains the primary configuration settings for the application.
 * It sets up database credentials, defines important paths, configures error reporting,
 * and initializes the session.
 *
 * It is included at the start of all major application entry points.
 *
 */

// --- Environment and Error Reporting ---
// Set to 'development' to see all errors, 'production' to hide them
define('ENVIRONMENT', 'development');

if (ENVIRONMENT === 'development') {
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    error_reporting(0);
}


// --- Database Credentials ---
// Replace with your actual database connection details.
define('DB_HOST', 'localhost');
define('DB_USER', 'your_db_user'); // <-- IMPORTANT: CHANGE THIS
define('DB_PASS', 'your_db_password'); // <-- IMPORTANT: CHANGE THIS
define('DB_NAME', 'your_db_name'); // <-- IMPORTANT: CHANGE THIS
define('DB_CHARSET', 'utf8mb4');


// --- Application Paths and URLs ---
// ROOT_PATH is the absolute path to the project root directory.
// It uses __DIR__ which is the directory of the current file (config), then goes up one level.
define('ROOT_PATH', dirname(__DIR__));

// BASE_URL should be the full URL to your application's root.
// Example: http://localhost/php-invoice-app or https://yourdomain.com
// This automates finding the base URL. Adjust if your setup is non-standard.
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'];
$script_name = str_replace(basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']);
define('BASE_URL', $protocol . $host . $script_name);


// --- Business Specific Settings (for Single Business Logic) ---
// This is the primary business's state name. Crucial for GST calculations.
// Use the exact state name as it will be stored in the client's record.
// Example: 'Uttar Pradesh'
define('BUSINESS_HOME_STATE', 'Your Business State'); // <-- IMPORTANT: SET YOUR STATE


// --- Session Management ---
// Start the session if it hasn't been started already.
// This ensures $_SESSION is available throughout the application.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


// --- Global Autoloader ---
// This function will automatically load class files when they are first used.
// This eliminates the need for many `require_once` statements at the top of each file.
spl_autoload_register(function ($className) {
    // Standard class path
    $classFile = ROOT_PATH . '/classes/' . $className . '.php';

    if (file_exists($classFile)) {
        require_once $classFile;
    }
    // You could add more directories here if needed in the future
    // else {
    //     // Handle class not found error if you want strict checking
    //     // For example: die("Error: Class '$className' not found.");
    // }
});

?>