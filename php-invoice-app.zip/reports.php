<?php
/**
 * =====================================================================================
 * Reports Dashboard Page
 * =====================================================================================
 *
 * This script serves as the main dashboard for business intelligence and reporting.
 * - It requires a user to be logged in.
 * - Fetches aggregated data (KPIs, monthly totals, top clients).
 * - Displays data in both summary cards and charts.
 *
 */

// Step 1: Bootstrap and Authenticate
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/helpers/format_helper.php'; // For currency formatting
$db = Database::getInstance();
$auth = new Auth($db);
$auth->requireLogin();
$currentUser = $auth->getUser();


// Step 2: Date Filtering (logic from original app, adapted)
$default_end_date = date('Y-m-d');
$default_start_date = date('Y-m-d', strtotime('-89 days')); // Last 90 days

$start_date = isset($_GET['start_date']) && filter_var($_GET['start_date'], FILTER_VALIDATE_REGEXP, ["options" => ["regexp"=>"/^\d{4}-\d{2}-\d{2}$/"]])
    ? $_GET['start_date']
    : $default_start_date;

$end_date = isset($_GET['end_date']) && filter_var($_GET['end_date'], FILTER_VALIDATE_REGEXP, ["options" => ["regexp"=>"/^\d{4}-\d{2}-\d{2}$/"]])
    ? $_GET['end_date']
    : $default_end_date;

// Step 3: Fetch Data for the View
$pageTitle = 'Reports Dashboard';

// Create a Report model/service in the future for cleaner code.
// For now, we perform the queries here as this is the "controller".
$report_error = null;
try {
    // --- KPIs ---
    $kpiSql = "SELECT
                    COUNT(*) as total_invoice_count,
                    COALESCE(SUM(total_amount), 0.00) as total_invoiced,
                    COALESCE(SUM(CASE WHEN status = 'paid' THEN total_amount ELSE advance_paid END), 0.00) as total_collected,
                    COALESCE(SUM(CASE WHEN status != 'paid' THEN total_amount - advance_paid ELSE 0 END), 0.00) as outstanding_receivables,
                    COUNT(DISTINCT client_id) as active_clients
                FROM invoices
                WHERE user_id = :user_id AND invoice_date BETWEEN :start_date AND :end_date";
    $kpiStmt = $db->query($kpiSql, ['user_id' => $currentUser->id, 'start_date' => $start_date, 'end_date' => $end_date]);
    $kpis = $kpiStmt->fetch();

    // --- Monthly Revenue for Chart ---
    $monthlySql = "SELECT DATE_FORMAT(invoice_date, '%Y-%m') as month, SUM(total_amount) as revenue
                   FROM invoices
                   WHERE user_id = :user_id AND invoice_date BETWEEN :start_date AND :end_date
                   GROUP BY month ORDER BY month ASC";
    $monthlyStmt = $db->query($monthlySql, ['user_id' => $currentUser->id, 'start_date' => $start_date, 'end_date' => $end_date]);
    $monthlyData = $monthlyStmt->fetchAll();

    // --- Top Clients for Chart ---
    $topClientsSql = "SELECT c.name as client_name, SUM(i.total_amount) as total_billed
                      FROM invoices i JOIN clients c ON i.client_id = c.id
                      WHERE i.user_id = :user_id AND i.invoice_date BETWEEN :start_date AND :end_date
                      GROUP BY i.client_id, c.name ORDER BY total_billed DESC LIMIT 5";
    $topClientsStmt = $db->query($topClientsSql, ['user_id' => $currentUser->id, 'start_date' => $start_date, 'end_date' => $end_date]);
    $topClientsData = $topClientsStmt->fetchAll();
    
} catch (PDOException $e) {
    $report_error = "An error occurred while generating report data.";
    error_log("Reports page error for user {$currentUser->id}: " . $e->getMessage());
}

$company = new Company($db);
$company->loadByUser($currentUser->id);


// Step 4: Include Header
require_once __DIR__ . '/partials/header.php';
?>

<!-- Main Content Wrapper -->
<div class="content-wrapper">

    <!-- Sidebar Partial -->
    <?php require_once __DIR__ . '/partials/sidebar.php'; ?>

    <!-- Main Content Area -->
    <div class="main-content">
        <!-- Date Filter Form -->
        <div class="card">
            <div class="card-body">
                <form method="GET" action="reports.php" class="form-row" style="margin-bottom: 0;">
                    <div class="form-col">
                        <label for="start_date">Start Date</label>
                        <input type="date" id="start_date" name="start_date" value="<?php echo h($start_date); ?>">
                    </div>
                    <div class="form-col">
                        <label for="end_date">End Date</label>
                        <input type="date" id="end_date" name="end_date" value="<?php echo h($end_date); ?>">
                    </div>
                    <div class="form-col" style="flex: 0 0 auto;">
                        <button type="submit" class="btn btn-primary">Update Report</button>
                    </div>
                </form>
            </div>
        </div>

        <?php if ($report_error): ?>
            <div class="alert alert-danger"><?php echo $report_error; ?></div>
        <?php else: ?>
            <!-- KPI Cards -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1rem; margin-bottom: 1.5rem;">
                <div class="card-body card">
                    <div class="text-muted text-xs">TOTAL INVOICED</div>
                    <div class="font-semibold text-lg">₹<?php echo format_currency($kpis['total_invoiced']); ?></div>
                    <div class="text-xs"><?php echo $kpis['total_invoice_count']; ?> invoices</div>
                </div>
                <div class="card-body card">
                    <div class="text-muted text-xs">TOTAL COLLECTED</div>
                    <div class="font-semibold text-lg text-success">₹<?php echo format_currency($kpis['total_collected']); ?></div>
                </div>
                <div class="card-body card">
                    <div class="text-muted text-xs">OUTSTANDING</div>
                    <div class="font-semibold text-lg text-danger">₹<?php echo format_currency($kpis['outstanding_receivables']); ?></div>
                </div>
                <div class="card-body card">
                    <div class="text-muted text-xs">ACTIVE CLIENTS</div>
                    <div class="font-semibold text-lg"><?php echo $kpis['active_clients']; ?></div>
                </div>
            </div>

            <!-- Charts -->
            <div class="card">
                <div class="card-body">
                    <h3 class="box-title">Revenue Overview</h3>
                    <div style="height: 350px;">
                        <canvas id="monthlyRevenueChart"></canvas>
                    </div>
                </div>
            </div>

             <div class="card">
                <div class="card-body">
                     <h3 class="box-title">Top 5 Clients (by Revenue)</h3>
                    <div style="height: 350px;">
                        <canvas id="topClientsChart"></canvas>
                    </div>
                </div>
            </div>
        <?php endif; ?>

    </div> <!-- /.main-content -->
</div> <!-- /.content-wrapper -->

<?php
// Include Modals and Footer
require_once __DIR__ . '/partials/modals.php';
?>

<!-- Chart.js Library -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns/dist/chartjs-adapter-date-fns.bundle.min.js"></script>

<script>
// JavaScript for charts, directly embedded for simplicity
document.addEventListener('DOMContentLoaded', function () {
    const chartDefaultOptions = {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            y: { ticks: { callback: value => '₹' + new Intl.NumberFormat('en-IN').format(value) } },
            x: { grid: { display: false } }
        }
    };

    // Monthly Revenue Chart
    const monthlyCtx = document.getElementById('monthlyRevenueChart');
    if (monthlyCtx) {
        const monthlyData = <?php echo json_encode($monthlyData ?? []); ?>;
        new Chart(monthlyCtx, {
            type: 'bar',
            data: {
                labels: monthlyData.map(d => new Date(d.month + '-02').toLocaleString('default', { month: 'short', year: '2-digit' })),
                datasets: [{
                    label: 'Revenue',
                    data: monthlyData.map(d => d.revenue),
                    backgroundColor: 'rgba(30, 64, 175, 0.8)',
                    borderColor: 'rgba(30, 64, 175, 1)',
                    borderWidth: 1
                }]
            },
            options: chartDefaultOptions
        });
    }

    // Top Clients Chart
    const topClientsCtx = document.getElementById('topClientsChart');
    if (topClientsCtx) {
        const topClientsData = <?php echo json_encode($topClientsData ?? []); ?>;
        new Chart(topClientsCtx, {
            type: 'bar',
            data: {
                labels: topClientsData.map(d => d.client_name),
                datasets: [{
                    label: 'Total Billed',
                    data: topClientsData.map(d => d.total_billed),
                    backgroundColor: 'rgba(29, 78, 216, 0.7)',
                    borderColor: 'rgba(29, 78, 216, 1)',
                    borderWidth: 1
                }]
            },
            options: { ...chartDefaultOptions, indexAxis: 'y' }
        });
    }
});
</script>

<?php
require_once __DIR__ . '/partials/footer.php';
?>