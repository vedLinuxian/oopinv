<?php
/**
 * =====================================================================================
 * Bank Accounts Management Page
 * =====================================================================================
 *
 * This script serves as the main interface for managing user bank accounts.
 * - Requires a user to be logged in.
 * - Provides the UI for listing, creating, updating, and deleting bank accounts.
 *
 */

// Step 1: Bootstrap the application
require_once __DIR__ . '/config/config.php';

// Step 2: Authentication
$db = Database::getInstance();
$auth = new Auth($db);
$auth->requireLogin();
$currentUser = $auth->getUser();

// Step 3: Fetch Data for the View
$pageTitle = 'Manage Bank Accounts';

$bankModel = new Bank($db);
$initialBanks = $bankModel->findAllForUser($currentUser->id);

$company = new Company($db);
$company->loadByUser($currentUser->id); // For the sidebar

// Step 4: Include Header
require_once __DIR__ . '/partials/header.php';
?>

<!-- Main Content Wrapper -->
<div class="content-wrapper">

    <!-- Sidebar Partial -->
    <?php require_once __DIR__ . '/partials/sidebar.php'; ?>

    <!-- Main Content Area -->
    <div class="main-content">
        <div class="card">
            <div class="card-body">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-lg font-semibold">Your Bank Accounts</h2>
                    <button type="button" class="btn btn-primary btn-sm" onclick="openBankModal()">
                        <i class="fas fa-plus btn-icon"></i> Add New Bank
                    </button>
                </div>

                <!-- Bank Accounts List Table -->
                <div class="table-responsive">
                    <table id="banks-table">
                        <thead>
                            <tr>
                                <th>Bank Name</th>
                                <th>Account Holder</th>
                                <th>Account Number</th>
                                <th>IFSC Code</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="banks-table-body">
                            <?php if (!empty($initialBanks)): ?>
                                <?php foreach ($initialBanks as $bank): ?>
                                    <tr>
                                        <td class="font-semibold"><?php echo h($bank['bank_name']); ?></td>
                                        <td><?php echo h($bank['account_holder_name'] ?? '-'); ?></td>
                                        <td><?php echo h($bank['account_number']); ?></td>
                                        <td><?php echo h($bank['ifsc_code']); ?></td>
                                        <td class="text-center">
                                            <div class="btn-group">
                                                <button class="btn btn-outline btn-sm" title="Edit Bank Account" onclick='openBankModal(<?php echo json_encode($bank, JSON_HEX_APOS); ?>)'>
                                                    <i class="fas fa-edit"></i> Edit
                                                </button>
                                                <button class="btn btn-danger btn-sm" title="Delete Bank Account" onclick="deleteBank(<?php echo $bank['id']; ?>, this)">
                                                    <i class="fas fa-trash"></i> Delete
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="empty-table">No bank accounts added yet.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div> <!-- /.card-body -->
        </div> <!-- /.card -->
    </div> <!-- /.main-content -->
</div> <!-- /.content-wrapper -->

<!-- Bank Add/Edit Modal (to be moved to modals.php later if desired) -->
<div id="bank-modal" class="modal">
    <div class="modal-content">
        <form id="bank-form" onsubmit="event.preventDefault(); saveBank(this);">
            <div class="modal-header">
                <h2 class="modal-title" id="bank-modal-title">Add New Bank Account</h2>
                <button type="button" class="modal-close" onclick="closeBankModal()">&times;</button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="bank_form_id" name="id" value="">

                <div class="form-group">
                    <label for="bank_name">Bank Name <span class="text-danger">*</span></label>
                    <input type="text" id="bank_name" name="bank_name" required>
                </div>
                <div class="form-group">
                    <label for="account_holder_name">Account Holder Name</label>
                    <input type="text" id="account_holder_name" name="account_holder_name" placeholder="Optional, as per bank records">
                </div>
                <div class="form-row">
                    <div class="form-col">
                        <label for="account_number">Account Number <span class="text-danger">*</span></label>
                        <input type="text" id="account_number" name="account_number" required>
                    </div>
                    <div class="form-col">
                        <label for="ifsc_code">IFSC Code <span class="text-danger">*</span></label>
                        <input type="text" id="ifsc_code" name="ifsc_code" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-col">
                        <label for="branch_name">Branch Name</label>
                        <input type="text" id="branch_name" name="branch_name" placeholder="Optional">
                    </div>
                    <div class="form-col">
                        <label for="upi_id">UPI ID</label>
                        <input type="text" id="upi_id" name="upi_id" placeholder="Optional">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeBankModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Bank</button>
            </div>
        </form>
    </div>
</div>

<?php
// Step 5: Include main Modals and Footer
require_once __DIR__ . '/partials/modals.php';
require_once __DIR__ . '/partials/footer.php';
?>