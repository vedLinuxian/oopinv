<?php

/**
 * =====================================================================================
 * User Model Class
 * =====================================================================================
 *
 * This class represents a single user in the application. It's responsible for
 * fetching, storing, and eventually managing user-specific data, including their role
 * and permissions.
 *
 * It acts as a Data Transfer Object (DTO) holding user properties and will contain
 * the core logic for our RBAC system.
 *
 */

class User
{
    /**
     * @var Database The database connection instance.
     */
    private $db;

    // --- User Properties ---
    public $id;
    public $username;
    public $role_id;
    public $created_at;
    
    /**
     * @var Role|null The user's role object. Lazily loaded.
     */
    private $role = null;


    /**
     * User constructor.
     * @param Database $db The database instance.
     */
    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    /**
     * Loads a user's data from the database by their ID.
     *
     * @param int $id The ID of the user to load.
     * @return bool True if the user was found and loaded, false otherwise.
     */
    public function load(int $id): bool
    {
        try {
            $stmt = $this->db->query("SELECT * FROM users WHERE id = :id", ['id' => $id]);
            $userData = $stmt->fetch();

            if ($userData) {
                $this->id = (int)$userData['id'];
                $this->username = $userData['username'];
                $this->role_id = (int)$userData['role_id'];
                $this->created_at = $userData['created_at'];
                return true;
            }
        } catch (PDOException $e) {
            error_log("Error loading user ID {$id}: " . $e->getMessage());
        }

        return false;
    }

    /**
     * Checks if this user has a specific permission.
     * This method will be the core of the RBAC checks.
     *
     * @param string $permission The permission string to check (e.g., 'delete_invoices').
     * @return bool True if the user has the permission, false otherwise.
     */
    public function hasPermission(string $permission): bool
    {
        // First, ensure the Role object is loaded.
        if ($this->role === null && $this->role_id) {
            $this->role = new Role($this->db);
            $this->role->load($this->role_id);
        }

        // If a role is loaded, delegate the permission check to the Role class.
        if ($this->role) {
            return $this->role->hasPermission($permission);
        }
        
        // If no role or role could not be loaded, the user has no permissions.
        return false;
    }
    
    /**
     * Get the user's role object.
     *
     * @return Role|null The Role object, or null if not set or not found.
     */
    public function getRole(): ?Role
    {
        if ($this->role === null && $this->role_id) {
            $this->role = new Role($this->db);
            $this->role->load($this->role_id);
        }
        return $this->role;
    }
    
    /**
     * Finds and returns all users in the system.
     * Primarily used for the user management page by an admin.
     *
     * @return array An array of User objects.
     */
    public static function findAll(Database $db): array
    {
        $users = [];
        try {
            $stmt = $db->query("SELECT id FROM users ORDER BY username ASC");
            $allUserData = $stmt->fetchAll();

            foreach ($allUserData as $userData) {
                $user = new User($db);
                if ($user->load((int)$userData['id'])) {
                    $users[] = $user;
                }
            }
        } catch (PDOException $e) {
            error_log("Error finding all users: " . $e->getMessage());
        }
        return $users;
    }

    /**
     * Saves a user record (for both creation and updates).
     *
     * @param string $username
     * @param string $password (plain text, will be hashed if not empty)
     * @param int $role_id
     * @return bool True on success, false on failure.
     */
    public function save(string $username, string $password, int $role_id): bool
    {
        try {
            if ($this->id) { // Update existing user
                $params = [
                    'username' => $username,
                    'role_id' => $role_id,
                    'id' => $this->id
                ];
                $sql = "UPDATE users SET username = :username, role_id = :role_id";
                if (!empty($password)) {
                    $sql .= ", password = :password";
                    $params['password'] = password_hash($password, PASSWORD_DEFAULT);
                }
                $sql .= " WHERE id = :id";
                $this->db->query($sql, $params);

            } else { // Create new user
                if (empty($password)) {
                    // Password is required for new users
                    return false;
                }
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                $sql = "INSERT INTO users (username, password, role_id) VALUES (:username, :password, :role_id)";
                $stmt = $this->db->query($sql, [
                    'username' => $username,
                    'password' => $hashedPassword,
                    'role_id' => $role_id
                ]);
                $this->id = $this->db->lastInsertId();
            }
            return true;

        } catch (PDOException $e) {
            error_log("Error saving user {$this->id}: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Deletes the current user from the database.
     *
     * @return bool True on success, false on failure.
     */
    public function delete(): bool
    {
        if (!$this->id) {
            return false;
        }

        try {
            $this->db->query("DELETE FROM users WHERE id = :id", ['id' => $this->id]);
            return true;
        } catch (PDOException $e) {
            error_log("Error deleting user ID {$this->id}: " . $e->getMessage());
            return false;
        }
    }
}