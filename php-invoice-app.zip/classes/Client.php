<?php

/**
 * =====================================================================================
 * Client Model Class
 * =====================================================================================
 *
 * This class represents a single client in the application. It's responsible for all
 * CRUD (Create, Read, Update, Delete) operations related to clients, ensuring
 * that all operations are scoped to the currently logged-in user.
 *
 */

class Client
{
    /** @var Database The database connection instance. */
    private $db;

    // --- Client Properties ---
    public $id;
    public $user_id;
    public $name;
    public $address;
    public $gstin;
    public $state;
    public $state_code;
    public $phone;
    public $email;
    public $created_at;


    /**
     * Client constructor.
     * @param Database $db The database instance.
     */
    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    /**
     * Finds a single client by its ID, scoped to a specific user.
     *
     * @param int $id The ID of the client.
     * @param int $user_id The ID of the owner user.
     * @return array|null An associative array of the client's data, or null if not found.
     */
    public function findByIdForUser(int $id, int $user_id): ?array
    {
        try {
            $stmt = $this->db->query("SELECT * FROM clients WHERE id = :id AND user_id = :user_id", [
                'id' => $id,
                'user_id' => $user_id
            ]);
            return $stmt->fetch() ?: null;
        } catch (PDOException $e) {
            error_log("Error finding client by ID {$id} for user {$user_id}: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Finds all clients for a user, with pagination and search.
     *
     * @param int $user_id The ID of the owner user.
     * @param int $limit Number of records to return.
     * @param int $offset Number of records to skip.
     * @param string $searchTerm Optional search term.
     * @return array An array of client records.
     */
    public function findAllForUser(int $user_id, int $limit, int $offset, string $searchTerm = ''): array
    {
        $params = [
            'user_id' => $user_id,
            'limit' => $limit,
            'offset' => $offset
        ];

        $sql = "SELECT * FROM clients WHERE user_id = :user_id";

        if (!empty($searchTerm)) {
            $sql .= " AND (name LIKE :search OR gstin LIKE :search OR email LIKE :search OR address LIKE :search)";
            $params['search'] = "%" . $searchTerm . "%";
        }

        $sql .= " ORDER BY name ASC LIMIT :limit OFFSET :offset";

        try {
            $stmt = $this->db->query($sql, $params);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("Error finding all clients for user {$user_id}: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Counts the total number of clients for a user, with optional search.
     *
     * @param int $user_id The ID of the owner user.
     * @param string $searchTerm Optional search term.
     * @return int The total count of clients.
     */
    public function countForUser(int $user_id, string $searchTerm = ''): int
    {
        $params = ['user_id' => $user_id];
        $sql = "SELECT COUNT(*) FROM clients WHERE user_id = :user_id";

        if (!empty($searchTerm)) {
            $sql .= " AND (name LIKE :search OR gstin LIKE :search OR email LIKE :search OR address LIKE :search)";
            $params['search'] = "%" . $searchTerm . "%";
        }
        
        try {
            $stmt = $this->db->query($sql, $params);
            return (int)$stmt->fetchColumn();
        } catch (PDOException $e) {
            error_log("Error counting clients for user {$user_id}: " . $e->getMessage());
            return 0;
        }
    }


    /**
     * Saves the current client object's state to the database (creates or updates).
     *
     * @return bool True on success, false on failure.
     */
    public function save(): bool
    {
        // Basic validation
        if (empty($this->name) || empty($this->user_id)) {
            return false;
        }
        
        try {
            if ($this->id) { // Update
                $sql = "UPDATE clients SET 
                            name = :name, address = :address, gstin = :gstin, state = :state, 
                            state_code = :state_code, phone = :phone, email = :email 
                        WHERE id = :id AND user_id = :user_id";
                $this->db->query($sql, $this->getPropertiesAsArray());
            } else { // Create
                $sql = "INSERT INTO clients (user_id, name, address, gstin, state, state_code, phone, email) 
                        VALUES (:user_id, :name, :address, :gstin, :state, :state_code, :phone, :email)";
                $params = $this->getPropertiesAsArray();
                unset($params['id']); // Remove ID for insert
                
                $this->db->query($sql, $params);
                $this->id = $this->db->lastInsertId();
            }
            return true;
        } catch (PDOException $e) {
            error_log("Error saving client for user {$this->user_id}: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Deletes a client by its ID. The object must be loaded first via findByIdForUser.
     *
     * @return bool True on success, false on failure.
     */
    public function delete(): bool
    {
        if (!$this->id || !$this->user_id) {
            return false;
        }
        
        try {
            $this->db->query("DELETE FROM clients WHERE id = :id AND user_id = :user_id", [
                'id' => $this->id,
                'user_id' => $this->user_id
            ]);
            return true;
        } catch (PDOException $e) {
            error_log("Error deleting client ID {$this->id}: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Helper to get object properties as an associative array for PDO binding.
     * @return array
     */
    private function getPropertiesAsArray(): array
    {
        return [
            'id' => $this->id,
            'user_id' => $this->user_id,
            'name' => trim($this->name),
            'address' => empty(trim($this->address)) ? null : trim($this->address),
            'gstin' => empty(trim($this->gstin)) ? null : trim($this->gstin),
            'state' => empty(trim($this->state)) ? null : trim($this->state),
            'state_code' => empty(trim($this->state_code)) ? null : trim($this->state_code),
            'phone' => empty(trim($this->phone)) ? null : trim($this->phone),
            'email' => empty(trim($this->email)) ? null : filter_var(trim($this->email), FILTER_SANITIZE_EMAIL)
        ];
    }
}