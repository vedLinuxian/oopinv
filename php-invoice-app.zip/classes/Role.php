<?php

/**
 * = l==================================================================================
 * Role Model Class
 * =====================================================================================
 *
 * This class represents a user role and its associated permissions within the
 * application's Role-Based Access Control (RBAC) system.
 *
 * Key Features:
 * - Loads role data from the database.
 * - Stores permissions in a JSON-decoded array for easy access.
 * - Provides the core `hasPermission()` method used by the Auth and User classes.
 *
 */

class Role
{
    /**
     * @var Database The database connection instance.
     */
    private $db;

    // --- Role Properties ---
    public $id;
    public $name;
    
    /**
     * @var array Permissions associated with this role.
     */
    private $permissions = [];

    /**
     * Role constructor.
     * @param Database $db The database instance.
     */
    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    /**
     * Loads a role's data from the database by its ID.
     *
     * @param int $id The ID of the role to load.
     * @return bool True if the role was found and loaded, false otherwise.
     */
    public function load(int $id): bool
    {
        try {
            $stmt = $this->db->query("SELECT * FROM roles WHERE id = :id", ['id' => $id]);
            $roleData = $stmt->fetch();

            if ($roleData) {
                $this->id = (int)$roleData['id'];
                $this->name = $roleData['name'];
                
                // Decode the permissions from the JSON string stored in the database.
                // If decoding fails or is empty, default to an empty array.
                $this->permissions = json_decode($roleData['permissions'], true) ?? [];

                return true;
            }
        } catch (PDOException $e) {
            error_log("Error loading role ID {$id}: " . $e->getMessage());
        }

        return false;
    }

    /**
     * Checks if this role has a specific permission.
     *
     * @param string $permission The permission string to check (e.g., 'delete_invoices').
     * @return bool True if the role has the permission, false otherwise.
     */
    public function hasPermission(string $permission): bool
    {
        // For ultimate power, the 'Admin' role can have a wildcard permission.
        if (in_array('*', $this->permissions)) {
            return true;
        }

        // Otherwise, check if the specific permission exists in the array.
        return in_array($permission, $this->permissions);
    }
    
    /**
     * Returns the array of permissions for this role.
     * @return array
     */
    public function getPermissions(): array
    {
        return $this->permissions;
    }

    /**
     * Finds and returns all roles in the system.
     * Used for the user management page (e.g., in a dropdown).
     *
     * @param Database $db The database instance.
     * @return array An array of Role objects.
     */
    public static function findAll(Database $db): array
    {
        $roles = [];
        try {
            $stmt = $db->query("SELECT id FROM roles ORDER BY name ASC");
            $allRoleData = $stmt->fetchAll();

            foreach ($allRoleData as $roleData) {
                $role = new Role($db);
                if ($role->load((int)$roleData['id'])) {
                    $roles[] = $role;
                }
            }
        } catch (PDOException $e) {
            error_log("Error finding all roles: " . $e->getMessage());
        }
        return $roles;
    }
}