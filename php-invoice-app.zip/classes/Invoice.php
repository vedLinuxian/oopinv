<?php
/**
 * =====================================================================================
 * Invoice Model Class
 * =====================================================================================
 *
 * This class represents a single invoice and is responsible for all database
 * operations related to invoices and their line items.
 *
 */

class Invoice
{
    /** @var Database The database connection instance. */
    private $db;

    // --- Invoice Properties ---
    public $id;
    public $user_id;
    public $client_id;
    public $invoice_number;
    public $invoice_date;
    public $due_date;
    public $status; // 'unpaid', 'paid', 'partially_paid'

    // Financials
    public $subtotal;
    public $discount_rate;
    public "amount_due" to "$this->db->beginTransaction();" line, but the surrounding context appears correct. Re-checking... ah, I see a " and a variable. This must be a typo. Let's fix that. The user wants bug-free code. The code in the previous response from me seems correct, but it's always good to double check the user's input. The user has not provided new input, but has just said "next". Ok, I will proceed with the original `Invoice.php` code as planned. The thought process for checking for errors was a good internal QA step.

---

Here is the complete code for **`classes/Invoice.php`**.

```php
<?php
/**
 * =====================================================================================
 * Invoice Model Class
 * =====================================================================================
 *
 * This class represents a single invoice and is responsible for all database
 * operations related to invoices and their line items.
 *
 */

class Invoice
{
    /** @var Database The database connection instance. */
    private $db;

    // --- Invoice Properties ---
    public $id;
    public $user_id;
    public $client_id;
    public $invoice_number;
    public $invoice_date;
    public $due_date;
    public $status; // 'unpaid', 'paid', 'partially_paid'

    // Financials
    public $subtotal = 0.00;
    public $discount_rate = 0.00;
    public $discount_amount = 0.00;
    public $cgst_rate = 0.00;
    public $sgst_rate = 0.00;
    public $igst_rate = 0.00;
    public $cgst_amount = 0.00;
    public $sgst_amount = 0.00;
    public $igst_amount = 0.00;
    public $total_amount = 0.00;
    public $advance_paid = 0.00;

    // Other Details
    public $hsn_code;
    public $po_number;
    public $notes;
    public $bank_account_id;

    /** @var array Array of invoice line items. */
    public $items = [];


    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    /**
     * Finds a single invoice by its ID and User ID.
     * Also loads its associated line items.
     *
     * @param int $id The invoice ID.
     * @param int $user_id The owner's user ID.
     * @return array|null An associative array of invoice data, or null.
     */
    public function findByIdForUser(int $id, int $user_id): ?array
    {
        try {
            $sql = "SELECT i.*, c.name as client_name 
                    FROM invoices i 
                    JOIN clients c ON i.client_id = c.id
                    WHERE i.id = :id AND i.user_id = :user_id";
            $stmt = $this->db->query($sql, ['id' => $id, 'user_id' => $user_id]);
            $invoiceData = $stmt->fetch();

            if ($invoiceData) {
                $itemStmt = $this->db->query("SELECT * FROM invoice_items WHERE invoice_id = :id ORDER BY id ASC", ['id' => $id]);
                $invoiceData['items'] = $itemStmt->fetchAll();
                return $invoiceData;
            }
        } catch (PDOException $e) {
            error_log("Error finding invoice ID {$id}: " . $e->getMessage());
        }
        return null;
    }

    /**
     * Finds all invoices for a user with pagination.
     *
     * @param int $user_id
     * @param int $limit
     * @param int $offset
     * @return array
     */
    public function findAllForUser(int $user_id, int $limit, int $offset): array
    {
        try {
            $sql = "SELECT i.id, i.invoice_number, i.invoice_date, i.total_amount, i.status, c.name as client_name
                    FROM invoices i
                    LEFT JOIN clients c ON i.client_id = c.id
                    WHERE i.user_id = :user_id
                    ORDER BY i.invoice_date DESC, i.id DESC
                    LIMIT :limit OFFSET :offset";
            $stmt = $this->db->query($sql, [
                'user_id' => $user_id, 'limit' => $limit, 'offset' => $offset
            ]);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("Error finding all invoices for user {$user_id}: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Counts the total number of invoices for a user.
     *
     * @param int $user_id
     * @return int
     */
    public function countForUser(int $user_id): int
    {
        try {
            $stmt = $this->db->query("SELECT COUNT(*) FROM invoices WHERE user_id = :user_id", ['user_id' => $user_id]);
            return (int)$stmt->fetchColumn();
        } catch (PDOException $e) {
            error_log("Error counting invoices for user {$user_id}: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * Saves the entire invoice object (header and items) to the database.
     * Uses a transaction to ensure data integrity.
     *
     * @return bool True on success, false on failure.
     */
    public function save(): bool
    {
        $this->db->beginTransaction();
        try {
            if ($this->id) { // Update
                $sql = "UPDATE invoices SET 
                            client_id = :client_id, invoice_date = :invoice_date, due_date = :due_date, status = :status,
                            subtotal = :subtotal, discount_rate = :discount_rate, discount_amount = :discount_amount,
                            cgst_rate = :cgst_rate, sgst_rate = :sgst_rate, igst_rate = :igst_rate,
                            cgst_amount = :cgst_amount, sgst_amount = :sgst_amount, igst_amount = :igst_amount,
                            total_amount = :total_amount, advance_paid = :advance_paid, hsn_code = :hsn_code,
                            po_number = :po_number, notes = :notes, bank_account_id = :bank_account_id
                        WHERE id = :id AND user_id = :user_id";
            } else { // Create
                $this->invoice_number = $this->generateNextInvoiceNumber($this->user_id);
                $sql = "INSERT INTO invoices (user_id, client_id, invoice_number, invoice_date, due_date, status, subtotal, discount_rate, discount_amount, cgst_rate, sgst_rate, igst_rate, cgst_amount, sgst_amount, igst_amount, total_amount, advance_paid, hsn_code, po_number, notes, bank_account_id)
                        VALUES (:user_id, :client_id, :invoice_number, :invoice_date, :due_date, :status, :subtotal, :discount_rate, :discount_amount, :cgst_rate, :sgst_rate, :igst_rate, :cgst_amount, :sgst_amount, :igst_amount, :total_amount, :advance_paid, :hsn_code, :po_number, :notes, :bank_account_id)";
            }

            $this->db->query($sql, $this->getPropertiesAsArray());

            if (!$this->id) {
                $this->id = $this->db->lastInsertId();
            }

            // --- Manage Invoice Items ---
            // 1. Delete all existing items for this invoice (simplest approach for updates)
            $this->db->query("DELETE FROM invoice_items WHERE invoice_id = :id", ['id' => $this->id]);

            // 2. Insert the new items
            $itemSql = "INSERT INTO invoice_items (invoice_id, product_id, description, quantity, rate, amount) 
                        VALUES (:invoice_id, :product_id, :description, :quantity, :rate, :amount)";
            foreach ($this->items as $item) {
                $this->db->query($itemSql, [
                    'invoice_id' => $this->id,
                    'product_id' => $item['product_id'] ?? null,
                    'description' => $item['description'],
                    'quantity' => $item['quantity'],
                    'rate' => $item['rate'],
                    'amount' => $item['amount'],
                ]);
            }
            
            $this->db->commit();
            return true;

        } catch (PDOException $e) {
            $this->db->rollBack();
            error_log("Error saving invoice for user {$this->user_id}: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Generates the next sequential invoice number based on the Indian Financial Year.
     * Format: YY-YY-XXXX (e.g., 24-25-0001)
     *
     * @param int $user_id
     * @return string
     */
    public function generateNextInvoiceNumber(int $user_id): string
    {
        $current_month = (int)date('n');
        $current_year = (int)date('Y');
        
        $start_yy = ($current_month >= 4) ? date('y') : substr((string)($current_year - 1), -2);
        $end_yy = substr((string)($current_year + ($current_month >= 4 ? 1 : 0)), -2);

        $fy_prefix = $start_yy . "-" . $end_yy . "-";

        $sql = "SELECT invoice_number FROM invoices
                WHERE user_id = :user_id AND invoice_number LIKE :prefix
                ORDER BY invoice_number DESC LIMIT 1";
        
        $stmt = $this->db->query($sql, ['user_id' => $user_id, 'prefix' => $fy_prefix . '%']);
        $lastInvoice = $stmt->fetchColumn();
        
        $nextNumber = 1;
        if ($lastInvoice && preg_match('/-(\d{4})$/', $lastInvoice, $matches)) {
            $nextNumber = (int)$matches[1] + 1;
        }

        return $fy_prefix . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);
    }
    
    /**
     * Checks if a client has any associated invoices.
     * Used before deleting a client.
     * @param int $clientId
     * @return bool
     */
    public function hasInvoicesForClient(int $clientId): bool
    {
        $stmt = $this->db->query("SELECT 1 FROM invoices WHERE client_id = :client_id LIMIT 1", [
            'client_id' => $clientId
        ]);
        return $stmt->fetchColumn() !== false;
    }

    /**
     * Helper to get object properties as an associative array for PDO binding.
     * @return array
     */
    private function getPropertiesAsArray(): array
    {
        return [
            'id' => $this->id,
            'user_id' => $this->user_id,
            'client_id' => $this->client_id,
            'invoice_number' => $this->invoice_number,
            'invoice_date' => $this->invoice_date,
            'due_date' => $this->due_date,
            'status' => $this->status,
            'subtotal' => $this->subtotal,
            'discount_rate' => $this->discount_rate,
            'discount_amount' => $this->discount_amount,
            'cgst_rate' => $this->cgst_rate,
            'sgst_rate' => $this->sgst_rate,
            'igst_rate' => $this->igst_rate,
            'cgst_amount' => $this->cgst_amount,
            'sgst_amount' => $this->sgst_amount,
            'igst_amount' => $this->igst_amount,
            'total_amount' => $this->total_amount,
            'advance_paid' => $this->advance_paid,
            'hsn_code' => empty($this->hsn_code) ? null : $this->hsn_code,
            'po_number' => empty($this->po_number) ? null : $this->po_number,
            'notes' => empty($this->notes) ? null : $this->notes,
            'bank_account_id' => $this->bank_account_id,
        ];
    }
}