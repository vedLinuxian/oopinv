<?php

/**
 * =====================================================================================
 * Product Model Class
 * =====================================================================================
 *
 * This class represents a single product or service in the inventory.
 * It handles all database operations for the `products` table, ensuring that
 * actions are scoped to the logged-in user.
 *
 */

class Product
{
    /** @var Database The database connection instance. */
    private $db;

    // --- Product Properties ---
    public $id;
    public $user_id;
    public $name;
    public $description;
    public $hsn_code;
    public $price;
    public $stock_quantity;      // Can be null for services or untracked items
    public $low_stock_threshold; // Can be null if stock is not tracked

    /**
     * Product constructor.
     * @param Database $db The database instance.
     */
    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    /**
     * Loads a single product by its ID and User ID.
     *
     * @param int $id The product ID.
     * @param int $user_id The owner's user ID.
     * @return bool True if found and loaded, false otherwise.
     */
    public function load(int $id, int $user_id): bool
    {
        try {
            $stmt = $this->db->query("SELECT * FROM products WHERE id = :id AND user_id = :user_id", [
                'id' => $id, 'user_id' => $user_id
            ]);
            $data = $stmt->fetch();

            if ($data) {
                $this->id = (int)$data['id'];
                $this->user_id = (int)$data['user_id'];
                $this->name = $data['name'];
                $this->description = $data['description'];
                $this->hsn_code = $data['hsn_code'];
                $this->price = (float)$data['price'];
                // Handle nullable integer fields
                $this->stock_quantity = $data['stock_quantity'] !== null ? (int)$data['stock_quantity'] : null;
                $this->low_stock_threshold = $data['low_stock_threshold'] !== null ? (int)$data['low_stock_threshold'] : null;
                return true;
            }
        } catch (PDOException $e) {
            error_log("Error loading product ID {$id} for user {$user_id}: " . $e->getMessage());
        }
        return false;
    }
    
    /**
     * Finds all products for a user, with pagination and search.
     *
     * @param int $user_id The owner's user ID.
     * @param int $limit
     * @param int $offset
     * @param string $searchTerm
     * @return array
     */
    public function findAllForUser(int $user_id, int $limit, int $offset, string $searchTerm = ''): array
    {
        $params = ['user_id' => $user_id, 'limit' => $limit, 'offset' => $offset];
        $sql = "SELECT * FROM products WHERE user_id = :user_id";

        if (!empty($searchTerm)) {
            $sql .= " AND (name LIKE :search OR description LIKE :search OR hsn_code LIKE :search)";
            $params['search'] = "%" . $searchTerm . "%";
        }

        $sql .= " ORDER BY name ASC LIMIT :limit OFFSET :offset";

        try {
            $stmt = $this->db->query($sql, $params);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("Error finding all products for user {$user_id}: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Counts the total number of products for a user.
     *
     * @param int $user_id
     * @param string $searchTerm
     * @return int
     */
    public function countForUser(int $user_id, string $searchTerm = ''): int
    {
        $params = ['user_id' => $user_id];
        $sql = "SELECT COUNT(*) FROM products WHERE user_id = :user_id";

        if (!empty($searchTerm)) {
            $sql .= " AND (name LIKE :search OR description LIKE :search OR hsn_code LIKE :search)";
            $params['search'] = "%" . $searchTerm . "%";
        }
        
        try {
            $stmt = $this->db->query($sql, $params);
            return (int)$stmt->fetchColumn();
        } catch (PDOException $e) {
            error_log("Error counting products for user {$user_id}: " . $e->getMessage());
            return 0;
        }
    }

    /**
     * Saves the product to the database (creates or updates).
     *
     * @return bool True on success, false on failure.
     */
    public function save(): bool
    {
        if (empty($this->name) || empty($this->user_id)) {
            return false;
        }

        try {
            if ($this->id) { // Update
                $sql = "UPDATE products SET
                            name = :name, description = :description, hsn_code = :hsn_code,
                            price = :price, stock_quantity = :stock_quantity,
                            low_stock_threshold = :low_stock_threshold
                        WHERE id = :id AND user_id = :user_id";
                
                $this->db->query($sql, $this->getPropertiesAsArray());

            } else { // Create
                $sql = "INSERT INTO products (user_id, name, description, hsn_code, price, stock_quantity, low_stock_threshold)
                        VALUES (:user_id, :name, :description, :hsn_code, :price, :stock_quantity, :low_stock_threshold)";
                
                $params = $this->getPropertiesAsArray();
                unset($params['id']);
                
                $this->db->query($sql, $params);
                $this->id = $this->db->lastInsertId();
            }
            return true;
        } catch (PDOException $e) {
            error_log("Error saving product for user {$this->user_id}: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Deletes the product from the database.
     *
     * @return bool True on success, false on failure.
     */
    public function delete(): bool
    {
        if (!$this->id || !$this->user_id) {
            return false;
        }
        
        try {
            $this->db->query("DELETE FROM products WHERE id = :id AND user_id = :user_id", [
                'id' => $this->id, 'user_id' => $this->user_id
            ]);
            return true;
        } catch (PDOException $e) {
            error_log("Error deleting product ID {$this->id}: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Finds all products that are at or below their low stock threshold.
     *
     * @param int $user_id The owner's user ID.
     * @return array An array of products that need reordering.
     */
    public function findLowStockProducts(int $user_id): array
    {
        $sql = "SELECT id, name, stock_quantity, low_stock_threshold
                FROM products
                WHERE user_id = :user_id
                  AND stock_quantity IS NOT NULL
                  AND low_stock_threshold IS NOT NULL
                  AND stock_quantity <= low_stock_threshold
                ORDER BY name ASC";
        
        try {
            $stmt = $this->db->query($sql, ['user_id' => $user_id]);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("Error finding low stock products for user {$user_id}: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Helper to get object properties as an array for PDO binding.
     * @return array
     */
    private function getPropertiesAsArray(): array
    {
        return [
            'id' => $this->id,
            'user_id' => $this->user_id,
            'name' => trim($this->name),
            'description' => empty(trim($this->description)) ? null : trim($this->description),
            'hsn_code' => empty(trim($this->hsn_code)) ? null : trim($this->hsn_code),
            'price' => (float)$this->price,
            'stock_quantity' => $this->stock_quantity === '' ? null : (int)$this->stock_quantity,
            'low_stock_threshold' => $this->low_stock_threshold === '' ? null : (int)$this->low_stock_threshold,
        ];
    }
}