<?php

/**
 * =====================================================================================
 * Authentication and Authorization Class
 * =====================================================================================
 *
 * This class handles all aspects of user authentication (who they are) and
 * authorization (what they are allowed to do).
 *
 * Key Features:
 * - Secure login verification using PHP's native password hashing functions.
 * - Session management to track logged-in users.
 * - Role-Based Access Control (RBAC) to manage permissions.
 * - Easy-to-use methods for protecting pages and features.
 *
 * --- How to Use ---
 * // At the top of a protected page:
 * $auth = new Auth(Database::getInstance());
 * $auth->requireLogin();
 * $currentUser = $auth->getUser(); // Get details of the logged-in user
 *
 * // Checking for a specific permission before showing a button or performing an action:
 * if ($auth->can('delete_invoice')) {
 *     echo '<button>Delete Invoice</button>';
 * }
 *
 */

class Auth
{
    /**
     * @var Database The database connection instance.
     */
    private $db;

    /**
     * @var array|null The currently logged-in user's data.
     */
    private $user = null;

    /**
     * Auth constructor.
     * @param Database $db The database instance.
     */
    public function __construct(Database $db)
    {
        $this->db = $db;

        // Automatically load user data from the session if a user is logged in.
        if (isset($_SESSION['user_id'])) {
            $this->user = $this->findUserById($_SESSION['user_id']);
        }
    }

    /**
     * Attempts to log in a user with the given username and password.
     *
     * @param string $username The user's username.
     * @param string $password The user's plain-text password.
     * @return User|null The User object on success, or null on failure.
     */
    public function login(string $username, string $password): ?User
    {
        // Find the user by username first.
        $stmt = $this->db->query("SELECT * FROM users WHERE username = :username", [
            'username' => $username
        ]);
        $user_data = $stmt->fetch();

        // If a user is found and the password verifies...
        if ($user_data && password_verify($password, $user_data['password'])) {
            // Important: Regenerate session ID to prevent session fixation.
            session_regenerate_id(true);

            // Store user ID in session to persist the login.
            $_SESSION['user_id'] = $user_data['id'];

            // Populate the internal user property with a User object.
            $this->user = new User($this->db);
            $this->user->load($user_data['id']); // Assumes a load() method in User class
            return $this->user;
        }

        // Return null if login fails.
        return null;
    }

    /**
     * Logs the current user out by destroying the session.
     */
    public function logout(): void
    {
        // Unset all session variables.
        $_SESSION = [];

        // If it's desired to kill the session, also delete the session cookie.
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }

        // Finally, destroy the session.
        session_destroy();

        $this->user = null;
    }

    /**
     * Checks if a user is currently logged in.
     *
     * @return bool True if a user is logged in, false otherwise.
     */
    public function isLoggedIn(): bool
    {
        return $this->user !== null;
    }

    /**
     * If the user is not logged in, redirects them to the login page.
     * This is used to protect entire pages.
     */
    public function requireLogin(): void
    {
        if (!$this->isLoggedIn()) {
            // Assuming BASE_URL is defined in config.php
            header('Location: ' . BASE_URL . 'login.php');
            exit();
        }
    }

    /**
     * Returns the currently logged-in user object.
     *
     * @return User|null The User object if logged in, or null.
     */
    public function getUser(): ?User
    {
        return $this->user;
    }

    /**
     * Checks if the current user has a specific permission.
     * This is the core of our RBAC (Role-Based Access Control).
     *
     * @param string $permission The permission to check (e.g., 'delete_invoice').
     * @return bool True if the user has the permission, false otherwise.
     */
    public function can(string $permission): bool
    {
        if (!$this->isLoggedIn()) {
            return false;
        }
        
        // This relies on the User object having a method to check its own permissions.
        // The implementation details will be in the User and Role classes.
        return $this->user->hasPermission($permission);
    }

    /**
     * A helper to find a user by their ID. Used for session initialization.
     *
     * @param int $id The user ID.
     * @return User|null A User object if found, or null.
     */
    private function findUserById(int $id): ?User
    {
        // Instantiate a new User object and attempt to load its data from the DB.
        $user = new User($this->db);
        if ($user->load($id)) {
            return $user;
        }
        return null;
    }
}