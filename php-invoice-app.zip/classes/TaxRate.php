<?php
/**
 * =====================================================================================
 * TaxRate Model Class
 * =====================================================================================
 *
 * This class represents a single configurable tax rate (GST slab). It's responsible for
 * all CRUD operations for the `tax_rates` table, scoped to the user.
 *
 */

class TaxRate
{
    /** @var Database The database connection instance. */
    private $db;

    // --- TaxRate Properties ---
    public $id;
    public $user_id;
    public $name;
    public $rate;
    public $is_default;


    /**
     * TaxRate constructor.
     * @param Database $db The database instance.
     */
    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    /**
     * Loads a single tax rate by its ID and User ID.
     *
     * @param int $id The tax rate ID.
     * @param int $user_id The owner's user ID.
     * @return bool True if found and loaded, false otherwise.
     */
    public function load(int $id, int $user_id): bool
    {
        try {
            $stmt = $this->db->query("SELECT * FROM tax_rates WHERE id = :id AND user_id = :user_id", [
                'id' => $id, 'user_id' => $user_id
            ]);
            $data = $stmt->fetch();

            if ($data) {
                $this->id = (int)$data['id'];
                $this->user_id = (int)$data['user_id'];
                $this->name = $data['name'];
                $this->rate = (float)$data['rate'];
                $this->is_default = (bool)$data['is_default'];
                return true;
            }
        } catch (PDOException $e) {
            error_log("Error loading tax rate ID {$id} for user {$user_id}: " . $e->getMessage());
        }
        return false;
    }

    /**
     * Finds all tax rates for a specific user.
     *
     * @param int $user_id The owner's user ID.
     * @return array An array of tax rate records.
     */
    public static function findAllForUser(Database $db, int $user_id): array
    {
        try {
            // Order by `is_default` descending to show the default rate first.
            $stmt = $db->query("SELECT * FROM tax_rates WHERE user_id = :user_id ORDER BY is_default DESC, rate ASC", [
                'user_id' => $user_id
            ]);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("Error finding all tax rates for user {$user_id}: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Saves the tax rate to the database (creates or updates).
     *
     * @return bool True on success, false on failure.
     */
    public function save(): bool
    {
        if (empty($this->name) || !is_numeric($this->rate) || empty($this->user_id)) {
            return false;
        }

        try {
            // If setting this rate as default, we must first unset any other default rate for this user.
            if ($this->is_default) {
                $this->db->query("UPDATE tax_rates SET is_default = 0 WHERE user_id = :user_id", [
                    'user_id' => $this->user_id
                ]);
            }
            
            if ($this->id) { // Update
                $sql = "UPDATE tax_rates SET 
                            name = :name, 
                            rate = :rate,
                            is_default = :is_default
                        WHERE id = :id AND user_id = :user_id";
                $params = $this->getPropertiesAsArray();
            } else { // Create
                $sql = "INSERT INTO tax_rates (user_id, name, rate, is_default) 
                        VALUES (:user_id, :name, :rate, :is_default)";
                $params = $this->getPropertiesAsArray();
                unset($params['id']);
            }
            
            $this->db->query($sql, $params);

            if (!$this->id) {
                $this->id = $this->db->lastInsertId();
            }
            return true;
        } catch (PDOException $e) {
            error_log("Error saving tax rate for user {$this->user_id}: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Deletes the tax rate from the database.
     *
     * @return bool True on success, false on failure.
     */
    public function delete(): bool
    {
        if (!$this->id || !$this->user_id) {
            return false;
        }

        try {
            $this->db->query("DELETE FROM tax_rates WHERE id = :id AND user_id = :user_id", [
                'id' => $this->id, 'user_id' => $this->user_id
            ]);
            return true;
        } catch (PDOException $e) {
            error_log("Error deleting tax rate ID {$this->id}: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Helper to get object properties as an array for PDO binding.
     * @return array
     */
    private function getPropertiesAsArray(): array
    {
        return [
            'id' => $this->id,
            'user_id' => $this->user_id,
            'name' => trim($this->name),
            'rate' => (float)$this->rate,
            'is_default' => $this->is_default ? 1 : 0
        ];
    }
}