<?php

/**
 * =====================================================================================
 * Database Class (Singleton Pattern)
 * =====================================================================================
 *
 * This class handles all database connections and queries for the application.
 *
 * Key Features:
 * - Uses PDO (PHP Data Objects) for a modern, secure, and flexible database layer.
 * - Implements the Singleton design pattern to ensure only one database connection
 *   is ever established per request, saving resources.
 * - Enforces the use of PREPARED STATEMENTS to prevent SQL injection vulnerabilities.
 * - Provides simple methods for executing queries and handling transactions.
 *
 * --- How to Use ---
 * // 1. Get the single instance of the database connection
 * $db = Database::getInstance();
 *
 * // 2. Execute a query with parameters
 * $stmt = $db->query("SELECT * FROM users WHERE id = :id", ['id' => 1]);
 *
 * // 3. Fetch results
 * $user = $stmt->fetch(); // For a single row
 * $all_users = $stmt->fetchAll(); // For all rows
 *
 */

class Database
{
    /**
     * @var Database|null The single instance of the class.
     */
    private static $instance = null;

    /**
     * @var PDO The PDO connection object.
     */
    private $pdo;

    /**
     * Private constructor to prevent creating a new instance with the 'new' operator.
     * Establishes the database connection using credentials from config.php.
     */
    private function __construct()
    {
        // Data Source Name (DSN) contains the information required to connect to the database.
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;

        // Set PDO options for our connection.
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // Throw exceptions on SQL errors.
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // Fetch associative arrays by default.
            PDO::ATTR_EMULATE_PREPARES   => false,                  // Use native prepared statements for better security.
        ];

        try {
            // Create the PDO instance.
            $this->pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (\PDOException $e) {
            // Handle connection errors gracefully.
            if (ENVIRONMENT === 'development') {
                // In development, we can show the detailed error.
                throw new \PDOException($e->getMessage(), (int)$e->getCode());
            } else {
                // In production, log the error and show a generic message.
                error_log("DATABASE CONNECTION ERROR: " . $e->getMessage());
                // Use a plain die() here because our error rendering system may rely on the DB.
                die('A database error occurred. Please contact support.');
            }
        }
    }

    /**
     * The method to get the single instance of the Database class.
     *
     * @return Database The single Database instance.
     */
    public static function getInstance(): Database
    {
        if (self::$instance === null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    /**
     * A general-purpose method for executing prepared SQL queries.
     *
     * @param string $sql The SQL query to execute with named placeholders (e.g., :id).
     * @param array $params An associative array of parameters to bind to the query.
     * @return PDOStatement The PDOStatement object.
     */
    public function query(string $sql, array $params = []): PDOStatement
    {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    /**
     * Starts a new database transaction.
     *
     * @return bool TRUE on success or FALSE on failure.
     */
    public function beginTransaction(): bool
    {
        return $this->pdo->beginTransaction();
    }

    /**
     * Commits the current transaction.
     *
     * @return bool TRUE on success or FALSE on failure.
     */
    public function commit(): bool
    {
        return $this->pdo->commit();
    }

    /**
     * Rolls back the current transaction.
     *
     * @return bool TRUE on success or FALSE on failure.
     */
    public function rollBack(): bool
    {
        return $this->pdo->rollBack();
    }

    /**
     * Returns the ID of the last inserted row.
     *
     * @return string|false The ID of the last inserted row, or false on failure.
     */
    public function lastInsertId()
    {
        return $this->pdo->lastInsertId();
    }

    /**
     * Private clone method to prevent cloning of the instance.
     */
    private function __clone() {}

    /**
     * Private wakeup method to prevent unserialization of the instance.
     */
    public function __wakeup() {}
}