<?php
/**
 * =====================================================================================
 * GST Handler Service Class
 * =====================================================================================
 *
 * This class encapsulates the business logic for determining the correct GST
 * treatment for a transaction based on the location of the business and the client.
 *
 * Key Responsibilities:
 * - Determines if a transaction is Intra-State (within the same state) or
 *   Inter-State (between different states).
 * - Calculates the breakdown of a total tax rate into CGST, SGST, and IGST.
 *
 * This is a "service" class – it doesn't represent a database table but provides
 * a specific, reusable piece of business logic.
 *
 * --- How to Use ---
 * $gstHandler = new GstHandler(BUSINESS_HOME_STATE); // From config.php
 * $taxDetails = $gstHandler->calculateTaxes(18.00, 'Maharashtra');
 * // $taxDetails might be: ['cgst_rate' => 9.00, 'sgst_rate' => 9.00, 'igst_rate' => 0]
 *
 * $taxDetails = $gstHandler->calculateTaxes(12.00, 'Delhi');
 * // $taxDetails might be: ['cgst_rate' => 0, 'sgst_rate' => 0, 'igst_rate' => 12.00]
 *
 */

class GstHandler
{
    /**
     * @var string The state where the business is located.
     */
    private $businessHomeState;

    /**
     * GstHandler constructor.
     * @param string $businessHomeState The state of the primary business, from config.
     */
    public function __construct(string $businessHomeState)
    {
        // Normalize the state name for reliable comparison (lowercase, trim)
        $this->businessHomeState = strtolower(trim($businessHomeState));
    }

    /**
     * Determines if a transaction is Intra-State (within the same state).
     *
     * @param string $clientState The state of the client.
     * @return bool True if the transaction is Intra-State, false otherwise.
     */
    public function isIntraState(string $clientState): bool
    {
        $normalizedClientState = strtolower(trim($clientState));

        // If either state is empty, we can't make a determination.
        // Defaulting to true (CGST/SGST) is often a safe fallback,
        // but it's better if states are always provided.
        if (empty($this->businessHomeState) || empty($normalizedClientState)) {
            // Log a warning if states are missing
            error_log("GST Calculation Warning: Business state or client state is empty.");
            return true; // Fallback assumption
        }

        return $this->businessHomeState === $normalizedClientState;
    }

    /**
     * Calculates the breakdown of a total tax rate into CGST, SGST, and IGST.
     *
     * @param float $totalTaxRate The combined tax rate (e.g., 18.00 for 18%).
     * @param string $clientState The state of the client.
     * @return array An associative array containing 'cgst_rate', 'sgst_rate', and 'igst_rate'.
     */
    public function calculateTaxes(float $totalTaxRate, string $clientState): array
    {
        $rates = [
            'cgst_rate' => 0.00,
            'sgst_rate' => 0.00,
            'igst_rate' => 0.00
        ];

        // Sanity check for the tax rate
        if ($totalTaxRate <= 0) {
            return $rates;
        }

        if ($this->isIntraState($clientState)) {
            // Intra-State transaction: Apply CGST and SGST
            $rates['cgst_rate'] = $totalTaxRate / 2;
            $rates['sgst_rate'] = $totalTaxRate / 2;
        } else {
            // Inter-State transaction: Apply IGST
            $rates['igst_rate'] = $totalTaxRate;
        }
        
        return $rates;
    }

    /**
     * Static helper to get a list of Indian States and Union Territories.
     * Includes their GST state codes.
     *
     * @return array
     */
    public static function getIndianStates(): array
    {
        // Source: Official GSTN List
        return [
            "Andhra Pradesh" => "37", "Arunachal Pradesh" => "12", "Assam" => "18",
            "Bihar" => "10", "Chhattisgarh" => "22", "Goa" => "30",
            "Gujarat" => "24", "Haryana" => "06", "Himachal Pradesh" => "02",
            "Jharkhand" => "20", "Karnataka" => "29", "Kerala" => "32",
            "Madhya Pradesh" => "23", "Maharashtra" => "27", "Manipur" => "14",
            "Meghalaya" => "17", "Mizoram" => "15", "Nagaland" => "13",
            "Odisha" => "21", "Punjab" => "03", "Rajasthan" => "08",
            "Sikkim" => "11", "Tamil Nadu" => "33", "Telangana" => "36",
            "Tripura" => "16", "Uttar Pradesh" => "09", "Uttarakhand" => "05",
            "West Bengal" => "19", "Andaman and Nicobar Islands" => "35",
            "Chandigarh" => "04", "Dadra and Nagar Haveli and Daman and Diu" => "26",
            "Delhi" => "07", "Jammu and Kashmir" => "01", "Ladakh" => "38",
            "Lakshadweep" => "31", "Puducherry" => "34", "Other Territory" => "97"
        ];
    }
}