<?php

/**
 * =====================================================================================
 * Company Model Class
 * =====================================================================================
 *
 * This class represents the user's company information. It handles loading, saving,
 * and managing the data and associated file uploads for the single business profile
 * tied to a user account.
 *
 */

class Company
{
    /** @var Database The database connection instance. */
    private $db;

    // --- Company Properties ---
    public $id;
    public $user_id;
    public $name;
    public $address;
    public $phone;
    public $email;
    public $website;
    public $gstin;
    public $upi_qr_code_path;
    public $stamp_path;
    public $default_notes;
    
    // Constants for file uploads
    private const UPLOAD_DIR_QR = 'uploads/qr_codes/';
    private const UPLOAD_DIR_STAMP = 'uploads/stamps/';
    private const MAX_FILE_SIZE = 1048576; // 1 MB
    private const ALLOWED_MIMES = ['image/jpeg', 'image/png', 'image/gif'];


    /**
     * Company constructor.
     * @param Database $db The database instance.
     */
    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    /**
     * Loads the company details associated with a given user ID.
     *
     * @param int $user_id The ID of the user whose company to load.
     * @return bool True if company details were found and loaded, false otherwise.
     */
    public function loadByUser(int $user_id): bool
    {
        try {
            $stmt = $this->db->query("SELECT * FROM companies WHERE user_id = :user_id LIMIT 1", [
                'user_id' => $user_id
            ]);
            $data = $stmt->fetch();

            if ($data) {
                $this->id = (int)$data['id'];
                $this->user_id = (int)$data['user_id'];
                $this->name = $data['name'];
                $this->address = $data['address'];
                $this->phone = $data['phone'];
                $this->email = $data['email'];
                $this->website = $data['website'];
                $this->gstin = $data['gstin'];
                $this->upi_qr_code_path = $data['upi_qr_code_path'];
                $this->stamp_path = $data['stamp_path'];
                $this->default_notes = $data['default_notes'];
                return true;
            }
        } catch (PDOException $e) {
            error_log("Error loading company for user {$user_id}: " . $e->getMessage());
        }
        return false;
    }

    /**
     * Saves the company record (creates if new, updates if exists).
     * This method also orchestrates file uploads and removals.
     *
     * @return bool True on success, false on failure.
     * @throws Exception On file upload errors.
     */
    public function save(): bool
    {
        $this->handleFileUploads();

        try {
            if ($this->id) {
                // Update existing record
                $sql = "UPDATE companies SET 
                            name = :name, address = :address, phone = :phone, email = :email, 
                            website = :website, gstin = :gstin, upi_qr_code_path = :upi_qr_code_path, 
                            stamp_path = :stamp_path, default_notes = :default_notes
                        WHERE id = :id AND user_id = :user_id";
                $params = $this->getPropertiesAsArray();
                $params['id'] = $this->id;

            } else {
                // Insert new record
                $sql = "INSERT INTO companies (user_id, name, address, phone, email, website, gstin, upi_qr_code_path, stamp_path, default_notes) 
                        VALUES (:user_id, :name, :address, :phone, :email, :website, :gstin, :upi_qr_code_path, :stamp_path, :default_notes)";
                $params = $this->getPropertiesAsArray();
            }

            $this->db->query($sql, $params);
            
            if (!$this->id) {
                $this->id = $this->db->lastInsertId();
            }
            return true;

        } catch (PDOException $e) {
            error_log("Error saving company for user {$this->user_id}: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Handles processing of file uploads (QR code and stamp).
     * Manages removal of old files and validation of new ones.
     *
     * @throws Exception If an upload fails validation or cannot be moved.
     */
    private function handleFileUploads()
    {
        // Handle QR code removal/upload
        if (!empty($_POST['remove_qr']) && $this->upi_qr_code_path) {
            $this->deleteFile($this->upi_qr_code_path);
            $this->upi_qr_code_path = null;
        }
        if (isset($_FILES['upi_qr_code']) && $_FILES['upi_qr_code']['error'] === UPLOAD_ERR_OK) {
            $this->upi_qr_code_path = $this->processUpload($_FILES['upi_qr_code'], self::UPLOAD_DIR_QR, $this->upi_qr_code_path);
        }

        // Handle Stamp removal/upload
        if (!empty($_POST['remove_stamp']) && $this->stamp_path) {
            $this->deleteFile($this->stamp_path);
            $this->stamp_path = null;
        }
        if (isset($_FILES['stamp']) && $_FILES['stamp']['error'] === UPLOAD_ERR_OK) {
            $this->stamp_path = $this->processUpload($_FILES['stamp'], self::UPLOAD_DIR_STAMP, $this->stamp_path);
        }
    }

    /**
     * Processes a single file upload. Validates, moves, and returns the new path.
     *
     * @param array $file The $_FILES['...'] array for the upload.
     * @param string $uploadDir The target directory constant.
     * @param string|null $oldFilePath The path of the old file to be replaced and deleted.
     * @return string The new path of the uploaded file.
     * @throws Exception
     */
    private function processUpload(array $file, string $uploadDir, ?string $oldFilePath): string
    {
        if ($file['size'] > self::MAX_FILE_SIZE) {
            throw new Exception("File is too large. Maximum size is 1MB.");
        }
        
        $mime_type = mime_content_type($file['tmp_name']);
        if (!in_array($mime_type, self::ALLOWED_MIMES)) {
            throw new Exception("Invalid file type. Only JPG, PNG, and GIF are allowed.");
        }

        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $newFilename = uniqid('file_', true) . '.' . strtolower($extension);
        $destination = $uploadDir . $newFilename;
        
        // Ensure upload directory exists
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        if (move_uploaded_file($file['tmp_name'], $destination)) {
            // Delete the old file if a new one was successfully uploaded
            if ($oldFilePath) {
                $this->deleteFile($oldFilePath);
            }
            return $destination;
        } else {
            throw new Exception("Failed to move uploaded file.");
        }
    }
    
    /**
     * Safely deletes a file if it exists.
     * @param string $filePath
     */
    private function deleteFile(string $filePath): void
    {
        if (file_exists($filePath)) {
            @unlink($filePath);
        }
    }

    /**
     * Helper to get object properties as an array for database binding.
     * @return array
     */
    private function getPropertiesAsArray(): array
    {
        return [
            'user_id' => $this->user_id,
            'name' => $this->name,
            'address' => $this->address,
            'phone' => $this->phone,
            'email' => $this->email,
            'website' => $this->website,
            'gstin' => $this->gstin,
            'upi_qr_code_path' => $this->upi_qr_code_path,
            'stamp_path' => $this->stamp_path,
            'default_notes' => $this->default_notes,
        ];
    }
}