<?php
/**
 * =====================================================================================
 * Bank Model Class
 * =====================================================================================
 *
 * This class represents a single bank account belonging to a user.
 * It is responsible for all CRUD (Create, Read, Update, Delete) operations for the
 * `user_banks` table, ensuring that all operations are scoped to the currently
 * logged-in user.
 *
 */

class Bank
{
    /** @var Database The database connection instance. */
    private $db;

    // --- Bank Properties ---
    public $id;
    public $user_id;
    public $bank_name;
    public $account_holder_name;
    public $account_number;
    public $ifsc_code;
    public $branch_name;
    public $upi_id;


    /**
     * Bank constructor.
     * @param Database $db The database instance.
     */
    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    /**
     * Loads a single bank account by its ID and User ID.
     *
     * @param int $id The bank account ID.
     * @param int $user_id The owner's user ID.
     * @return bool True if found and loaded, false otherwise.
     */
    public function load(int $id, int $user_id): bool
    {
        try {
            $stmt = $this->db->query("SELECT * FROM user_banks WHERE id = :id AND user_id = :user_id", [
                'id' => $id, 'user_id' => $user_id
            ]);
            $data = $stmt->fetch();

            if ($data) {
                $this->id = (int)$data['id'];
                $this->user_id = (int)$data['user_id'];
                $this->bank_name = $data['bank_name'];
                $this->account_holder_name = $data['account_holder_name'];
                $this->account_number = $data['account_number'];
                $this->ifsc_code = $data['ifsc_code'];
                $this->branch_name = $data['branch_name'];
                $this->upi_id = $data['upi_id'];
                return true;
            }
        } catch (PDOException $e) {
            error_log("Error loading bank ID {$id} for user {$user_id}: " . $e->getMessage());
        }
        return false;
    }

    /**
     * Finds all bank accounts for a specific user.
     *
     * @param int $user_id The owner's user ID.
     * @return array An array of bank account records.
     */
    public function findAllForUser(int $user_id): array
    {
        try {
            $stmt = $this->db->query(
                "SELECT * FROM user_banks WHERE user_id = :user_id ORDER BY bank_name ASC",
                ['user_id' => $user_id]
            );
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("Error finding all banks for user {$user_id}: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Saves the bank account to the database (creates or updates).
     *
     * @return bool True on success, false on failure.
     */
    public function save(): bool
    {
        if (empty($this->bank_name) || empty($this->account_number) || empty($this->ifsc_code) || empty($this->user_id)) {
            return false;
        }

        try {
            if ($this->id) { // Update
                $sql = "UPDATE user_banks SET 
                            bank_name = :bank_name, account_holder_name = :account_holder_name,
                            account_number = :account_number, ifsc_code = :ifsc_code,
                            branch_name = :branch_name, upi_id = :upi_id
                        WHERE id = :id AND user_id = :user_id";
            } else { // Create
                $sql = "INSERT INTO user_banks (user_id, bank_name, account_holder_name, account_number, ifsc_code, branch_name, upi_id)
                        VALUES (:user_id, :bank_name, :account_holder_name, :account_number, :ifsc_code, :branch_name, :upi_id)";
            }
            
            $params = $this->getPropertiesAsArray();
            if (!$this->id) unset($params['id']);

            $this->db->query($sql, $params);

            if (!$this->id) {
                $this->id = $this->db->lastInsertId();
            }
            return true;
        } catch (PDOException $e) {
            error_log("Error saving bank for user {$this->user_id}: " . $e->getMessage());
            // Check for unique constraint violation
            if ($e->getCode() == 23000) {
                 // Potentially throw a custom exception here for the API handler to catch.
                 // For now, returning false is sufficient.
            }
            return false;
        }
    }

    /**
     * Deletes the bank account from the database.
     *
     * @return bool True on success, false on failure.
     */
    public function delete(): bool
    {
        if (!$this->id || !$this->user_id) {
            return false;
        }

        try {
            // Unlink this bank from any invoices that use it
            $this->db->query("UPDATE invoices SET bank_account_id = NULL WHERE bank_account_id = :bank_id AND user_id = :user_id", [
                'bank_id' => $this->id, 'user_id' => $this->user_id
            ]);

            // Now, delete the bank record itself
            $this->db->query("DELETE FROM user_banks WHERE id = :id AND user_id = :user_id", [
                'id' => $this->id, 'user_id' => $this->user_id
            ]);
            
            return true;
        } catch (PDOException $e) {
            error_log("Error deleting bank ID {$this->id}: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Helper to get object properties as an associative array for PDO binding.
     * @return array
     */
    private function getPropertiesAsArray(): array
    {
        return [
            'id' => $this->id,
            'user_id' => $this->user_id,
            'bank_name' => trim($this->bank_name),
            'account_holder_name' => empty(trim($this->account_holder_name)) ? null : trim($this->account_holder_name),
            'account_number' => trim($this->account_number),
            'ifsc_code' => trim($this->ifsc_code),
            'branch_name' => empty(trim($this->branch_name)) ? null : trim($this->branch_name),
            'upi_id' => empty(trim($this->upi_id)) ? null : trim($this->upi_id),
        ];
    }
}