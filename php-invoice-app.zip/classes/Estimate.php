<?php
/**
 * =====================================================================================
 * Estimate Model Class
 * =====================================================================================
 *
 * This class represents a single estimate/quotation and is responsible for all database
 * operations related to estimates and their line items.
 *
 */

class Estimate
{
    /** @var Database The database connection instance. */
    private $db;

    // --- Estimate Properties (similar to Invoice) ---
    public $id;
    public $user_id;
    public $client_id;
    public $invoice_id; // To link if converted
    public $estimate_number;
    public $estimate_date;
    public $expiry_date;
    public $status; // 'draft', 'sent', 'accepted', 'rejected', 'invoiced'

    // Financials
    public $subtotal = 0.00;
    public $discount_rate = 0.00;
    public $discount_amount = 0.00;
    public $cgst_rate = 0.00;
    public $sgst_rate = 0.00;
    public $igst_rate = 0.00;
    public $cgst_amount = 0.00;
    public $sgst_amount = 0.00;
    public $igst_amount = 0.00;
    public $total_amount = 0.00;

    // Other Details
    public $hsn_code;
    public $po_number;
    public $notes;

    /** @var array Array of estimate line items. */
    public $items = [];

    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    /**
     * Loads a single estimate by its ID and User ID.
     * Also loads its associated line items.
     *
     * @param int $id The estimate ID.
     * @param int $user_id The owner's user ID.
     * @return array|null An associative array of estimate data, or null.
     */
    public function findByIdForUser(int $id, int $user_id): ?array
    {
        try {
            $sql = "SELECT e.*, c.name as client_name 
                    FROM estimates e 
                    JOIN clients c ON e.client_id = c.id
                    WHERE e.id = :id AND e.user_id = :user_id";
            $stmt = $this->db->query($sql, ['id' => $id, 'user_id' => $user_id]);
            $estimateData = $stmt->fetch();

            if ($estimateData) {
                $itemStmt = $this->db->query("SELECT * FROM estimate_items WHERE estimate_id = :id ORDER BY id ASC", ['id' => $id]);
                $estimateData['items'] = $itemStmt->fetchAll();
                return $estimateData;
            }
        } catch (PDOException $e) {
            error_log("Error finding estimate ID {$id}: " . $e->getMessage());
        }
        return null;
    }

    /**
     * Finds all estimates for a user with pagination.
     *
     * @param int $user_id
     * @param int $limit
     * @param int $offset
     * @return array
     */
    public function findAllForUser(int $user_id, int $limit, int $offset): array
    {
        try {
            $sql = "SELECT e.id, e.estimate_number, e.estimate_date, e.total_amount, e.status, c.name as client_name
                    FROM estimates e
                    LEFT JOIN clients c ON e.client_id = c.id
                    WHERE e.user_id = :user_id
                    ORDER BY e.estimate_date DESC, e.id DESC
                    LIMIT :limit OFFSET :offset";
            $stmt = $this->db->query($sql, ['user_id' => $user_id, 'limit' => $limit, 'offset' => $offset]);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("Error finding all estimates for user {$user_id}: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Counts the total number of estimates for a user.
     * @param int $user_id
     * @return int
     */
    public function countForUser(int $user_id): int
    {
        try {
            $stmt = $this->db->query("SELECT COUNT(*) FROM estimates WHERE user_id = :user_id", ['user_id' => $user_id]);
            return (int)$stmt->fetchColumn();
        } catch (PDOException $e) {
            error_log("Error counting estimates for user {$user_id}: " . $e->getMessage());
            return 0;
        }
    }

    /**
     * Saves the estimate and its items to the database within a transaction.
     *
     * @return bool True on success, false on failure.
     */
    public function save(): bool
    {
        $this->db->beginTransaction();
        try {
            if ($this->id) { // Update
                $sql = "UPDATE estimates SET 
                            client_id = :client_id, estimate_date = :estimate_date, expiry_date = :expiry_date, status = :status,
                            subtotal = :subtotal, discount_rate = :discount_rate, discount_amount = :discount_amount,
                            cgst_rate = :cgst_rate, sgst_rate = :sgst_rate, igst_rate = :igst_rate,
                            cgst_amount = :cgst_amount, sgst_amount = :sgst_amount, igst_amount = :igst_amount,
                            total_amount = :total_amount, hsn_code = :hsn_code,
                            po_number = :po_number, notes = :notes
                        WHERE id = :id AND user_id = :user_id";
            } else { // Create
                $this->estimate_number = $this->generateNextEstimateNumber($this->user_id);
                $this->status = 'draft'; // New estimates are always drafts initially
                $sql = "INSERT INTO estimates (user_id, client_id, estimate_number, estimate_date, expiry_date, status, subtotal, discount_rate, discount_amount, cgst_rate, sgst_rate, igst_rate, cgst_amount, sgst_amount, igst_amount, total_amount, hsn_code, po_number, notes)
                        VALUES (:user_id, :client_id, :estimate_number, :estimate_date, :expiry_date, :status, :subtotal, :discount_rate, :discount_amount, :cgst_rate, :sgst_rate, :igst_rate, :cgst_amount, :sgst_amount, :igst_amount, :total_amount, :hsn_code, :po_number, :notes)";
            }
            
            $this->db->query($sql, $this->getPropertiesAsArray());

            if (!$this->id) {
                $this->id = $this->db->lastInsertId();
            }

            // Manage items: delete existing, then insert new
            $this->db->query("DELETE FROM estimate_items WHERE estimate_id = :id", ['id' => $this->id]);
            $itemSql = "INSERT INTO estimate_items (estimate_id, product_id, description, quantity, rate, amount, hsn_code) 
                        VALUES (:estimate_id, :product_id, :description, :quantity, :rate, :amount, :hsn_code)";
            foreach ($this->items as $item) {
                $this->db->query($itemSql, [
                    'estimate_id' => $this->id,
                    'product_id' => $item['product_id'] ?? null,
                    'description' => $item['description'],
                    'quantity' => $item['quantity'],
                    'rate' => $item['rate'],
                    'amount' => $item['amount'],
                    'hsn_code' => $item['hsn'] ?? null
                ]);
            }
            
            $this->db->commit();
            return true;

        } catch (PDOException $e) {
            $this->db->rollBack();
            error_log("Error saving estimate for user {$this->user_id}: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Generates the next sequential estimate number (EST-YY-YY-XXXX).
     * @param int $user_id
     * @return string
     */
    public function generateNextEstimateNumber(int $user_id): string
    {
        $current_month = (int)date('n'); $current_year = (int)date('Y');
        $start_yy = ($current_month >= 4) ? date('y') : substr((string)($current_year - 1), -2);
        $end_yy = substr((string)($current_year + ($current_month >= 4 ? 1 : 0)), -2);
        
        $fy_prefix = "EST-" . $start_yy . "-" . $end_yy . "-";
        
        $stmt = $this->db->query(
            "SELECT estimate_number FROM estimates WHERE user_id = :user_id AND estimate_number LIKE :prefix ORDER BY estimate_number DESC LIMIT 1",
            ['user_id' => $user_id, 'prefix' => $fy_prefix . '%']
        );
        $lastNum = $stmt->fetchColumn();
        
        $nextSeq = 1;
        if ($lastNum && preg_match('/-(\d{4})$/', $lastNum, $matches)) {
            $nextSeq = (int)$matches[1] + 1;
        }

        return $fy_prefix . str_pad($nextSeq, 4, '0', STR_PAD_LEFT);
    }
    
    /**
     * Helper to get object properties as an associative array for PDO binding.
     * @return array
     */
    private function getPropertiesAsArray(): array
    {
        return [
            'id' => $this->id,
            'user_id' => $this->user_id,
            'client_id' => $this->client_id,
            'estimate_number' => $this->estimate_number,
            'estimate_date' => $this->estimate_date,
            'expiry_date' => empty($this->expiry_date) ? null : $this->expiry_date,
            'status' => $this->status,
            'subtotal' => $this->subtotal,
            'discount_rate' => $this->discount_rate,
            'discount_amount' => $this->discount_amount,
            'cgst_rate' => $this->cgst_rate,
            'sgst_rate' => $this->sgst_rate,
            'igst_rate' => $this->igst_rate,
            'cgst_amount' => $this->cgst_amount,
            'sgst_amount' => $this->sgst_amount,
            'igst_amount' => $this->igst_amount,
            'total_amount' => $this->total_amount,
            'hsn_code' => empty($this->hsn_code) ? null : $this->hsn_code,
            'po_number' => empty($this->po_number) ? null : $this->po_number,
            'notes' => empty($this->notes) ? null : $this->notes
        ];
    }
}