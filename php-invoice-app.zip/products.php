<?php
/**
 * =====================================================================================
 * Products Management Page
 * =====================================================================================
 *
 * This script serves as the main interface for managing inventory (products & services).
 * - It requires a user to be logged in.
 * - It provides the UI for listing, searching, creating, updating, and deleting items.
 * - Leverages the Product class for all data interactions.
 *
 */

// Step 1: Bootstrap the application
require_once __DIR__ . '/config/config.php';

// Step 2: Authentication
$db = Database::getInstance();
$auth = new Auth($db);
$auth->requireLogin();
$currentUser = $auth->getUser();

// Step 3: Fetch Data for the View
$pageTitle = 'Product & Service Inventory';

$productModel = new Product($db);
$page = 1;
$limit = 10;
$initialProducts = $productModel->findAllForUser($currentUser->id, $limit, 0);
$totalProducts = $productModel->countForUser($currentUser->id);

$company = new Company($db);
$company->loadByUser($currentUser->id);

// Step 4: Include Header
require_once __DIR__ . '/partials/header.php';
?>

<!-- Main Content Wrapper -->
<div class="content-wrapper">

    <!-- Sidebar Partial -->
    <?php require_once __DIR__ . '/partials/sidebar.php'; ?>

    <!-- Main Content Area -->
    <div class="main-content">
        <div class="card">
            <div class="card-body">
                <div class="flex justify-between items-center mb-4 flex-wrap gap-2">
                    <h2 class="text-lg font-semibold">Inventory (<?php echo $totalProducts; ?> items)</h2>
                    <button type="button" class="btn btn-primary btn-sm" onclick="openProductModal()">
                        <i class="fas fa-plus btn-icon"></i> Add New Item
                    </button>
                </div>

                <!-- Search Input -->
                <div class="form-group mb-4">
                    <label for="product_search_tab" class="sr-only">Search Inventory</label>
                    <input type="text" id="product_search_tab" placeholder="Search by Name, Description, HSN Code...">
                </div>

                <!-- Product List Table -->
                <div class="table-responsive">
                    <table id="products-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>HSN/SAC</th>
                                <th class="text-right">Price (₹)</th>
                                <th class="text-center">Stock</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="products-table-body">
                             <?php if (!empty($initialProducts)): ?>
                                <?php foreach ($initialProducts as $product): ?>
                                    <tr>
                                        <td class="font-semibold">
                                            <?php echo h($product['name']); ?>
                                            <div class="text-xs text-muted"><?php echo h(substr($product['description'] ?? '', 0, 70)) . (strlen($product['description'] ?? '') > 70 ? '...' : ''); ?></div>
                                        </td>
                                        <td><?php echo h($product['hsn_code'] ?? '-'); ?></td>
                                        <td class="text-right"><?php echo format_currency($product['price']); ?></td>
                                        <td class="text-center">
                                            <?php if ($product['stock_quantity'] !== null): ?>
                                                <?php echo (int)$product['stock_quantity']; ?>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <div class="btn-group">
                                                <button class="btn btn-outline btn-sm" title="Edit Item" onclick="openProductModal(<?php echo $product['id']; ?>)">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button class="btn btn-danger btn-sm" title="Delete Item" onclick="deleteProduct(<?php echo $product['id']; ?>, this)">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="empty-table">No products or services found. Click "Add New Item" to start.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination container for JavaScript -->
                <div id="product-pagination" class="pagination" style="<?php echo ($totalProducts <= $limit) ? 'display: none;' : ''; ?>">
                </div>

            </div> <!-- /.card-body -->
        </div> <!-- /.card -->
    </div> <!-- /.main-content -->
</div> <!-- /.content-wrapper -->

<?php
// We need to add a new Product Modal to our modals partial
// For now, let's include it directly here, but ideally it moves to modals.php later
?>

<!-- Product Add/Edit Modal -->
<div id="product-modal" class="modal">
    <div class="modal-content">
        <form id="product-form" onsubmit="event.preventDefault(); saveProduct(this);">
            <div class="modal-header">
                <h2 class="modal-title" id="product-modal-title">Add New Item</h2>
                <button type="button" class="modal-close" onclick="closeProductModal()">&times;</button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="product_form_id" name="id" value="">
                
                <div class="form-group">
                    <label for="product_name">Item Name / Service Title <span class="text-danger">*</span></label>
                    <input type="text" id="product_name" name="name" required>
                </div>
                
                <div class="form-group">
                    <label for="product_description">Description</label>
                    <textarea id="product_description" name="description" rows="2"></textarea>
                </div>
                
                <div class="form-row">
                    <div class="form-col">
                        <label for="product_hsn_code">HSN/SAC Code</label>
                        <input type="text" id="product_hsn_code" name="hsn_code">
                    </div>
                    <div class="form-col">
                        <label for="product_price">Price (₹) <span class="text-danger">*</span></label>
                        <input type="number" id="product_price" name="price" required step="0.01" min="0" value="0.00">
                    </div>
                </div>

                <hr style="margin: 1.5rem 0;">
                <h3 class="font-semibold text-sm mb-2 text-secondary">Inventory Tracking (Optional)</h3>
                
                <div class="form-row">
                    <div class="form-col">
                        <label for="product_stock_quantity">Current Stock Quantity</label>
                        <input type="number" id="product_stock_quantity" name="stock_quantity" min="0" step="1" placeholder="Leave blank if not tracked">
                        <small class="text-muted text-xs">For services or untracked items, leave this field empty.</small>
                    </div>
                    <div class="form-col">
                        <label for="product_low_stock_threshold">Low Stock Alert Level</label>
                        <input type="number" id="product_low_stock_threshold" name="low_stock_threshold" min="0" step="1" placeholder="e.g., 10">
                         <small class="text-muted text-xs">Receive a notification when stock reaches this level.</small>
                    </div>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeProductModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Item</button>
            </div>
        </form>
    </div>
</div>

<?php
// Include the main modals and footer partials
require_once __DIR__ . '/partials/modals.php';
require_once __DIR__ . '/partials/footer.php';
?>