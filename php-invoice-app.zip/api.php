<?php
/**
 * =====================================================================================
 * Main API Endpoint
 * =====================================================================================
 *
 * This script is the single entry point for all AJAX requests from the frontend.
 * It routes requests to handler functions, which use the Model classes to interact
 * with the database.
 *
 */

// Step 1: Bootstrap the Application
require_once __DIR__ . '/config/config.php';

// --- Global API Setup ---
header('Content-Type: application/json');

try {
    $db = Database::getInstance();
    $auth = new Auth($db);
} catch (PDOException $e) {
    http_response_code(503);
    echo json_encode(['success' => false, 'message' => 'Database connection failed.']);
    exit();
}

// Step 2: Authentication Guard
if (!$auth->isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Authentication required. Please log in again.']);
    exit();
}
$currentUser = $auth->getUser();

// Step 3: API Routing
$action = $_REQUEST['action'] ?? null;
$inputData = $_SERVER['REQUEST_METHOD'] === 'POST' ? ($_POST ?: json_decode(file_get_contents('php://input'), true) ?? []) : $_GET;

try {
    switch ($action) {
        case 'get_clients': handle_get_clients($db, $currentUser); break;
        case 'get_client': handle_get_client($db, $currentUser, $inputData); break;
        case 'save_client': handle_save_client($db, $currentUser, $_POST); break; // FormData
        case 'delete_client': handle_delete_client($db, $currentUser, $inputData); break;
        
        case 'get_company': handle_get_company($db, $currentUser); break;
        case 'save_company': handle_save_company($db, $currentUser, $_POST); break; // FormData
            
        case 'get_products': handle_get_products($db, $currentUser); break;
        case 'get_product': handle_get_product($db, $currentUser, $inputData); break;
        case 'save_product': handle_save_product($db, $currentUser, $_POST); break; // FormData
        case 'delete_product': handle_delete_product($db, $currentUser, $inputData); break;

        case 'get_tax_rates': handle_get_tax_rates($db, $currentUser); break;
        case 'save_tax_rate': handle_save_tax_rate($db, $currentUser, $_POST); break; // FormData
        case 'delete_tax_rate': handle_delete_tax_rate($db, $currentUser, $inputData); break;

        case 'get_banks': handle_get_banks($db, $currentUser); break;
        case 'save_bank': handle_save_bank($db, $currentUser, $_POST); break; // FormData
        case 'delete_bank': handle_delete_bank($db, $currentUser, $inputData); break;
        
        case 'get_users': handle_get_users($db, $currentUser); break;
        case 'get_roles': handle_get_roles($db, $currentUser); break;
        case 'save_user': handle_save_user($db, $currentUser, $_POST); break; // FormData
        case 'delete_user': handle_delete_user($db, $currentUser, $inputData); break;

        case 'get_estimates': handle_get_estimates($db, $currentUser); break;
        case 'get_estimate': handle_get_estimate($db, $currentUser, $inputData); break;
        case 'save_estimate': handle_save_estimate($db, $currentUser, $inputData); break;
        case 'delete_estimate': handle_delete_estimate($db, $currentUser, $inputData); break;
        case 'update_estimate_status': handle_update_estimate_status($db, $currentUser, $inputData); break;
        case 'convert_to_invoice': handle_convert_to_invoice($db, $currentUser, $inputData); break;
        
        case 'save_invoice': handle_save_invoice($db, $currentUser, $inputData); break;
        case 'delete_invoice': handle_delete_invoice($db, $currentUser, $inputData); break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid action specified.']);
            break;
    }
} catch (Exception $e) {
    $code = ($e->getCode() >= 400 && $e->getCode() < 600) ? $e->getCode() : 500;
    http_response_code($code);
    error_log("API Action '$action' for user {$currentUser->id}: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
exit();


/* =====================================================================================
 * API Handler Implementations
 * ===================================================================================== */

// --- Client Handlers ---
function handle_get_clients(Database $db, User $user) {
    $clientModel = new Client($db);
    $clients = $clientModel->findAllForUser($user->id, 10000, 0, $_GET['search'] ?? '');
    echo json_encode(['success' => true, 'clients' => $clients]);
}

function handle_get_client(Database $db, User $user, array $input) {
    $clientId = (int)($input['id'] ?? 0);
    $client = (new Client($db))->findByIdForUser($clientId, $user->id);
    if (!$client) { throw new Exception('Client not found or access denied.', 404); }
    echo json_encode(['success' => true, 'client' => $client]);
}

function handle_save_client(Database $db, User $user, array $input) {
    $clientId = !empty($input['id']) ? (int)$input['id'] : null;
    $client = new Client($db);
    if ($clientId && !$client->findByIdForUser($clientId, $user->id)) { throw new Exception("Access denied.", 403); }
    $client->id = $clientId; $client->user_id = $user->id;
    $fields = ['name', 'address', 'gstin', 'state', 'state_code', 'phone', 'email'];
    foreach ($fields as $field) $client->{$field} = $input[$field] ?? null;
    if ($client->save()) { echo json_encode(['success' => true, 'message' => 'Client saved successfully.']); }
    else { throw new Exception("Failed to save client.", 500); }
}

function handle_delete_client(Database $db, User $user, array $input) {
    $clientId = (int)($input['id'] ?? 0);
    $client = new Client($db);
    if (!$client->findByIdForUser($clientId, $user->id)) { throw new Exception("Client not found.", 404); }
    if ((new Invoice($db))->hasInvoicesForClient($clientId)) { throw new Exception("Cannot delete a client that has associated invoices.", 409); }
    $client->id = $clientId;
    if ($client->delete()) { echo json_encode(['success' => true, 'message' => 'Client deleted successfully.']); }
    else { throw new Exception("Failed to delete client.", 500); }
}

// --- Company Handler ---
function handle_get_company(Database $db, User $user) {
    $company = new Company($db);
    $company->loadByUser($user->id);
    echo json_encode(['success' => true, 'company' => get_object_vars($company)]);
}

function handle_save_company(Database $db, User $user, array $input) {
    $company = new Company($db);
    $company->loadByUser($user->id);
    $company->user_id = $user->id;
    $fields = ['name', 'address', 'phone', 'email', 'website', 'gstin', 'default_notes'];
    foreach ($fields as $field) $company->{$field} = $input[$field] ?? null;
    if ($company->save()) { echo json_encode(['success' => true, 'message' => 'Company details updated.']); } 
    else { throw new Exception("Failed to save company details.", 500); }
}

// --- Product Handlers ---
function handle_get_products(Database $db, User $user) {
    $model = new Product($db);
    $items = $model->findAllForUser($user->id, 10000, 0, $_GET['search'] ?? '');
    echo json_encode(['success' => true, 'products' => $items]);
}

function handle_get_product(Database $db, User $user, array $input) {
    $id = (int)($input['id'] ?? 0);
    $model = new Product($db);
    if (!$model->load($id, $user->id)) { throw new Exception('Product not found.', 404); }
    echo json_encode(['success' => true, 'product' => get_object_vars($model)]);
}

function handle_save_product(Database $db, User $user, array $input) {
    $id = !empty($input['id']) ? (int)$input['id'] : null;
    $model = new Product($db);
    if ($id && !$model->load($id, $user->id)) { throw new Exception('Access denied.', 403); }
    $model->user_id = $user->id;
    $fields = ['name', 'description', 'hsn_code', 'price', 'stock_quantity', 'low_stock_threshold'];
    foreach ($fields as $field) $model->{$field} = $input[$field] ?? null;
    if ($model->save()) { echo json_encode(['success' => true, 'message' => 'Item saved.']); } 
    else { throw new Exception('Failed to save item.', 500); }
}

function handle_delete_product(Database $db, User $user, array $input) {
    $id = (int)($input['id'] ?? 0);
    $model = new Product($db);
    if (!$model->load($id, $user->id)) { throw new Exception('Product not found.', 404); }
    if ($model->delete()) { echo json_encode(['success' => true, 'message' => 'Item deleted.']); }
    else { throw new Exception('Failed to delete item.', 500); }
}

// --- Tax Rate Handlers ---
function handle_get_tax_rates(Database $db, User $user) {
    echo json_encode(['success' => true, 'tax_rates' => TaxRate::findAllForUser($db, $user->id)]);
}

function handle_save_tax_rate(Database $db, User $user, array $input) {
    $id = !empty($input['id']) ? (int)$input['id'] : null;
    $model = new TaxRate($db);
    if ($id && !$model->load($id, $user->id)) { throw new Exception('Tax rate not found.', 404); }
    $model->user_id = $user->id;
    $model->name = $input['name'] ?? '';
    $model->rate = $input['rate'] ?? 0.00;
    $model->is_default = isset($input['is_default']) && $input['is_default'] == '1';
    if ($model->save()) { echo json_encode(['success' => true, 'message' => 'Tax rate saved.']); }
    else { throw new Exception('Failed to save tax rate.', 500); }
}

function handle_delete_tax_rate(Database $db, User $user, array $input) {
    $id = (int)($input['id'] ?? 0);
    $model = new TaxRate($db);
    if (!$model->load($id, $user->id)) { throw new Exception('Tax rate not found.', 404); }
    if ($model->delete()) { echo json_encode(['success' => true, 'message' => 'Tax rate deleted.']); }
    else { throw new Exception('Failed to delete tax rate.', 500); }
}

// --- Bank Handlers ---
function handle_get_banks(Database $db, User $user) {
    echo json_encode(['success' => true, 'banks' => (new Bank($db))->findAllForUser($user->id)]);
}

function handle_save_bank(Database $db, User $user, array $input) {
    $id = !empty($input['id']) ? (int)$input['id'] : null;
    $model = new Bank($db);
    if ($id && !$model->load($id, $user->id)) { throw new Exception('Bank account not found.', 404); }
    $model->user_id = $user->id;
    $fields = ['bank_name', 'account_holder_name', 'account_number', 'ifsc_code', 'branch_name', 'upi_id'];
    foreach ($fields as $field) $model->{$field} = $input[$field] ?? null;
    if ($model->save()) { echo json_encode(['success' => true, 'message' => 'Bank account saved.']); }
    else { throw new Exception('Failed to save bank account.', 500); }
}

function handle_delete_bank(Database $db, User $user, array $input) {
    $id = (int)($input['id'] ?? 0);
    $model = new Bank($db);
    if (!$model->load($id, $user->id)) { throw new Exception('Bank account not found.', 404); }
    if ($model->delete()) { echo json_encode(['success' => true, 'message' => 'Bank account deleted.']); }
    else { throw new Exception('Failed to delete bank account.', 500); }
}

// --- User (RBAC) Handlers ---
function handle_get_users(Database $db, User $user) {
    if (strtolower($user->getRole()->name) !== 'admin') { throw new Exception('Permission denied.', 403); }
    $users = User::findAll($db);
    $response = array_map(fn($u) => ['id' => $u->id, 'username' => $u->username, 'role_id' => $u->role_id, 'role_name' => $u->getRole()->name ?? 'N/A'], $users);
    echo json_encode(['success' => true, 'users' => $response]);
}
function handle_get_roles(Database $db, User $user) {
    if (strtolower($user->getRole()->name) !== 'admin') { throw new Exception('Permission denied.', 403); }
    $roles = Role::findAll($db);
    $response = array_map(fn($r) => ['id' => $r->id, 'name' => $r->name], $roles);
    echo json_encode(['success' => true, 'roles' => $response]);
}
function handle_save_user(Database $db, User $user, array $input) {
    if (strtolower($user->getRole()->name) !== 'admin') { throw new Exception('Permission denied.', 403); }
    $id = !empty($input['id']) ? (int)$input['id'] : null;
    $model = new User($db);
    if ($id && !$model->load($id)) { throw new Exception('User not found.', 404); }
    if ($model->save($input['username'], $input['password'], (int)$input['role_id'])) { echo json_encode(['success' => true, 'message' => 'User saved.']); } 
    else { throw new Exception('Failed to save user.', 500); }
}
function handle_delete_user(Database $db, User $user, array $input) {
    if (strtolower($user->getRole()->name) !== 'admin') { throw new Exception('Permission denied.', 403); }
    $id = (int)($input['id'] ?? 0);
    if ($id === $user->id) { throw new Exception('You cannot delete your own account.', 400); }
    $model = new User($db);
    if (!$model->load($id)) { throw new Exception('User not found.', 404); }
    if ($model->delete()) { echo json_encode(['success' => true, 'message' => 'User deleted.']); } 
    else { throw new Exception('Failed to delete user.', 500); }
}

// --- Estimate & Invoice Handlers (Shared Logic) ---
function process_document_save(Database $db, User $user, array $inputData, string $type) {
    $isInvoice = $type === 'invoice';
    $model = $isInvoice ? new Invoice($db) : new Estimate($db);
    $id = !empty($inputData['id']) ? (int)$inputData['id'] : null;

    if ($id) {
        $found = $isInvoice ? $model->findByIdForUser($id, $user->id) : $model->findByIdForUser($id, $user->id);
        if (!$found) throw new Exception(ucfirst($type) . ' not found or access denied.', 404);
        $model->id = $id;
    }

    $model->user_id = $user->id;
    
    // Server-side validation and calculation
    $company = new Company($db); $company->loadByUser($user->id);
    $client = (new Client($db))->findByIdForUser((int)$inputData['client_id'], $user->id);
    if (!$client) { throw new Exception("Client not found.", 404); }
    $gstHandler = new GstHandler(BUSINESS_HOME_STATE);
    $taxInfo = $gstHandler->calculateTaxes((float)($inputData['tax_rate_total'] ?? 0), $client['state']);
    
    $subtotal = 0; $items = [];
    foreach($inputData['items'] as $item) {
        $quantity = (float)($item['quantity'] ?? 0); $rate = (float)($item['rate'] ?? 0); $amount = round($quantity * $rate, 2);
        $subtotal += $amount;
        $items[] = ['product_id' => $item['product_id'] ?? null, 'description' => $item['description'], 'quantity' => $quantity, 'rate' => $rate, 'amount' => $amount, 'hsn' => $item['hsn'] ?? null];
    }

    $discount_rate = (float)($inputData['discount_rate'] ?? 0);
    $discount_amount = round($subtotal * $discount_rate / 100, 2);
    $taxable_amount = $subtotal - $discount_amount;
    
    $model->items = $items;
    $model->client_id = $client['id'];
    $model->subtotal = round($subtotal, 2);
    $model->discount_rate = $discount_rate;
    $model->discount_amount = $discount_amount;
    $model->cgst_rate = $taxInfo['cgst_rate']; $model->sgst_rate = $taxInfo['sgst_rate']; $model->igst_rate = $taxInfo['igst_rate'];
    $model->cgst_amount = round($taxable_amount * $taxInfo['cgst_rate'] / 100, 2);
    $model->sgst_amount = round($taxable_amount * $taxInfo['sgst_rate'] / 100, 2);
    $model->igst_amount = round($taxable_amount * $taxInfo['igst_rate'] / 100, 2);
    $model->total_amount = round($taxable_amount + $model->cgst_amount + $model->sgst_amount + $model->igst_amount, 2);

    $fields = $isInvoice ? ['invoice_date','due_date','notes','advance_paid','bank_account_id'] : ['estimate_date','expiry_date','notes'];
    foreach($fields as $field) { $model->{$field} = $inputData[$field] ?? null; }
    
    if($isInvoice) {
        if(abs($model->total_amount - (float)($inputData['advance_paid'] ?? 0)) < 0.01) $model->status = 'paid';
        elseif((float)($inputData['advance_paid'] ?? 0) > 0) $model->status = 'partially_paid';
        else $model->status = 'unpaid';
    }

    if ($model->save()) { echo json_encode(['success' => true, 'message' => ucfirst($type) . ' saved successfully.', 'id' => $model->id]); } 
    else { throw new Exception("Failed to save " . $type, 500); }
}

// --- Estimate Handlers (using shared logic) ---
function handle_save_estimate(Database $db, User $user, array $inputData) {
    process_document_save($db, $user, $inputData, 'estimate');
}
function handle_delete_estimate(Database $db, User $user, array $input) {
    $id = (int)($input['id'] ?? 0); $model = new Estimate($db);
    $estimate = $model->findByIdForUser($id, $user->id);
    if (!$estimate) { throw new Exception("Estimate not found.", 404); }
    if (!empty($estimate['invoice_id'])) { throw new Exception("Cannot delete an estimate that has been converted to an invoice.", 409); }
    $model->id = $id;
    if($model->delete()){ echo json_encode(['success' => true, 'message' => 'Estimate deleted.']); }
    else { throw new Exception("Failed to delete estimate.", 500); }
}
function handle_update_estimate_status(Database $db, User $user, array $input) {
    $id = (int)($input['id'] ?? 0); $status = $input['status'] ?? '';
    if(!in_array($status, ['draft','sent','accepted','rejected'])) { throw new Exception('Invalid status', 400); }
    $db->query("UPDATE estimates SET status = :status WHERE id = :id AND user_id = :user_id", ['status' => $status, 'id' => $id, 'user_id' => $user->id]);
    echo json_encode(['success' => true, 'message' => 'Status updated.']);
}
function handle_convert_to_invoice(Database $db, User $user, array $input) {
    $estimateId = (int)($input['id'] ?? 0);
    $estimateData = (new Estimate($db))->findByIdForUser($estimateId, $user->id);
    if(!$estimateData) { throw new Exception('Estimate not found.', 404); }
    if($estimateData['invoice_id']) { throw new Exception('Estimate already invoiced.', 409); }
    
    $db->beginTransaction();
    try {
        $invoice = new Invoice($db);
        $fieldsToCopy = ['user_id','client_id','subtotal','discount_rate','discount_amount','cgst_rate','sgst_rate','igst_rate','cgst_amount','sgst_amount','igst_amount','total_amount','notes'];
        foreach($fieldsToCopy as $field) $invoice->{$field} = $estimateData[$field];
        $invoice->invoice_date = date('Y-m-d');
        $invoice->items = $estimateData['items'];
        $invoice->save(); // Generates number & saves
        $db->query("UPDATE estimates SET invoice_id = :invoice_id, status = 'invoiced' WHERE id = :id", ['invoice_id' => $invoice->id, 'id' => $estimateId]);
        $db->commit();
        echo json_encode(['success' => true, 'message' => "Converted to Invoice #{$invoice->invoice_number}", 'id' => $invoice->id]);
    } catch(Exception $e) { $db->rollBack(); throw $e; }
}

// --- Invoice Handlers (using shared logic) ---
function handle_save_invoice(Database $db, User $user, array $inputData) {
    process_document_save($db, $user, $inputData, 'invoice');
}
function handle_delete_invoice(Database $db, User $user, array $inputData) {
    $id = (int)($inputData['id'] ?? 0);
    $invoiceModel = new Invoice($db);
    $invoice = $invoiceModel->findByIdForUser($id, $user->id);
    if(!$invoice) { throw new Exception("Invoice not found.", 404); }
    
    $db->beginTransaction();
    try {
        $db->query("UPDATE estimates SET invoice_id = NULL, status = 'accepted' WHERE invoice_id = :invoice_id AND user_id = :user_id", ['invoice_id' => $id, 'user_id' => $user->id]);
        $db->query("DELETE FROM invoice_items WHERE invoice_id = :id", ['id' => $id]);
        $db->query("DELETE FROM invoices WHERE id = :id AND user_id = :user_id", ['id' => $id, 'user_id' => $user->id]);
        $db->commit();
        echo json_encode(['success' => true, 'message' => 'Invoice deleted.']);
    } catch (Exception $e) { $db->rollBack(); throw new Exception("Failed to delete invoice.", 500); }
}