<?php

/**
 * =====================================================================================
 * Logout Script
 * =====================================================================================
 *
 * This script handles the user logout process.
 * It is a non-visual page that performs an action and then redirects.
 *
 * - Includes the configuration to ensure session management is active.
 * - Instantiates the Auth class.
 * - Calls the logout() method to securely destroy the session.
 * - Redirects the user back to the login page.
 *
 */

// Step 1: Bootstrap the application to access config and classes
require_once __DIR__ . '/config/config.php';

// Step 2: Instantiate necessary objects
// Although we don't need the DB for logout, it's good practice
// in case future logout logic needs it (e.g., logging the event).
$db = Database::getInstance();
$auth = new Auth($db);

// Step 3: Perform the logout action
$auth->logout();

// Step 4: Redirect to the login page
// Use the BASE_URL constant for a reliable redirect path.
header('Location: ' . BASE_URL . 'login.php');
exit();

?>