<?php
/**
 * =====================================================================================
 * Modals Partial (Final Version)
 * =====================================================================================
 *
 * This file contains the HTML markup for all sitewide modals, including the
 * universal preview modal for invoices and estimates.
 *
 */
?>

<!-- ========================================================================= -->
<!-- Client Add/Edit Modal                                                   -->
<!-- ========================================================================= -->
<div id="client-modal" class="modal">
    <div class="modal-content">
        <form id="client-form" onsubmit="event.preventDefault(); saveClient(this);">
            <div class="modal-header">
                <h2 class="modal-title" id="client-modal-title">Add New Client</h2>
                <button type="button" class="modal-close" onclick="closeClientModal()">&times;</button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="client_form_id" name="id" value="">
                <div class="form-row">
                    <div class="form-col"><label for="client_name">Client Name <span class="text-danger">*</span></label><input type="text" id="client_name" name="name" required></div>
                    <div class="form-col"><label for="client_gstin">GSTIN</label><input type="text" id="client_gstin" name="gstin" pattern="^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$" title="Enter a valid GSTIN format"></div>
                </div>
                <div class="form-group"><label for="client_address">Address</label><textarea id="client_address" name="address" rows="3"></textarea></div>
                <div class="form-row">
                    <div class="form-col"><label for="client_state">State <span class="text-danger">*</span></label><select id="client_state" name="state" required><option value="">-- Select a State --</option></select></div>
                    <div class="form-col"><label for="client_state_code">State Code</label><input type="text" id="client_state_code" name="state_code" readonly></div>
                </div>
                <div class="form-row">
                    <div class="form-col"><label for="client_phone">Phone</label><input type="tel" id="client_phone" name="phone"></div>
                    <div class="form-col"><label for="client_email">Email</label><input type="email" id="client_email" name="email"></div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeClientModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Client</button>
            </div>
        </form>
    </div>
</div>

<!-- ========================================================================= -->
<!-- Company Info Modal                                                      -->
<!-- ========================================================================= -->
<div id="company-modal" class="modal">
    <div class="modal-content">
        <form id="company-form" onsubmit="event.preventDefault(); saveCompany(this);">
            <div class="modal-header"><h2 class="modal-title">Company Information</h2><button type="button" class="modal-close" onclick="closeCompanyModal()">&times;</button></div>
            <div class="modal-body">
                 <div class="form-row">
                    <div class="form-col"><label for="m_company_name">Company Name <span class="text-danger">*</span></label><input type="text" id="m_company_name" name="name" required></div>
                    <div class="form-col"><label for="m_company_gstin">GSTIN</label><input type="text" id="m_company_gstin" name="gstin" pattern="^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$" title="Enter a valid GSTIN format"></div>
                </div>
                <div class="form-group"><label for="m_company_address">Address <span class="text-danger">*</span></label><textarea id="m_company_address" name="address" rows="3" required></textarea></div>
                <div class="form-row">
                    <div class="form-col"><label for="m_company_phone">Phone</label><input type="tel" id="m_company_phone" name="phone"></div>
                    <div class="form-col"><label for="m_company_email">Email</label><input type="email" id="m_company_email" name="email"></div>
                </div>
                <hr style="margin: 1.5rem 0; border-top: 1px solid var(--border-color);"><h3 class="font-semibold text-sm mb-2">Images & Notes</h3>
                <div class="form-group">
                    <label for="m_company_upi_qr_code">UPI QR Code (Image)</label><input type="file" id="m_company_upi_qr_code" name="upi_qr_code" accept="image/png, image/jpeg">
                    <div id="qr-preview-container" class="file-input-info" style="display: none; margin-top: 0.5rem;"><img id="qr-preview-img" src="#" alt="QR Preview" style="max-height: 40px; border: 1px solid #eee;"><input type="checkbox" name="remove_qr" id="m_remove_qr" value="1"><label for="m_remove_qr" style="display:inline; margin-left: 5px;">Remove</label></div>
                </div>
                 <div class="form-group">
                    <label for="m_company_stamp">Stamp (Image)</label><input type="file" id="m_company_stamp" name="stamp" accept="image/png, image/jpeg">
                    <div id="stamp-preview-container" class="file-input-info" style="display: none; margin-top: 0.5rem;"><img id="stamp-preview-img" src="#" alt="Stamp Preview" style="max-height: 40px; border: 1px solid #eee;"><input type="checkbox" name="remove_stamp" id="m_remove_stamp" value="1"><label for="m_remove_stamp" style="display:inline; margin-left: 5px;">Remove</label></div>
                </div>
                <div class="form-group"><label for="m_company_default_notes">Default Invoice Notes</label><textarea id="m_company_default_notes" name="default_notes" rows="3"></textarea></div>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="closeCompanyModal()">Cancel</button><button type="submit" class="btn btn-primary">Save Info</button></div>
        </form>
    </div>
</div>

<!-- ========================================================================= -->
<!-- Product Add/Edit Modal                                                  -->
<!-- ========================================================================= -->
<div id="product-modal" class="modal">
    <div class="modal-content">
        <form id="product-form" onsubmit="event.preventDefault(); saveProduct(this);">
            <div class="modal-header"><h2 class="modal-title" id="product-modal-title">Add Item</h2><button type="button" class="modal-close" onclick="closeProductModal()">&times;</button></div>
            <div class="modal-body">
                <input type="hidden" id="product_form_id" name="id" value="">
                <div class="form-group"><label for="product_name">Name <span class="text-danger">*</span></label><input type="text" id="product_name" name="name" required></div>
                <div class="form-group"><label for="product_description">Description</label><textarea id="product_description" name="description" rows="2"></textarea></div>
                <div class="form-row">
                    <div class="form-col"><label for="product_hsn_code">HSN/SAC</label><input type="text" id="product_hsn_code" name="hsn_code"></div>
                    <div class="form-col"><label for="product_price">Price (₹) <span class="text-danger">*</span></label><input type="number" id="product_price" name="price" required step="0.01" min="0"></div>
                </div>
                <hr style="margin: 1.5rem 0; border-top: 1px solid var(--border-color);"><h3 class="font-semibold text-sm text-secondary">Inventory Tracking (Optional)</h3>
                <div class="form-row">
                    <div class="form-col"><label for="product_stock_quantity">Stock Qty</label><input type="number" id="product_stock_quantity" name="stock_quantity" min="0" step="1" placeholder="Leave blank if untracked"></div>
                    <div class="form-col"><label for="product_low_stock_threshold">Low Stock Alert</label><input type="number" id="product_low_stock_threshold" name="low_stock_threshold" min="0" step="1" placeholder="e.g., 10"></div>
                </div>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="closeProductModal()">Cancel</button><button type="submit" class="btn btn-primary">Save Item</button></div>
        </form>
    </div>
</div>

<!-- ========================================================================= -->
<!-- User Add/Edit Modal                                                     -->
<!-- ========================================================================= -->
<div id="user-modal" class="modal">
    <div class="modal-content" style="max-width: 500px;">
        <form id="user-form" onsubmit="event.preventDefault(); saveUser(this);">
            <div class="modal-header"><h2 class="modal-title" id="user-modal-title">Add User</h2><button type="button" class="modal-close" onclick="closeUserModal()">&times;</button></div>
            <div class="modal-body">
                <input type="hidden" id="user_form_id" name="id" value="">
                <div class="form-group"><label for="user_username">Username <span class="text-danger">*</span></label><input type="text" id="user_username" name="username" required></div>
                <div class="form-group"><label for="user_password">Password</label><input type="password" id="user_password" name="password" autocomplete="new-password"><small class="text-muted text-xs">Leave blank to keep current password.</small></div>
                <div class="form-group"><label for="user_role_id">Role <span class="text-danger">*</span></label><select id="user_role_id" name="role_id" required><option value="">-- Select Role --</option></select></div>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="closeUserModal()">Cancel</button><button type="submit" class="btn btn-primary">Save User</button></div>
        </form>
    </div>
</div>

<!-- ========================================================================= -->
<!-- Bank Add/Edit Modal                                                     -->
<!-- ========================================================================= -->
<div id="bank-modal" class="modal">
    <div class="modal-content">
        <form id="bank-form" onsubmit="event.preventDefault(); saveBank(this);">
            <div class="modal-header"><h2 class="modal-title" id="bank-modal-title">Add Bank</h2><button type="button" class="modal-close" onclick="closeBankModal()">&times;</button></div>
            <div class="modal-body">
                <input type="hidden" id="bank_form_id" name="id" value="">
                <div class="form-group"><label for="bank_name">Bank Name <span class="text-danger">*</span></label><input type="text" id="bank_name" name="bank_name" required></div>
                <div class="form-group"><label for="account_holder_name">Holder Name</label><input type="text" id="account_holder_name" name="account_holder_name"></div>
                <div class="form-row">
                    <div class="form-col"><label for="account_number">Account No. <span class="text-danger">*</span></label><input type="text" id="account_number" name="account_number" required></div>
                    <div class="form-col"><label for="ifsc_code">IFSC <span class="text-danger">*</span></label><input type="text" id="ifsc_code" name="ifsc_code" required></div>
                </div>
                <div class="form-row">
                    <div class="form-col"><label for="branch_name">Branch</label><input type="text" id="branch_name" name="branch_name"></div>
                    <div class="form-col"><label for="upi_id">UPI ID</label><input type="text" id="upi_id" name="upi_id"></div>
                </div>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="closeBankModal()">Cancel</button><button type="submit" class="btn btn-primary">Save Bank</button></div>
        </form>
    </div>
</div>

<!-- ========================================================================= -->
<!-- Tax Rate Add/Edit Modal                                                 -->
<!-- ========================================================================= -->
<div id="tax-rate-modal" class="modal">
     <div class="modal-content" style="max-width: 500px;">
        <form id="tax-rate-form" onsubmit="event.preventDefault(); saveTaxRate(this);">
            <div class="modal-header"><h2 class="modal-title" id="tax-rate-modal-title">Add Tax Rate</h2><button type="button" class="modal-close" onclick="closeTaxRateModal()">&times;</button></div>
            <div class="modal-body">
                <input type="hidden" id="tax_rate_form_id" name="id" value="">
                <div class="form-group"><label for="tax_rate_name">Name <span class="text-danger">*</span></label><input type="text" id="tax_rate_name" name="name" required placeholder="e.g., GST 18%"></div>
                <div class="form-group"><label for="tax_rate_rate">Rate (%) <span class="text-danger">*</span></label><input type="number" id="tax_rate_rate" name="rate" required step="0.01" min="0" placeholder="e.g., 18.00"></div>
                <div class="form-group"><input type="checkbox" id="tax_rate_is_default" name="is_default" value="1"><label for="tax_rate_is_default" style="display: inline; font-weight: normal;">Set as default</label></div>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="closeTaxRateModal()">Cancel</button><button type="submit" class="btn btn-primary">Save Rate</button></div>
        </form>
    </div>
</div>

<!-- ========================================================================= -->
<!-- UNIVERSAL PREVIEW MODAL                                                 -->
<!-- ========================================================================= -->
<div id="preview-modal" class="modal">
    <div class="modal-content" style="max-width: 900px;">
        <div class="modal-header"><h2 class="modal-title" id="preview-modal-title">Preview</h2><button type="button" class="modal-close" onclick="closePreviewModal()">&times;</button></div>
        <div class="modal-body" id="preview-modal-content"><p class="text-center p-4">Loading preview...</p></div>
        <div class="modal-footer" id="preview-modal-footer">
            <button type="button" class="btn btn-outline" onclick="closePreviewModal()">Close</button>
        </div>
    </div>
</div>