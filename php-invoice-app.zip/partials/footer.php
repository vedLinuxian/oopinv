<?php
/**
 * =====================================================================================
 * Footer Partial
 * =====================================================================================
 *
 * This file contains the standard closing markup for every authenticated page.
 *
 * It includes:
 * - Closing tags for the main container and body.
 * - The primary `<script>` tag for the main application JavaScript file.
 * - A space for outputting global JavaScript variables from PHP.
 *
 */
?>

        <!-- This closes the .container div opened in header.php -->
    </div> 

    <!-- Global JavaScript variables -->
    <script>
        // Pass important PHP constants/variables to the frontend JavaScript.
        // This is a secure way to make configuration available to your JS.
        const AppConfig = {
            BASE_URL: '<?php echo BASE_URL; ?>'
        };
    </script>

    <!-- Main Application JavaScript file -->
    <script src="<?php echo BASE_URL; ?>js/app.js"></script>
    
    <!-- Any page-specific JavaScript can be added after the main app.js -->
    
</body>
</html>