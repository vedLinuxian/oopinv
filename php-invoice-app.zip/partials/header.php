<?php
/**
 * =====================================================================================
 * Header Partial
 * =====================================================================================
 *
 * This file contains the standard opening markup for every authenticated page.
 *
 * It includes:
 * - The HTML document type, head, and meta tags.
 * - Links to all CSS files, fonts, and icons.
 * - The main page header, including the page title and user menu.
 * - A container for toast notifications.
 *
 * --- Dependencies ---
 * This file assumes that the following PHP variables have been defined in the script
 * that includes it:
 * - $pageTitle: (string) The title of the page to be displayed.
 * - $currentUser: (User) The authenticated user object from the Auth class.
 *
 */

// Set a default title if the including page did not provide one.
$pageTitle = $pageTitle ?? 'Dashboard';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?> - Invoice Generator</title>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Main Application Stylesheet -->
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>css/style.css">
</head>
<body>

    <!-- This main container wraps all page content -->
    <div class="container">
        
        <!-- Standard Page Header -->
        <header class="page-header">
            <div class="page-title">
                <h1><?php echo htmlspecialchars($pageTitle); ?></h1>
            </div>
            <div class="user-menu">
                <span class="user-name">Welcome, <?php echo htmlspecialchars($currentUser->username ?? 'User'); ?></span>
                <a href="<?php echo BASE_URL; ?>logout.php" class="btn btn-outline btn-sm">Sign Out</a>
            </div>
        </header>

        <!-- Container for JavaScript-driven toast notifications -->
        <div id="toast-container"></div>
        
        <!-- PHP flash messages will be handled via a session helper and displayed here -->
        <?php
        // We will later create 'session_helper.php' with a function like 'display_flash_messages()'
        // and call it here.
        ?>

        <!-- The rest of the page content from the including file will follow here -->