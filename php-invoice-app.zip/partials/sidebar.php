<?php
/**
 * =====================================================================================
 * Sidebar Partial
 * =====================================================================================
 *
 * This file contains the markup for the sidebar, which is included on main authenticated
 * pages like the dashboard.
 *
 * It displays:
 * - A summary of the user's company information.
 * - A list of quick actions and navigation links.
 *
 * --- Dependencies ---
 * This file assumes that the following PHP variables have been defined in the script
 * that includes it:
 * - $company: (Company|array) An object/array containing the company's details.
 * - $auth: (Auth) The authenticated user object for future permission checks.
 *
 */
?>

<aside class="sidebar">

    <!-- Company Information Box -->
    <div class="sidebar-box">
        <div class="sidebar-header">Company Information</div>
        <div class="sidebar-body">
            <?php if ($company && $company->id): // Check if a valid company object/id exists ?>
                <div class="mb-2">
                    <div class="font-semibold mb-1"><?php echo htmlspecialchars($company->name); ?></div>
                    <div class="text-sm mb-1"><?php echo nl2br(htmlspecialchars($company->address)); ?></div>
                    
                    <?php if (!empty($company->phone)): ?>
                        <div class="text-xs text-muted">Phone: <?php echo htmlspecialchars($company->phone); ?></div>
                    <?php endif; ?>

                    <?php if (!empty($company->email)): ?>
                        <div class="text-xs text-muted">Email: <?php echo htmlspecialchars($company->email); ?></div>
                    <?php endif; ?>

                    <?php if (!empty($company->gstin)): ?>
                        <div class="text-xs text-muted">GSTIN: <?php echo htmlspecialchars($company->gstin); ?></div>
                    <?php endif; ?>
                    
                    <?php if (!empty($company->upi_qr_code_path) && file_exists(ROOT_PATH . '/' . $company->upi_qr_code_path)): ?>
                        <div class="text-xs text-muted mt-2">QR Code: 
                            <img src="<?php echo BASE_URL . htmlspecialchars($company->upi_qr_code_path) . '?t=' . time(); ?>" alt="UPI QR" class="img-preview">
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($company->stamp_path) && file_exists(ROOT_PATH . '/' . $company->stamp_path)): ?>
                        <div class="text-xs text-muted mt-2">Stamp: 
                            <img src="<?php echo BASE_URL . htmlspecialchars($company->stamp_path) . '?t=' . time(); ?>" alt="Stamp" class="img-preview">
                        </div>
                    <?php endif; ?>
                </div>
                
                <button type="button" class="btn btn-outline btn-sm mt-2" onclick="openCompanyModal()">Edit Details</button>
                <a href="<?php echo BASE_URL; ?>bank.php" class="btn btn-outline btn-sm mt-2">Manage Banks</a>
                
            <?php else: ?>
                <p class="text-muted text-sm">Company details are not set up yet.</p>
                <button type="button" class="btn btn-primary btn-sm mt-2" onclick="openCompanyModal()">Add Company Details</button>
            <?php endif; ?>
        </div>
    </div>

    <!-- Quick Actions Box -->
    <div class="sidebar-box">
        <div class="sidebar-header">Quick Actions</div>
        <div class="sidebar-body">
            <div class="flex flex-column gap-2">
                <button type="button" class="btn btn-primary w-full" onclick="showTab('create-invoice')">
                    <i class="fas fa-plus btn-icon"></i> Create New Invoice
                </button>
                <a href="<?php echo BASE_URL; ?>estimates.php" class="btn btn-outline w-full">
                    <i class="fas fa-file-alt btn-icon"></i> Manage Estimates
                </a>
                <a href="<?php echo BASE_URL; ?>clients.php" class="btn btn-outline w-full">
                    <i class="fas fa-users btn-icon"></i> Manage Clients
                </a>
                <a href="<?php echo BASE_URL; ?>products.php" class="btn btn-outline w-full">
                    <i class="fas fa-box-open btn-icon"></i> Product Inventory
                </a>

                <hr style="border: none; border-top: 1px solid var(--border-color); margin: 0.5rem 0;">

                <h3 class="text-xs font-semibold text-muted" style="padding: 0 0.5rem;">REPORTS</h3>
                <a href="<?php echo BASE_URL; ?>reports.php" class="btn btn-outline w-full">
                    <i class="fas fa-chart-pie btn-icon"></i> Reports Dashboard
                </a>
                <a href="<?php echo BASE_URL; ?>taxes.php" class="btn btn-outline w-full">
                     <i class="fas fa-percent btn-icon"></i> Manage Tax Rates
                </a>

                <hr style="border: none; border-top: 1px solid var(--border-color); margin: 0.5rem 0;">
                
                <h3 class="text-xs font-semibold text-muted" style="padding: 0 0.5rem;">ADMINISTRATION</h3>
                <!-- The link to users.php will be wrapped in a permission check -->
                <?php if ($auth->can('manage_users')): ?>
                    <a href="<?php echo BASE_URL; ?>users.php" class="btn btn-outline w-full">
                        <i class="fas fa-user-shield btn-icon"></i> Manage Users
                    </a>
                <?php endif; ?>

                <button type="button" class="btn btn-outline w-full company-edit-btn" onclick="openCompanyModal()">
                    <i class="fas fa-cog btn-icon"></i> Company Settings
                </button>
            </div>
        </div>
    </div>

</aside>