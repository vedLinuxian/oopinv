<?php
/**
 * =====================================================================================
 * Estimates Management Page
 * =====================================================================================
 *
 * This script serves as the main interface for managing estimates/quotations.
 * - Requires a user to be logged in.
 * - Provides a tabbed interface for listing existing estimates and creating new ones.
 * - The form handles both 'create' and 'edit' modes.
 *
 */

// Step 1: Bootstrap and Authenticate
require_once __DIR__ . '/config/config.php';
$db = Database::getInstance();
$auth = new Auth($db);
$auth->requireLogin();
$currentUser = $auth->getUser();

// Step 2: Fetch Data for the View
$pageTitle = 'Manage Estimates';

$estimateModel = new Estimate($db);
$clientModel = new Client($db);
$company = new Company($db);
$company->loadByUser($currentUser->id);

// Initial data for the "Create" tab form
$nextEstimateNumber = $estimateModel->generateNextEstimateNumber($currentUser->id);
$allClients = $clientModel->findAllForUser($currentUser->id, 10000, 0); // Get all clients
$allProducts = (new Product($db))->findAllForUser($currentUser->id, 10000, 0);
$allTaxRates = TaxRate::findAllForUser($db, $currentUser->id);
$defaultTaxRate = 0.00;
foreach($allTaxRates as $tax) {
    if ($tax['is_default']) {
        $defaultTaxRate = (float)$tax['rate'];
        break;
    }
}

// Step 3: Include Header
require_once __DIR__ . '/partials/header.php';
?>

<!-- Main Content Wrapper -->
<div class="content-wrapper">

    <!-- Sidebar Partial -->
    <?php require_once __DIR__ . '/partials/sidebar.php'; ?>

    <!-- Main Content Area -->
    <div class="main-content">
        <div class="card">
            <div class="tabs">
                <div class="tab active" data-tab="estimates-list">Estimates List</div>
                <div class="tab" data-tab="create-estimate">Create / Edit Estimate</div>
            </div>

            <!-- Estimates List Tab -->
            <div class="tab-content active" id="estimates-list-tab">
                <div class="card-body">
                     <div class="flex justify-between items-center mb-4">
                        <h2 class="text-lg font-semibold">Your Estimates</h2>
                        <button type="button" class="btn btn-primary btn-sm" onclick="showTab('create-estimate')">
                            <i class="fas fa-plus btn-icon"></i> New Estimate
                        </button>
                    </div>
                    <div class="table-responsive">
                        <table id="estimates-table">
                            <thead><tr><th>Estimate #</th><th>Date</th><th>Client</th><th class="text-right">Total (₹)</th><th class="text-center">Status</th><th class="text-center">Actions</th></tr></thead>
                            <tbody id="estimates-table-body">
                                <!-- JS will load initial data here -->
                                <tr><td colspan="6" class="empty-table">Loading estimates...</td></tr>
                            </tbody>
                        </table>
                    </div>
                    <div id="estimate-pagination" class="pagination"></div>
                </div>
            </div>

            <!-- Create/Edit Estimate Tab -->
            <div class="tab-content" id="create-estimate-tab">
                <div class="card-body">
                    <h2 class="text-lg font-semibold mb-4" id="estimate-form-title">Create New Estimate</h2>
                    <form id="estimate-form" onsubmit="event.preventDefault(); saveEstimate(this);">
                        <input type="hidden" name="id" id="estimate_form_id" value="">

                        <!-- Details Box -->
                        <div class="box">
                            <h3 class="box-title">Estimate Details</h3>
                            <div class="form-row">
                                <div class="form-col">
                                    <label>Estimate #</label>
                                    <input type="text" id="estimate_number" name="estimate_number" value="<?php echo h($nextEstimateNumber); ?>" readonly>
                                </div>
                                <div class="form-col">
                                    <label>Estimate Date *</label>
                                    <input type="date" id="estimate_date" name="estimate_date" value="<?php echo date('Y-m-d'); ?>" required>
                                </div>
                                <div class="form-col">
                                    <label>Expiry Date</label>
                                    <input type="date" id="expiry_date" name="expiry_date">
                                </div>
                            </div>
                        </div>

                        <!-- Client Box -->
                        <div class="box">
                            <h3 class="box-title">Client Information</h3>
                            <div class="form-group">
                                <label for="estimate_client_id">Select Client *</label>
                                <select id="estimate_client_id" name="client_id" required>
                                    <option value="">-- Select a Client --</option>
                                    <?php foreach ($allClients as $client): ?>
                                    <option value="<?php echo $client['id']; ?>" data-state="<?php echo h($client['state']); ?>">
                                        <?php echo h($client['name']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <!-- Items Box -->
                        <div class="box">
                            <h3 class="box-title">Items *</h3>
                            <div class="flex justify-between items-center mb-2">
                                <select id="estimate-product-selector" class="form-control" style="width: 300px; padding: 0.5rem;">
                                    <option value="">-- Add an Item from Inventory --</option>
                                    <?php foreach ($allProducts as $product): ?>
                                    <option value="<?php echo $product['id']; ?>" data-details='<?php echo json_encode($product, JSON_HEX_APOS); ?>'>
                                        <?php echo h($product['name']); ?> (<?php echo format_currency($product['price']); ?>)
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="table-responsive">
                                <table id="estimate-items-table">
                                    <thead><tr><th width="50%">Description</th><th width="15%">HSN/SAC</th><th width="10%">Qty</th><th width="10%">Rate</th><th width="15%">Amount</th><th>Action</th></tr></thead>
                                    <tbody id="estimate-items-body"></tbody>
                                </table>
                            </div>
                             <button type="button" class="btn btn-outline btn-sm mt-2" onclick="addEstimateItem()"><i class="fas fa-plus btn-icon"></i> Add Custom Item</button>
                        </div>
                        
                        <!-- Totals & Notes -->
                        <div class="flex flex-wrap gap-4">
                            <div class="form-col" style="min-width: 300px;">
                                <label for="estimate_notes">Notes / Terms</label>
                                <textarea id="estimate_notes" name="notes" rows="8"><?php echo h($company->default_notes); ?></textarea>
                            </div>
                            <div class="form-col" style="flex-grow: 2;">
                                <table class="totals-table" style="float: right; width: 100%; max-width: 400px;">
                                    <tr><td>Subtotal:</td><td class="text-right">₹ <span id="estimate_subtotal_display">0.00</span></td></tr>
                                    <tr>
                                        <td><label>Discount (%):</label> <input type="number" id="estimate_discount_rate" name="discount_rate" value="0.00" min="0" max="100" step="0.01"></td>
                                        <td class="text-right" style="color:#e67e22;">- ₹ <span id="estimate_discount_amount_display">0.00</span></td>
                                    </tr>
                                    <tr><td colspan="2"><hr style="border-top:1px solid var(--border-color); margin: 4px 0;"></td></tr>
                                    <tr><td class="font-semibold">Taxable Amount:</td><td class="text-right font-semibold">₹ <span id="estimate_taxable_display">0.00</span></td></tr>
                                    <tr>
                                        <td>
                                            <label>Tax Rate:</label> 
                                            <select id="estimate_tax_rate_select" style="max-width: 150px; display:inline-block; padding: 0.3rem 0.5rem; height: auto;">
                                            <?php foreach ($allTaxRates as $tax): ?>
                                                <option value="<?php echo (float)$tax['rate']; ?>" <?php echo $tax['is_default'] ? 'selected' : ''; ?>><?php echo h($tax['name']); ?></option>
                                            <?php endforeach; ?>
                                            </select>
                                        </td>
                                        <td class="text-right">₹ <span id="estimate_tax_amount_display">0.00</span></td>
                                    </tr>
                                    <tr class="grand-total"><td >Total:</td><td class="text-right">₹ <span id="estimate_total_display">0.00</span></td></tr>
                                </table>
                            </div>
                        </div>
                        
                        <!-- Action Buttons -->
                        <div class="action-buttons mt-4">
                            <button type="button" class="btn btn-outline" onclick="resetEstimateForm()">Cancel / New</button>
                            <button type="submit" class="btn btn-primary">Save Estimate</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Include Modals and Footer
require_once __DIR__ . '/partials/modals.php';
require_once __DIR__ . '/partials/footer.php';
?>