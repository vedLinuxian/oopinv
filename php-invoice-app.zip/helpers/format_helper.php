<?php
/**
 * =====================================================================================
 * Formatting Helper Functions
 * =====================================================================================
 *
 * This file provides utility functions for consistently formatting data, such as dates
 * and monetary values, for display in the views.
 *
 */

if (!function_exists('format_currency')) {
    /**
     * Formats a numeric value as Indian Rupee (INR) currency.
     *
     * Example: format_currency(12345.67) -> "12,345.67"
     *
     * @param float|string|null $amount The numeric amount to format.
     * @param int $decimals The number of decimal places.
     * @return string The formatted currency string. Returns "0.00" if input is invalid.
     */
    function format_currency($amount, int $decimals = 2): string
    {
        if (!is_numeric($amount)) {
            return number_format(0, $decimals);
        }
        return number_format((float)$amount, $decimals);
    }
}


if (!function_exists('format_date')) {
    /**
     * Formats a date string into a more readable format (e.g., d-m-Y).
     *
     * Example: format_date("2025-10-23") -> "23-10-2025"
     *
     * @param string|null $date_string A string parsable by strtotime() (e.g., Y-m-d).
     * @param string $format The desired output format as per PHP's date() function.
     * @return string The formatted date string, or an empty string if input is invalid.
     */
    function format_date(?string $date_string, string $format = 'd-m-Y'): string
    {
        if (empty($date_string) || $date_string === '0000-00-00') {
            return '';
        }
        try {
            // Using DateTime for more robust parsing
            $date = new DateTime($date_string);
            return $date->format($format);
        } catch (Exception $e) {
            // Log the error if date parsing fails for an unknown reason
            error_log("Failed to parse date string in format_date(): " . $date_string);
            return ''; // Return empty string on failure
        }
    }
}


if (!function_exists('h')) {
    /**
     * A shorthand alias for htmlspecialchars to prevent XSS attacks.
     * This is a critical security function.
     *
     * @param string|null $text The raw text to be outputted to HTML.
     * @return string The safely escaped text.
     */
    function h(?string $text): string
    {
        return htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8');
    }
}