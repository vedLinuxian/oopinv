<?php
/**
 * =====================================================================================
 * Session Helper Functions
 * =====================================================================================
 *
 * This file provides utility functions for managing session-based flash messages.
 * Flash messages are used to display status messages (like "Success!" or "Error!")
 * across page loads.
 *
 */

if (!function_exists('set_flash_message')) {
    /**
     * Sets a flash message in the session.
     *
     * @param string $type The type of message ('success', 'error', 'warning', 'info').
     * @param string $message The message content.
     */
    function set_flash_message(string $type, string $message): void
    {
        // Store the message and its type in a session array.
        $_SESSION['flash_messages'][] = [
            'type' => $type,
            'message' => $message
        ];
    }
}

if (!function_exists('display_flash_messages')) {
    /**
     * Displays all stored flash messages and then clears them from the session.
     * Generates HTML markup for the alerts.
     */
    function display_flash_messages(): void
    {
        if (isset($_SESSION['flash_messages']) && is_array($_SESSION['flash_messages'])) {
            
            foreach ($_SESSION['flash_messages'] as $flash) {
                // Sanitize type and message before outputting
                $type = htmlspecialchars($flash['type'] ?? 'info', ENT_QUOTES, 'UTF-8');
                $message = htmlspecialchars($flash['message'] ?? '', ENT_QUOTES, 'UTF-8');
                
                // Map the type to a CSS class and an icon
                $icon = '';
                switch ($type) {
                    case 'success':
                        $icon = '✓';
                        break;
                    case 'error':
                        $icon = '✗';
                        break;
                    case 'warning':
                        $icon = '⚠️';
                        break;
                    case 'info':
                    default:
                        $icon = 'ℹ️';
                        break;
                }

                // Use HEREDOC for clean HTML output
                echo <<<HTML
                <div class="alert alert-{$type}" id="php-flash-message-{$type}">
                    <div class="alert-icon">{$icon}</div>
                    <div>{$message}</div>
                </div>
HTML;
            }

            // Clear the flash messages from the session so they don't show again.
            unset($_SESSION['flash_messages']);
        }
    }
}