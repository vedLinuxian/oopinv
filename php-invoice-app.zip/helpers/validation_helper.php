<?php
/**
 * =====================================================================================
 * Validation Helper Functions
 * =====================================================================================
 *
 * This file provides utility functions for validating user-submitted data.
 * It helps ensure that data conforms to expected formats and rules before being
 * processed or saved to the database.
 *
 */

if (!function_exists('is_valid_email')) {
    /**
     * Validates if a string is a well-formed email address.
     *
     * @param string|null $email The email string to validate.
     * @return bool True if the email is valid, false otherwise.
     */
    function is_valid_email(?string $email): bool
    {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
}

if (!function_exists('is_not_empty')) {
    /**
     * Checks if a string is not null and not empty after trimming whitespace.
     *
     * @param string|null $value The string to check.
     * @return bool True if the value is not empty, false otherwise.
     */
    function is_not_empty(?string $value): bool
    {
        return $value !== null && trim($value) !== '';
    }
}

if (!function_exists('is_valid_gstin')) {
    /**
     * Validates if a string matches the Indian GSTIN format.
     * Format: 2-digit state code, 10-char PAN, 1-digit entity code, 'Z', 1-char checksum.
     *
     * @param string|null $gstin The GSTIN string to validate.
     * @return bool True if the format is valid, false otherwise.
     */
    function is_valid_gstin(?string $gstin): bool
    {
        if (empty($gstin)) {
            // GSTIN is often optional, so an empty string can be considered 'valid' in that context.
            // The calling script should first check if it's required.
            return true;
        }
        $pattern = "/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/";
        return preg_match($pattern, $gstin) === 1;
    }
}


if (!function_exists('sanitize_input')) {
    /**
     * A general-purpose sanitization function to strip tags and optionally trim.
     * NOTE: For database inputs, use PDO prepared statements instead of manual sanitization.
     * This function is primarily for cleaning data before display or for non-SQL contexts.
     *
     * @param string|null $input The raw input string.
     * @param bool $trim Whether to trim whitespace from the beginning and end.
     * @return string The sanitized string.
     */
    function sanitize_input(?string $input, bool $trim = true): string
    {
        if ($input === null) {
            return '';
        }

        // Remove HTML and PHP tags from a string
        $sanitized = strip_tags($input);
        
        if ($trim) {
            $sanitized = trim($sanitized);
        }
        
        return $sanitized;
    }
}