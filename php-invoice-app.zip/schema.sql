-- =================================================================================
-- DATABASE SCHEMA FOR OOP INVOICE GENERATOR
-- =================================================================================

-- Set a safe mode to prevent accidental deletion of tables
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


-- ---------------------------------------------------------------------------------
-- TABLE: `roles` (New)
-- Purpose: Stores user roles and their permissions for RBAC.
-- ---------------------------------------------------------------------------------
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT 'e.g., Admin, Staff',
  `permissions` text COMMENT 'JSON-encoded array of permission strings',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default roles. Admin has wildcard '*', Staff has specific permissions.
INSERT INTO `roles` (`id`, `name`, `permissions`) VALUES
(1, 'Admin', '[\"*\"]'),
(2, 'Staff', '[\"create_invoice\", \"edit_invoice\", \"view_reports\", \"manage_clients\", \"manage_products\"]');


-- ---------------------------------------------------------------------------------
-- TABLE: `users` (Alteration)
-- Purpose: Add `role_id` to link users to the roles table.
-- ---------------------------------------------------------------------------------
ALTER TABLE `users` 
  ADD `role_id` int(11) DEFAULT 2,
  ADD `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  ADD CONSTRAINT `fk_user_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- Update the first existing user to be an 'Admin'
UPDATE `users` ORDER BY id LIMIT 1 SET `role_id` = 1;


-- ---------------------------------------------------------------------------------
-- TABLE: `products` (New)
-- Purpose: Manages the product/service inventory.
-- ---------------------------------------------------------------------------------
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `hsn_code` varchar(20) DEFAULT NULL,
  `price` decimal(15,2) NOT NULL DEFAULT 0.00,
  `stock_quantity` int(11) DEFAULT NULL COMMENT 'NULL for services/untracked items',
  `low_stock_threshold` int(11) DEFAULT NULL COMMENT 'Alert when stock drops to this level',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `fk_product_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------------------------------------------------
-- TABLE: `tax_rates` (New)
-- Purpose: Allows admins to manage GST tax slabs.
-- ---------------------------------------------------------------------------------
CREATE TABLE `tax_rates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL COMMENT 'e.g., "Standard GST", "GST Exempt"',
  `rate` decimal(5,2) NOT NULL COMMENT 'The combined GST rate, e.g., 18.00 for 18%',
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `fk_taxrate_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert common tax rates for the first admin user
INSERT INTO `tax_rates` (`name`, `rate`, `user_id`, `is_default`)
SELECT 'GST 18%', 18.00, id, 1 FROM `users` WHERE `role_id`=1 ORDER BY id LIMIT 1;

INSERT INTO `tax_rates` (`name`, `rate`, `user_id`, `is_default`)
SELECT 'GST 12%', 12.00, id, 0 FROM `users` WHERE `role_id`=1 ORDER BY id LIMIT 1;

INSERT INTO `tax_rates` (`name`, `rate`, `user_id`, `is_default`)
SELECT 'GST 5%', 5.00, id, 0 FROM `users` WHERE `role_id`=1 ORDER BY id LIMIT 1;

INSERT INTO `tax_rates` (`name`, `rate`, `user_id`, `is_default`)
SELECT 'GST Exempt', 0.00, id, 0 FROM `users` WHERE `role_id`=1 ORDER BY id LIMIT 1;


-- ---------------------------------------------------------------------------------
-- MINOR ALTERATIONS AND INDEXING
-- ---------------------------------------------------------------------------------

-- Add an index to clients.user_id for faster lookups.
ALTER TABLE `clients` 
  ADD INDEX `user_id` (`user_id`);

-- Make sure clients state field can hold full state names.
ALTER TABLE `clients`
  MODIFY `state` varchar(100) DEFAULT NULL;

-- Add an index to invoices.user_id.
ALTER TABLE `invoices` 
  ADD INDEX `user_id` (`user_id`);

-- Add user_id index for company and bank tables for consistency
ALTER TABLE `companies` 
  ADD INDEX `user_id` (`user_id`);

-- Assuming the user_banks table exists from the previous app, adding user_id index
ALTER TABLE `user_banks` 
  ADD INDEX `user_id` (`user_id`);
  
-- Add user_id to estimates table if it doesn't exist, and add an index.
-- This part is defensive. Run only if your `estimates` table might be missing the column/index.
ALTER TABLE `estimates`
  ADD COLUMN IF NOT EXISTS `user_id` INT(11) NOT NULL AFTER `id`,
  ADD INDEX IF NOT EXISTS `user_id` (`user_id`);


-- End of Schema Script
-- =================================================================================