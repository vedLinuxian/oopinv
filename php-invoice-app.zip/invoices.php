<?php
/**
 * =====================================================================================
 * Invoices Page Controller (Create/Edit)
 * =====================================================================================
 *
 * This script serves as the controller for creating and editing invoices.
 * - It handles two main actions via a GET parameter: 'create' and 'edit'.
 * - For 'edit', it fetches existing invoice data to pre-populate the form.
 * - For 'create', it prepares default values.
 * - It gathers necessary data for form dropdowns (clients, products, tax rates).
 * - It renders the complete invoice form.
 *
 */

// Step 1: Bootstrap and Authenticate
require_once __DIR__ . '/config/config.php';
$db = Database::getInstance();
$auth = new Auth($db);
$auth->requireLogin();
$currentUser = $auth->getUser();

// Step 2: Determine Action (Create or Edit)
$action = $_GET['action'] ?? 'create';
$invoice_id = ($action === 'edit') ? (int)($_GET['id'] ?? 0) : null;
$invoiceData = null;
$invoiceItems = [];

$pageTitle = ($action === 'edit') ? 'Edit Invoice' : 'Create New Invoice';

// Step 3: Fetch Data based on Action
$invoiceModel = new Invoice($db);
$clientModel = new Client($db);
$company = new Company($db);
$company->loadByUser($currentUser->id);


if ($action === 'edit') {
    if (!$invoice_id) {
        set_flash_message('error', 'Invalid invoice ID specified for editing.');
        header('Location: ' . BASE_URL . 'index.php');
        exit();
    }
    // findByIdForUser also fetches items
    $invoiceData = $invoiceModel->findByIdForUser($invoice_id, $currentUser->id);
    if (!$invoiceData) {
        set_flash_message('error', 'Invoice not found or you do not have permission to view it.');
        header('Location: ' . BASE_URL . 'index.php');
        exit();
    }
    $invoiceItems = $invoiceData['items'] ?? [];
    $pageTitle = 'Edit Invoice #' . h($invoiceData['invoice_number']);
} else { // 'create' action
    $invoiceData = [
        'id' => null,
        'invoice_number' => $invoiceModel->generateNextInvoiceNumber($currentUser->id),
        'invoice_date' => date('Y-m-d'),
        'due_date' => date('Y-m-d'),
        'client_id' => null,
        'status' => 'unpaid',
        'discount_rate' => '0.00',
        'notes' => $company->default_notes ?? ''
        // Other fields will default to NULL or 0
    ];
}

// Fetch data needed for form dropdowns
$allClients = $clientModel->findAllForUser($currentUser->id, 1000, 0); // Get all clients for dropdown
$allProducts = (new Product($db))->findAllForUser($currentUser->id, 1000, 0);
$allTaxRates = TaxRate::findAllForUser($db, $currentUser->id);
$allBanks = (new Bank($db))->findAllForUser($currentUser->id); // We'll create Bank.php next

// If creating a new invoice, set default CGST/SGST from the default tax rate
if ($action === 'create') {
    $defaultTaxRate = 0.00;
    foreach($allTaxRates as $tax) {
        if ($tax['is_default']) {
            $defaultTaxRate = (float)$tax['rate'];
            break;
        }
    }
    $invoiceData['cgst_rate'] = $defaultTaxRate / 2;
    $invoiceData['sgst_rate'] = $defaultTaxRate / 2;
}


// Step 4: Include Header
require_once __DIR__ . '/partials/header.php';
?>

<!-- Form is wrapped in main-content without the sidebar -->
<div class="main-content" style="flex: 1 1 100%;">
    <div class="card">
        <div class="card-body">
            
            <form id="invoice-form" onsubmit="event.preventDefault(); saveInvoice(this);">
                <input type="hidden" name="id" value="<?php echo h($invoiceData['id']); ?>">
                <input type="hidden" id="taxable-amount-hidden"> <!-- JS uses this -->

                <!-- Invoice Header -->
                <div class="box">
                    <h3 class="box-title">Invoice Details</h3>
                    <div class="form-row">
                        <div class="form-col">
                            <label for="invoice_number">Invoice Number</label>
                            <input type="text" id="invoice_number" name="invoice_number" value="<?php echo h($invoiceData['invoice_number']); ?>" readonly>
                        </div>
                        <div class="form-col">
                            <label for="invoice_date">Invoice Date *</label>
                            <input type="date" id="invoice_date" name="invoice_date" value="<?php echo h($invoiceData['invoice_date']); ?>" required>
                        </div>
                        <div class="form-col">
                            <label for="due_date">Due Date</label>
                            <input type="date" id="due_date" name="due_date" value="<?php echo h($invoiceData['due_date'] ?? ''); ?>">
                        </div>
                    </div>
                </div>

                <!-- Client and Bank Details -->
                <div class="box">
                     <h3 class="box-title">Client &amp; Bank</h3>
                     <div class="form-row">
                        <div class="form-col">
                            <label for="client_id">Select Client *</label>
                            <select id="client_id" name="client_id" required>
                                <option value="">-- Select a Client --</option>
                                <?php foreach ($allClients as $client): ?>
                                    <option value="<?php echo $client['id']; ?>" <?php echo ($invoiceData['client_id'] == $client['id']) ? 'selected' : ''; ?>>
                                        <?php echo h($client['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-col">
                            <label for="bank_account_id">Bank Account (Optional)</label>
                            <select id="bank_account_id" name="bank_account_id">
                                <option value="">-- No Bank Details --</option>
                                <?php foreach ($allBanks as $bank): ?>
                                    <option value="<?php echo $bank['id']; ?>" <?php echo ($invoiceData['bank_account_id'] == $bank['id']) ? 'selected' : ''; ?>>
                                        <?php echo h($bank['bank_name']) . ' (...' . substr($bank['account_number'], -4) . ')'; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Invoice Items -->
                <div class="box">
                    <h3 class="box-title">Invoice Items *</h3>
                    <div id="item-options-bar" class="flex justify-between items-center mb-2">
                        <select id="product-selector" class="form-control" style="width: 300px; padding: 0.5rem;">
                            <option value="">-- Select an Item to Add --</option>
                             <?php foreach ($allProducts as $product): ?>
                                <option value="<?php echo $product['id']; ?>" 
                                        data-name="<?php echo h($product['name']); ?>" 
                                        data-description="<?php echo h($product['description']); ?>" 
                                        data-hsn="<?php echo h($product['hsn_code']); ?>" 
                                        data-price="<?php echo $product['price']; ?>">
                                    <?php echo h($product['name']); ?> (<?php echo format_currency($product['price']); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div>
                             <input type="checkbox" id="allow-custom-item" checked>
                             <label for="allow-custom-item" style="display:inline; font-weight:normal;">Allow Custom Items</label>
                        </div>
                    </div>
                    
                    <div class="table-responsive">
                        <table id="items-table">
                            <thead><tr><th width="45%">Description</th><th width="15%">HSN/SAC</th><th width="10%">Qty</th><th width="15%">Rate (₹)</th><th width="15%">Amount (₹)</th><th class="text-center">Action</th></tr></thead>
                            <tbody id="invoice-items-body">
                                <!-- JS will populate items here, but we can render existing items for edit -->
                                <?php if (!empty($invoiceItems)): ?>
                                    <?php foreach ($invoiceItems as $item): ?>
                                    <tr class="item-row">
                                        <td><textarea name="items[description][]" class="item-description" required rows="1"><?php echo h($item['description']); ?></textarea></td>
                                        <td><input type="text" name="items[hsn][]" class="item-hsn" value="<?php echo h($item['hsn_code'] ?? ''); ?>"></td>
                                        <td><input type="number" name="items[quantity][]" class="item-quantity" value="<?php echo number_format($item['quantity'], 2); ?>" step="any" min="0" required></td>
                                        <td><input type="number" name="items[rate][]" class="item-rate" value="<?php echo number_format($item['rate'], 2); ?>" step="any" min="0" required></td>
                                        <td><input type="text" name="items[amount][]" class="item-amount" readonly></td>
                                        <td class="text-center"><button type="button" class="btn btn-danger btn-sm remove-item">&times;</button></td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <button type="button" class="btn btn-outline btn-sm mt-2" id="add-item-btn"><i class="fas fa-plus btn-icon"></i> Add Custom Item</button>
                </div>

                <!-- Totals & Notes -->
                 <div class="flex flex-wrap gap-4">
                     <div class="form-col" style="min-width: 300px;">
                        <label for="notes">Notes / Terms & Conditions</label>
                        <textarea id="notes" name="notes" rows="5"><?php echo h($invoiceData['notes']); ?></textarea>
                     </div>
                     <div class="form-col text-right" style="flex-grow: 2;">
                        <table class="totals-table" style="float: right; width: 100%; max-width: 400px;">
                            <!-- ... Totals table structure ... -->
                        </table>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="action-buttons mt-4">
                    <a href="<?php echo BASE_URL; ?>index.php" class="btn btn-outline">Cancel</a>
                    <button type="submit" class="btn btn-primary">
                        <?php echo ($action === 'edit' ? '<i class="fas fa-save btn-icon"></i> Update' : '<i class="fas fa-paper-plane btn-icon"></i> Create'); ?> Invoice
                    </button>
                </div>

            </form>
        </div>
    </div>
</div>

<?php
require_once __DIR__ . '/partials/modals.php';
require_once __DIR__ . '/partials/footer.php';
?>