<?php
/**
 * =====================================================================================
 * Tax Rates Management Page
 * =====================================================================================
 *
 * This script provides the UI for managing GST tax slabs.
 * - Requires an authenticated user with 'manage_taxes' permission (future RBAC).
 * - Lists all configurable tax rates for the user.
 * - Allows creating, updating, and deleting tax rates via a modal form.
 *
 */

// Step 1: Bootstrap the application
require_once __DIR__ . '/config/config.php';

// Step 2: Authentication & Authorization
$db = Database::getInstance();
$auth = new Auth($db);
$auth->requireLogin();
$currentUser = $auth->getUser();

// Future RBAC check: Redirect if the user doesn't have permission.
// if (!$auth->can('manage_taxes')) {
//     set_flash_message('error', 'You do not have permission to access that page.');
//     header('Location: ' . BASE_URL . 'index.php');
//     exit();
// }


// Step 3: Fetch Data for the View
$pageTitle = 'Manage Tax Rates (GST)';
$initialTaxRates = TaxRate::findAllForUser($db, $currentUser->id);

$company = new Company($db);
$company->loadByUser($currentUser->id);

// Step 4: Include Header
require_once __DIR__ . '/partials/header.php';
?>

<!-- Main Content Wrapper -->
<div class="content-wrapper">

    <!-- Sidebar Partial -->
    <?php require_once __DIR__ . '/partials/sidebar.php'; ?>

    <!-- Main Content Area -->
    <div class="main-content">
        <div class="card">
            <div class="card-body">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-lg font-semibold">Your Tax Slabs</h2>
                    <button type="button" class="btn btn-primary btn-sm" onclick="openTaxRateModal()">
                        <i class="fas fa-plus btn-icon"></i> Add New Tax Rate
                    </button>
                </div>

                <!-- Tax Rate List Table -->
                <div class="table-responsive">
                    <table id="tax-rates-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th class="text-right">Rate (%)</th>
                                <th class="text-center">Default</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="tax-rates-table-body">
                            <?php if (!empty($initialTaxRates)): ?>
                                <?php foreach ($initialTaxRates as $taxRate): ?>
                                    <tr>
                                        <td class="font-semibold"><?php echo h($taxRate['name']); ?></td>
                                        <td class="text-right"><?php echo number_format((float)$taxRate['rate'], 2); ?>%</td>
                                        <td class="text-center">
                                            <?php if ($taxRate['is_default']): ?>
                                                <i class="fas fa-star" style="color: var(--accent);" title="Default Tax Rate"></i>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <div class="btn-group">
                                                <button class="btn btn-outline btn-sm" title="Edit Tax Rate" onclick='openTaxRateModal(<?php echo json_encode($taxRate, JSON_HEX_APOS); ?>)'>
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button class="btn btn-danger btn-sm" title="Delete Tax Rate" onclick="deleteTaxRate(<?php echo $taxRate['id']; ?>, this)">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" class="empty-table">No tax rates found. Click "Add New" to create one.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div> <!-- /.card-body -->
        </div> <!-- /.card -->
    </div> <!-- /.main-content -->
</div> <!-- /.content-wrapper -->

<!-- Tax Rate Add/Edit Modal (This should eventually be moved to modals.php) -->
<div id="tax-rate-modal" class="modal">
    <div class="modal-content" style="max-width: 500px;">
        <form id="tax-rate-form" onsubmit="event.preventDefault(); saveTaxRate(this);">
            <div class="modal-header">
                <h2 class="modal-title" id="tax-rate-modal-title">Add New Tax Rate</h2>
                <button type="button" class="modal-close" onclick="closeTaxRateModal()">&times;</button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="tax_rate_form_id" name="id" value="">
                
                <div class="form-group">
                    <label for="tax_rate_name">Rate Name <span class="text-danger">*</span></label>
                    <input type="text" id="tax_rate_name" name="name" required placeholder="e.g., GST 18%">
                </div>
                
                <div class="form-group">
                    <label for="tax_rate_rate">Rate (%) <span class="text-danger">*</span></label>
                    <input type="number" id="tax_rate_rate" name="rate" required step="0.01" min="0" placeholder="e.g., 18.00">
                </div>

                <div class="form-group">
                    <input type="checkbox" id="tax_rate_is_default" name="is_default" value="1">
                    <label for="tax_rate_is_default" style="display: inline; font-weight: normal;">
                        Set as the default tax rate for new invoices.
                    </label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeTaxRateModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Tax Rate</button>
            </div>
        </form>
    </div>
</div>

<?php
// Step 5: Include main Modals and Footer
require_once __DIR__ . '/partials/modals.php';
require_once __DIR__ . '/partials/footer.php';
?>