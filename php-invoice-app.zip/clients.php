<?php
/**
 * =====================================================================================
 * Clients Management Page
 * =====================================================================================
 *
 * This script serves as the main interface for managing clients.
 * - It requires a user to be logged in.
 * - It provides the UI for listing, searching, creating, updating, and deleting clients.
 * - It loads the first page of clients server-side for fast initial rendering.
 * - Subsequent interactions (pagination, search, save, delete) are handled by `app.js`
 *   via AJAX calls to `api.php`.
 *
 */

// Step 1: Bootstrap the application
require_once __DIR__ . '/config/config.php';

// Step 2: Authentication
$db = Database::getInstance();
$auth = new Auth($db);
$auth->requireLogin();
$currentUser = $auth->getUser();

// Step 3: Fetch Data for the View
// This page is dedicated to clients, so it's the main data point.
$pageTitle = 'Manage Clients'; // Set the title for the header

// Fetch initial data for the first-page load
$clientModel = new Client($db);
$page = 1;
$limit = 10; // This should match CLIENTS_PER_PAGE in app.js
$search = ''; // No initial search
$initialClients = $clientModel->findAllForUser($currentUser->id, $limit, 0, $search);
$totalClients = $clientModel->countForUser($currentUser->id, $search);

// We still need company data for the sidebar partial
$company = new Company($db);
$company->loadByUser($currentUser->id);

// Step 4: Include Header
require_once __DIR__ . '/partials/header.php';
?>

<!-- Main Content Wrapper (matches index.php for consistent layout) -->
<div class="content-wrapper">

    <!-- Sidebar Partial -->
    <?php require_once __DIR__ . '/partials/sidebar.php'; ?>

    <!-- Main Content Area -->
    <div class="main-content">
        <div class="card">
            <div class="card-body">
                <div class="flex justify-between items-center mb-4 flex-wrap gap-2">
                    <h2 class="text-lg font-semibold">Your Clients (<?php echo $totalClients; ?>)</h2>
                    <button type="button" class="btn btn-primary btn-sm" onclick="openClientModal()">
                        <i class="fas fa-user-plus btn-icon"></i> Add New Client
                    </button>
                </div>

                <!-- Search Input -->
                <div class="form-group mb-4">
                    <label for="client_search_tab" class="sr-only">Search Clients</label>
                    <input type="text" id="client_search_tab" placeholder="Search by Name, GSTIN, Email, Address...">
                </div>

                <!-- Client List Table -->
                <div class="table-responsive">
                    <table id="clients-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>GSTIN</th>
                                <th>State</th>
                                <th>Contact</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="clients-table-body">
                            <?php if (!empty($initialClients)): ?>
                                <?php foreach ($initialClients as $client): ?>
                                    <tr>
                                        <td class="font-semibold"><?php echo h($client['name']); ?></td>
                                        <td><?php echo h($client['gstin'] ?? '-'); ?></td>
                                        <td><?php echo h($client['state'] ?? '-'); ?></td>
                                        <td class="text-xs">
                                            <?php if(!empty($client['phone'])): ?>
                                                Ph: <?php echo h($client['phone']); ?><br>
                                            <?php endif; ?>
                                            <?php if(!empty($client['email'])): ?>
                                                @: <?php echo h($client['email']); ?>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <div class="btn-group">
                                                <button class="btn btn-outline btn-sm" title="Edit Client" onclick="openClientModal(<?php echo $client['id']; ?>)">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button class="btn btn-danger btn-sm" title="Delete Client" onclick="deleteClient(<?php echo $client['id']; ?>, this)">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="empty-table">No clients found. Click "Add New Client" to start.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination container for JavaScript -->
                <div id="client-pagination" class="pagination" style="<?php echo ($totalClients <= $limit) ? 'display: none;' : ''; ?>">
                    <!-- JS will render pagination here -->
                </div>

            </div> <!-- /.card-body -->
        </div> <!-- /.card -->
    </div> <!-- /.main-content -->
</div> <!-- /.content-wrapper -->

<?php
// Step 5: Include Modals and Footer
// This ensures the client modal is available on this page.
require_once __DIR__ . '/partials/modals.php';
require_once __DIR__ . '/partials/footer.php';
?>