<?php
// Include database configuration
// db_config.php ensures session is started if not already active
require_once 'db_config.php';

// Initialize variables
$username = $password = "";
$username_err = $password_err = $login_err = "";

// Process login form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Validate username
    if (empty(trim($_POST["username"]))) {
        $username_err = "Please enter username.";
    } else {
        $username = trim($_POST["username"]);
    }

    // Validate password
    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter your password.";
    } else {
        $password = trim($_POST["password"]);
    }

    // Check input errors before validating in database
    if (empty($username_err) && empty($password_err)) {
        // Prepare a select statement
        $sql = "SELECT id, username, password FROM users WHERE username = :username";

        $result = query($conn, $sql, ['username' => $username]);

        if ($result) {
            if (fetch_count($conn, $result) == 1) {
                $user = fetch_one($result);

                // Verify password
                if (password_verify($password, $user["password"])) {
                    // Password is correct, session should already be started by db_config.php
                    // No need to call session_start() again here.

                    // Regenerate session ID for security upon successful login
                    session_regenerate_id(true);

                    // Store data in session variables
                    $_SESSION["loggedin"] = true;
                    $_SESSION["id"] = $user["id"];
                    $_SESSION["username"] = $user["username"];

                    // Redirect user to welcome page
                    header("location: index.php");
                    exit;
                } else {
                    // Password is not valid
                    $login_err = "Invalid username or password.";
                }
            } else {
                // Username doesn't exist
                $login_err = "Invalid username or password.";
            }
        } else {
             // Query itself failed
             $db_error = mysqli_error($conn); // Get specific DB error if possible
            error_log("Login query failed for username '{$username}': " . $db_error);
             $login_err = "Oops! Something went wrong. Please try again later.";
         }
     } // End validation check
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - GST Invoice Generator</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #1e40af;
            --primary-light: #3b82f6;
            --primary-dark: #1e3a8a;
            --secondary: #64748b;
            --accent: #f59e0b;
            --danger: #ef4444;
            --success: #10b981;
            --warning: #f59e0b;
            --info: #3b82f6;
            --light: #f8fafc;
            --dark: #1e293b;
            --body-bg: #f1f5f9;
            --card-bg: #ffffff;
            --border-color: #e2e8f0;
            --text-primary: #334155;
            --text-secondary: #64748b;
            --text-muted: #94a3b8;
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            --radius-sm: 0.125rem;
            --radius: 0.25rem;
            --radius-md: 0.375rem;
            --radius-lg: 0.5rem;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--body-bg);
            color: var(--text-primary);
            line-height: 1.6;
            font-size: 14px;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-container {
            width: 100%;
            max-width: 400px;
            margin: 0 auto;
            padding: 2rem;
        }

        .login-header {
            text-align: center;
            margin-bottom: 2rem;
        }

        .login-header h1 {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary);
            margin-bottom: 0.5rem;
        }

        .login-header p {
            color: var(--text-secondary);
        }

        .login-form {
            background: var(--card-bg);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-md);
            padding: 2rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        label {
            display: block;
            font-weight: 500;
            margin-bottom: 0.5rem;
            color: var(--text-primary);
        }

        input {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid var(--border-color);
            border-radius: var(--radius);
            font-family: inherit;
            font-size: 0.875rem;
            color: var(--text-primary);
            background-color: white;
            transition: border-color 0.2s ease, box-shadow 0.2s ease;
        }

        input:focus {
            outline: none;
            border-color: var(--primary-light);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.25);
        }

        .error {
            color: var(--danger);
            font-size: 0.75rem;
            margin-top: 0.25rem;
        }

        .alert {
            padding: 0.75rem 1rem;
            border-radius: var(--radius);
            margin-bottom: 1.5rem;
            font-size: 0.875rem;
        }

        .alert-danger {
            background-color: rgba(239, 68, 68, 0.1);
            color: var(--danger);
            border-left: 3px solid var(--danger);
        }

        .btn {
            display: inline-block;
            width: 100%;
            padding: 0.75rem 1rem;
            background-color: var(--primary);
            color: white;
            font-weight: 500;
            text-align: center;
            border: none;
            border-radius: var(--radius);
            cursor: pointer;
            transition: background-color 0.2s ease;
        }

        .btn:hover {
            background-color: var(--primary-dark);
        }

        .register-link {
            text-align: center;
            margin-top: 1.5rem;
            font-size: 0.875rem;
            color: var(--text-secondary);
        }

        .register-link a {
            color: var(--primary);
            text-decoration: none;
        }

        .register-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <h1>Invoice Generator</h1>
            <p>Log in to access your account</p>
        </div>

        <div class="login-form">
            <?php
            if (!empty($login_err)) {
                echo '<div class="alert alert-danger">' . htmlspecialchars($login_err) . '</div>'; // Use htmlspecialchars
            }
            ?>

            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="form-group">
                    <label for="username">Username</label> <!-- Add 'for' attribute -->
                    <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($username); ?>"> <!-- Use htmlspecialchars -->
                    <span class="error"><?php echo $username_err; ?></span>
                </div>

                <div class="form-group">
                    <label for="password">Password</label> <!-- Add 'for' attribute -->
                    <input type="password" id="password" name="password">
                    <span class="error"><?php echo $password_err; ?></span>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn">Login</button>
                </div>

                <div class="register-link">
                    Don't have an account? <a href="register.php">Sign up now</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>