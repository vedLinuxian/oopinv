<?php
// Include database configuration
require_once 'db_config.php'; // Ensures session is started via db_config.php

// Check if the user is logged in, if not redirect to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}

// Get user information
$user_id = $_SESSION["id"];
$username = $_SESSION["username"];

// Constants for Upload
define('UPLOAD_DIR_QR', 'uploads/qr_codes/');
define('UPLOAD_DIR_STAMP', 'uploads/stamps/');
define('MAX_FILE_SIZE', 1024 * 1024); // 1 MB
$allowed_types = ['image/jpeg', 'image/png', 'image/gif'];

// --- Fetch User's company details (needed before POST processing) ---
$company = [];
$sql_get_company = "SELECT * FROM companies WHERE user_id = :user_id LIMIT 1";
$result_get_company = query($conn, $sql_get_company, ['user_id' => $user_id]);
if ($result_get_company && fetch_count($conn, $result_get_company) > 0) {
    $company = fetch_one($result_get_company);
}

// Initialize messages
$message = $_SESSION['message'] ?? ''; unset($_SESSION['message']); // Use session for flash messages
$error = $_SESSION['error_message'] ?? ''; unset($_SESSION['error_message']);

// --- Process Company Save ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["save_company"])) {
    // Basic company info
    $company_name = sanitize($conn, $_POST["company_name"]);
    $company_address = sanitize($conn, $_POST["company_address"]);
    $company_phone = sanitize($conn, $_POST["company_phone"]);
    $company_email_raw = $_POST["company_email"];
    $company_email = filter_var(trim($company_email_raw), FILTER_VALIDATE_EMAIL) ? sanitize_email($company_email_raw) : null;
    $company_website = sanitize($conn, $_POST["company_website"]);
    $company_gstin = sanitize($conn, $_POST["company_gstin"]);
    $company_default_notes = sanitize($conn, $_POST["company_default_notes"]);

    // Image handling
    $qr_code_path = $company['upi_qr_code_path'] ?? null;
    $stamp_path = $company['stamp_path'] ?? null;
    $upload_error = false;
    $upload_error_msg = '';
    $remove_qr = isset($_POST['remove_qr_code']) && $_POST['remove_qr_code'] == '1';
    $remove_stamp = isset($_POST['remove_stamp']) && $_POST['remove_stamp'] == '1';

    // Check/Create Upload Directories
    foreach ([UPLOAD_DIR_QR, UPLOAD_DIR_STAMP] as $dir) {
        if (!is_dir($dir)) { if (!@mkdir($dir, 0775, true)) { $upload_error_msg = "Error: Failed to create upload directory '$dir'."; $upload_error = true; error_log($upload_error_msg." User $user_id"); break; }
        } elseif (!is_writable($dir)) { $upload_error_msg = "Error: Upload directory '$dir' is not writable."; $upload_error = true; error_log($upload_error_msg." User $user_id"); break; }
    }

    // Process QR Code Upload/Removal
    if (!$upload_error) {
        if ($remove_qr && !empty($qr_code_path) && file_exists($qr_code_path)) { if (!@unlink($qr_code_path)) { error_log("Could not delete existing QR file: $qr_code_path"); } $qr_code_path = null;
        } elseif (isset($_FILES['company_upi_qr_code']) && $_FILES['company_upi_qr_code']['error'] == UPLOAD_ERR_OK && !$remove_qr) {
            $qr_file = $_FILES['company_upi_qr_code'];
            if ($qr_file['size'] > MAX_FILE_SIZE) { $upload_error_msg = "Error: QR Code file too large (Max 1MB)."; $upload_error = true; }
            elseif (!in_array(mime_content_type($qr_file['tmp_name']), $allowed_types)) { $upload_error_msg = "Error: Invalid QR Code file type (JPG, PNG, GIF)."; $upload_error = true; }
            else {
                $file_ext = strtolower(pathinfo($qr_file['name'], PATHINFO_EXTENSION)); $new_filename = 'user_' . $user_id . '_qr_' . time() . '.' . $file_ext; $dest_path = UPLOAD_DIR_QR . $new_filename;
                if (move_uploaded_file($qr_file['tmp_name'], $dest_path)) { if (!empty($qr_code_path) && file_exists($qr_code_path)) { @unlink($qr_code_path); } $qr_code_path = $dest_path;
                } else { $upload_error_msg = "Error: Failed to move uploaded QR Code file."; $upload_error = true; }
            }
        } elseif (isset($_FILES['company_upi_qr_code']) && $_FILES['company_upi_qr_code']['error'] != UPLOAD_ERR_NO_FILE && !$remove_qr) { $upload_error_msg = "Error uploading QR Code: " . $_FILES['company_upi_qr_code']['error']; $upload_error = true; }

         // Process Stamp Upload/Removal
         if (!$upload_error) {
             if ($remove_stamp && !empty($stamp_path) && file_exists($stamp_path)) { if (!@unlink($stamp_path)) { error_log("Could not delete existing Stamp file: $stamp_path"); } $stamp_path = null;
             } elseif (isset($_FILES['company_stamp']) && $_FILES['company_stamp']['error'] == UPLOAD_ERR_OK && !$remove_stamp) {
                 $stamp_file = $_FILES['company_stamp'];
                 if ($stamp_file['size'] > MAX_FILE_SIZE) { $upload_error_msg = "Error: Stamp file too large (Max 1MB)."; $upload_error = true; }
                 elseif (!in_array(mime_content_type($stamp_file['tmp_name']), $allowed_types)) { $upload_error_msg = "Error: Invalid Stamp file type (JPG, PNG, GIF)."; $upload_error = true; }
                 else {
                     $file_ext = strtolower(pathinfo($stamp_file['name'], PATHINFO_EXTENSION)); $new_filename = 'user_' . $user_id . '_stamp_' . time() . '.' . $file_ext; $dest_path = UPLOAD_DIR_STAMP . $new_filename;
                     if (move_uploaded_file($stamp_file['tmp_name'], $dest_path)) { if (!empty($stamp_path) && file_exists($stamp_path)) { @unlink($stamp_path); } $stamp_path = $dest_path;
                     } else { $upload_error_msg = "Error: Failed to move uploaded Stamp file."; $upload_error = true; }
                 }
             } elseif (isset($_FILES['company_stamp']) && $_FILES['company_stamp']['error'] != UPLOAD_ERR_NO_FILE && !$remove_stamp) { $upload_error_msg = "Error uploading Stamp file: " . $_FILES['company_stamp']['error']; $upload_error = true; }
         }
    }

    // Final Validation and Save
    if (empty($company_name) || empty($company_address)) {
        $error = "Company name and address are required fields.";
    } elseif ($company_email_raw && $company_email === null) {
         $error = "Invalid email format provided.";
    } elseif ($upload_error) {
        $error = $upload_error_msg ?: "An unspecified file upload error occurred.";
    } else {
        if (!empty($company) && isset($company['id'])) { // Update existing
            $sql = "UPDATE companies SET name = :name, address = :address, phone = :phone, email = :email, website = :website, gstin = :gstin, upi_qr_code_path = :upi_qr_code_path, default_notes = :default_notes, stamp_path = :stamp_path WHERE id = :id AND user_id = :user_id";
            $params = ['name' => $company_name, 'address' => $company_address, 'phone' => $company_phone, 'email' => $company_email, 'website' => $company_website, 'gstin' => $company_gstin, 'upi_qr_code_path' => $qr_code_path, 'default_notes' => $company_default_notes, 'stamp_path' => $stamp_path, 'id' => $company['id'], 'user_id' => $user_id ];
        } else { // Insert new
            $sql = "INSERT INTO companies (user_id, name, address, phone, email, website, gstin, upi_qr_code_path, default_notes, stamp_path) VALUES (:user_id, :name, :address, :phone, :email, :website, :gstin, :upi_qr_code_path, :default_notes, :stamp_path)";
            $params = [ 'user_id' => $user_id, 'name' => $company_name, 'address' => $company_address, 'phone' => $company_phone, 'email' => $company_email, 'website' => $company_website, 'gstin' => $company_gstin, 'upi_qr_code_path' => $qr_code_path, 'default_notes' => $company_default_notes, 'stamp_path' => $stamp_path ];
        }

        if (query($conn, $sql, $params)) {
             $_SESSION['message'] = "Company details saved successfully.";
             header("Location: index.php");
             exit;
        } else {
            $error = "Failed to save company details. Database error occurred.";
            error_log("Company save failed for user $user_id: " . mysqli_error($conn));
        }
    }
    if ($error) { $_SESSION['error_message'] = $error; header("Location: index.php"); exit; }
}

// --- Load user's invoices with PAGINATION and STATUS ---
$invoices = [];
$invoices_per_page = 15;
$current_invoice_page = isset($_GET['invoice_page']) ? max(1, (int)$_GET['invoice_page']) : 1;
$total_invoices = 0;
$total_invoice_pages = 1;
try {
    $sql_count_invoices = "SELECT COUNT(*) as total FROM invoices WHERE user_id = :user_id";
    $result_count = query($conn, $sql_count_invoices, ['user_id' => $user_id]);
    $total_invoices = (int)(fetch_one($result_count)['total'] ?? 0);

    if ($total_invoices > 0) {
        $total_invoice_pages = ceil($total_invoices / $invoices_per_page);
        if ($current_invoice_page < 1) { $current_invoice_page = 1; }
        if ($current_invoice_page > $total_invoice_pages) { $current_invoice_page = $total_invoice_pages; }
        $offset = ($current_invoice_page - 1) * $invoices_per_page;

        $sql_invoices = "SELECT i.id, i.invoice_number, i.invoice_date, i.total_amount, i.advance_paid, i.status, c.name as client_name FROM invoices i LEFT JOIN clients c ON i.client_id = c.id WHERE i.user_id = :user_id ORDER BY i.invoice_date DESC, i.id DESC LIMIT :limit OFFSET :offset";
        $result_invoices = query($conn, $sql_invoices, ['user_id' => $user_id, 'limit' => $invoices_per_page, 'offset' => $offset]);
        $invoices = $result_invoices ? fetch_all($result_invoices) : [];
    }
} catch (Exception $e) {
    error_log("Invoice loading failed for user $user_id: " . $e->getMessage());
    $error = "Could not load invoice data.";
}

// Generate Next Invoice Number for display (mirrors API logic)
function generateInvoiceNumberForDisplay($conn, $user_id) {
    $current_month = (int)date('n'); $current_year = (int)date('Y');
    if ($current_month >= 4) { $start_yy = date('y'); $end_yy = substr((string)($current_year + 1), -2);
    } else { $start_yy = substr((string)($current_year - 1), -2); $end_yy = date('y'); }
    $fy_prefix = $start_yy . "-" . $end_yy . "-";

    $sql = "SELECT invoice_number FROM invoices WHERE user_id = :user_id AND invoice_number LIKE :prefix ORDER BY invoice_number DESC LIMIT 1";
    $params = ['user_id' => $user_id, 'prefix' => $fy_prefix . '%'];
    $result = query($conn, $sql, $params);
    $nextNumber = 1;
    if ($result && fetch_count($conn, $result) > 0) {
        $lastInvoice = fetch_one($result);
        if (preg_match('/-(\d{4})$/', $lastInvoice['invoice_number'], $matches)) {
            $nextNumber = (int)$matches[1] + 1;
        } else {
            error_log("index.php display: Unexpected invoice format for FY '$fy_prefix', user $user_id. Last#: " . ($lastInvoice['invoice_number'] ?? 'N/A'));
            $sql_count = "SELECT COUNT(*) as count FROM invoices WHERE user_id = :user_id AND invoice_number LIKE :prefix";
            $res_count = query($conn, $sql_count, $params);
             if($res_count) $nextNumber = (int)fetch_one($res_count)['count'] + 1;
        }
    }
    return $fy_prefix . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);
}
$next_invoice_num_display = generateInvoiceNumberForDisplay($conn, $user_id);
function h($text) { return htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - GST Invoice Generator</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <style>
        :root {
            --primary: #1e40af; --primary-light: #3b82f6; --primary-dark: #1e3a8a;
            --secondary: #64748b; --accent: #f59e0b; --danger: #ef4444; --success: #10b981;
            --warning: #f59e0b; --info: #3b82f6; --light: #f8fafc; --dark: #1e293b;
            --body-bg: #f1f5f9; --card-bg: #ffffff; --border-color: #e2e8f0;
            --text-primary: #334155; --text-secondary: #64748b; --text-muted: #94a3b8;
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            --radius-sm: 0.125rem; --radius: 0.25rem; --radius-md: 0.375rem; --radius-lg: 0.5rem; --radius-xl: 0.75rem;
            --status-paid-bg: #d1fae5; --status-paid-text: #065f46;
            --status-unpaid-bg: #fee2e2; --status-unpaid-text: #991b1b;
            --status-partial-bg: #fef3c7; --status-partial-text: #92400e;
            --status-default-bg: #e5e7eb; --status-default-text: #4b5563;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Poppins', sans-serif; background-color: var(--body-bg); color: var(--text-primary); line-height: 1.6; font-size: 14px; }
        .container { max-width: 1280px; margin: 0 auto; padding: 2rem; }
        .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; padding-bottom: 1rem; border-bottom: 1px solid var(--border-color); }
        .page-title h1 { font-size: 1.75rem; font-weight: 700; color: var(--primary); margin-bottom: 0.25rem; }
        .page-title p { color: var(--text-secondary); font-size: 0.875rem; }
        .user-menu { display: flex; align-items: center; gap: 1rem; }
        .user-name { font-weight: 500; }
        .content-wrapper { display: flex; flex-wrap: wrap; gap: 1.5rem; }
        .sidebar { flex: 0 0 300px; }
        .main-content { flex: 1; min-width: 0; }
        .card { background: var(--card-bg); border-radius: var(--radius-lg); box-shadow: var(--shadow-md); overflow: hidden; margin-bottom: 1.5rem; }
        .card-body { padding: 1.5rem; }
        .tabs { display: flex; border-bottom: 1px solid var(--border-color); padding: 0 1.5rem; overflow-x: auto; }
        .tab { padding: 0.75rem 1.25rem; cursor: pointer; font-weight: 500; color: var(--text-secondary); border-bottom: 2px solid transparent; transition: all 0.2s ease; margin-bottom: -1px; white-space: nowrap; }
        .tab:hover { color: var(--primary); }
        .tab.active { color: var(--primary); border-bottom-color: var(--primary); }
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        .form-group { margin-bottom: 1rem; }
        .form-row { display: flex; flex-wrap: wrap; gap: 0.75rem; margin-bottom: 0.75rem; }
        .form-col { flex: 1; min-width: 180px; }
        label { display: block; font-weight: 500; margin-bottom: 0.5rem; color: var(--text-primary); font-size: 0.875rem; }
        label[for^="remove_"] { display: inline; margin-bottom: 0; font-weight: 400; color: var(--text-secondary); font-size: 0.8rem; margin-left: 0.2rem; vertical-align: middle; }
        input, select, textarea { width: 100%; padding: 0.625rem 0.75rem; border: 1px solid var(--border-color); border-radius: var(--radius); font-family: inherit; font-size: 0.875rem; color: var(--text-primary); background-color: white; transition: border-color 0.2s ease, box-shadow 0.2s ease; }
        input:focus, select:focus, textarea:focus { outline: none; border-color: var(--primary-light); box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.25); }
        input[readonly], input:disabled { background-color: var(--light); cursor: not-allowed; opacity: 0.7;}
        input[type="number"] { text-align: right;}
        input[type="checkbox"] { width: auto; margin-right: 0.3rem; vertical-align: middle; }
        textarea { resize: vertical; min-height: 60px; }
        .file-input-info { margin-top: 0.5rem; display: flex; align-items: center; }
        .file-input-info img { max-height: 40px; max-width: 100px; border: 1px solid #eee; vertical-align: middle; object-fit: contain; margin-right: 10px; }
        .box { border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 1.25rem; margin-bottom: 1.5rem; }
        .box-title { font-size: 1rem; font-weight: 600; color: var(--primary); margin-bottom: 1rem; padding-bottom: 0.5rem; border-bottom: 1px solid var(--border-color); }
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 1rem; }
        table th, table td { padding: 0.75rem; border-bottom: 1px solid var(--border-color); vertical-align: middle; font-size: 0.875rem; line-height: 1.4; }
        table th { text-align: left; font-weight: 600; background-color: var(--light); border-bottom-width: 2px; color: var(--text-primary); white-space: nowrap; }
        table tr:last-child td { border-bottom: none; }
        table input, table select { border-radius: var(--radius-sm); padding: 0.5rem; font-size: 0.875rem; }
        #items-table input[name="amount[]"] { background-color: var(--light); text-align: right; }
        #items-table input[name="convenience_fee"], #items-table input[name="advance_paid"] { text-align: right;}
        .totals-table td { padding: 0.4rem 0; }
        .totals-table label { margin-bottom: 0; font-weight: 400; }
        .totals-table input[type=number] { padding: 0.3rem 0.5rem; font-size: 0.875rem; max-width: 80px; display: inline-block; vertical-align: middle; margin-left: 5px; border-radius: var(--radius-sm); text-align: right; }
        .totals-table .amount-display { font-weight: 500; display:inline-block; min-width: 60px; text-align: right;}
        .totals-table .grand-total td { font-weight: 700; font-size: 1.1em; border-top: 1px solid var(--border-color); padding-top: 0.6rem; padding-bottom: 0; }
        .empty-table td { text-align: center; padding: 2rem; color: var(--text-secondary); }
        .status-badge { display: inline-block; padding: 0.3em 0.7em; font-size: 0.7rem; font-weight: 600; line-height: 1; text-align: center; white-space: nowrap; vertical-align: middle; border-radius: var(--radius-md); text-transform: uppercase; letter-spacing: 0.5px; }
        .status-paid { background-color: var(--status-paid-bg); color: var(--status-paid-text); border: 1px solid #6ee7b7; }
        .status-unpaid { background-color: var(--status-unpaid-bg); color: var(--status-unpaid-text); border: 1px solid #fca5a5; }
        .status-partially_paid { background-color: var(--status-partial-bg); color: var(--status-partial-text); border: 1px solid #fcd34d; }
        .status-default { background-color: var(--status-default-bg); color: var(--status-default-text); border: 1px solid #d1d5db; }
        .btn { display: inline-flex; align-items: center; justify-content: center; padding: 0.5rem 1rem; border-radius: var(--radius); font-weight: 500; cursor: pointer; transition: all 0.2s ease; border: 1px solid transparent; font-size: 0.875rem; text-decoration: none; white-space: nowrap; }
        .btn:disabled { background-color: var(--secondary) !important; opacity: 0.7; cursor: not-allowed; color: white !important; }
        .btn-primary { background-color: var(--primary); color: white; } .btn-primary:hover:not(:disabled) { background-color: var(--primary-dark); }
        .btn-success { background-color: var(--success); color: white; } .btn-success:hover:not(:disabled) { background-color: #0d9488; }
        .btn-danger { background-color: var(--danger); color: white; } .btn-danger:hover:not(:disabled) { background-color: #dc2626; }
        .btn-secondary { background-color: var(--secondary); color: white; } .btn-secondary:hover:not(:disabled) { background-color: #475569; }
        .btn-outline { background-color: transparent; border-color: var(--border-color); color: var(--text-primary); } .btn-outline:hover:not(:disabled) { border-color: var(--primary); color: var(--primary); background-color: rgba(30, 64, 175, 0.05); }
        .btn-sm { padding: 0.25rem 0.625rem; font-size: 0.75rem; }
        .btn-icon { display: inline-block; margin-right: 0.5rem; width: 1em; height: 1em; line-height: 1;}
        .btn-icon-only { padding: 0.375rem; font-size: 1rem; } .btn-icon-only .btn-icon { margin-right: 0; }
        .btn-block { display: flex; width: 100%; }
        .btn-group { display: inline-flex; gap: 0.25rem; }
        .action-buttons { display: flex; justify-content: flex-end; gap: 0.75rem; margin-top: 1.5rem; }
        .sidebar-box { background: var(--card-bg); border-radius: var(--radius-lg); box-shadow: var(--shadow-md); overflow: hidden; margin-bottom: 1.5rem; }
        .sidebar-header { background: var(--primary); color: white; padding: 1rem; font-weight: 600; font-size: 1.125rem; }
        .sidebar-body { padding: 1.25rem; }
        .sidebar-body .img-preview { max-height: 40px; max-width: 100px; vertical-align: middle; border: 1px solid #eee; margin-left: 5px; object-fit: contain; border-radius: var(--radius-sm); }
        .alert { padding: 0.75rem 1rem; border-radius: var(--radius); margin-bottom: 1.5rem; display: flex; align-items: center; font-size: 0.875rem; border-left-width: 4px; border-left-style: solid;} .alert-icon { margin-right: 0.75rem; font-size: 1.25rem; line-height: 1;}
        .alert-success { background-color: #f0fdf4; color: #15803d; border-color: var(--success); } .alert-danger { background-color: #fef2f2; color: #b91c1c; border-color: var(--danger); }
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0, 0, 0, 0.6); backdrop-filter: blur(3px); }
        .modal-content { background-color: #fff; margin: 5% auto; padding: 0; border: 1px solid #ccc; width: 90%; max-width: 700px; border-radius: var(--radius-lg); box-shadow: var(--shadow-lg); animation: fadeInModal 0.3s ease-out; overflow: hidden; }
        .modal-header { padding: 1rem 1.5rem; background-color: var(--primary); color: white; display: flex; justify-content: space-between; align-items: center; }
        .modal-title { font-weight: 600; font-size: 1.25rem; line-height: 1.2; }
        .modal-close { background: transparent; border: none; color: white; font-size: 1.8rem; font-weight: bold; cursor: pointer; line-height: 1; padding: 0.2rem; opacity: 0.8; } .modal-close:hover { opacity: 1; }
        .modal-body { padding: 1.5rem; max-height: 70vh; overflow-y: auto;}
        .modal-body hr { margin: 1.5rem 0; border: none; border-top: 1px solid var(--border-color); }
        .modal-footer { padding: 1rem 1.5rem; background-color: var(--light); border-top: 1px solid var(--border-color); display: flex; justify-content: flex-end; gap: 0.75rem; }
        #invoice-preview-modal .modal-content { max-width: 900px; }
        @keyframes fadeInModal { from { opacity: 0; transform: translateY(-20px); } to { opacity: 1; transform: translateY(0); } }
        #toast-container { position: fixed; top: 1rem; right: 1rem; z-index: 9999; width: 320px; }
        .toast { background-color: white; border-radius: var(--radius); box-shadow: var(--shadow-lg); margin-bottom: 0.75rem; overflow: hidden; border-left: 4px solid var(--dark); animation: slideInRight 0.3s ease-out, fadeOut 0.5s ease-out 4.5s forwards; }
        .toast-header { padding: 0.5rem 1rem; display: flex; justify-content: space-between; align-items: center; } .toast-title { font-weight: 600; font-size: 0.875rem; } .toast-close { background: transparent; border: none; font-size: 1.25rem; line-height: 1; cursor: pointer; opacity: 0.7;} .toast-close:hover { opacity: 1; } .toast-body { padding: 0.75rem 1rem; font-size: 0.875rem;}
        .toast-success { border-left-color: var(--success); } .toast-error { border-left-color: var(--danger); } .toast-warning { border-left-color: var(--warning); }
        @keyframes slideInRight { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        @keyframes fadeOut { from { opacity: 1; } to { opacity: 0; } }
        .pagination { display: flex; justify-content: center; align-items: center; gap: 0.5rem; margin-top: 1.5rem; font-size: 0.875rem;}
        .pagination a, .pagination span { padding: 0.4rem 0.8rem; border: 1px solid var(--border-color); border-radius: var(--radius); color: var(--primary); text-decoration: none; background-color: white; }
        .pagination a:hover { background-color: var(--primary-light); color: white; border-color: var(--primary-light); }
        .pagination span.current { background-color: var(--primary); color: white; border-color: var(--primary); font-weight: 600; }
        .pagination span.disabled { color: var(--text-muted); background-color: var(--light); border-color: var(--border-color); cursor: not-allowed; }
        .mt-2 { margin-top: 0.5rem; } .mb-4 { margin-bottom: 1rem; } .ml-4 { margin-left: 1rem;}
        .p-3 { padding: 0.75rem; } .text-right { text-align: right; } .text-center { text-align: center; }
        .font-semibold { font-weight: 600; } .text-sm { font-size: 0.875rem; } .text-xs { font-size: 0.75rem; } .text-lg { font-size: 1.125rem; }
        .text-muted { color: var(--text-muted); } .text-danger { color: var(--danger); } .text-primary-dark { color: var(--primary-dark); }
        .flex { display: flex; } .items-center { align-items: center; } .justify-between { justify-content: space-between; } .justify-end { justify-content: flex-end; } .flex-column { flex-direction: column; } .gap-2 { gap: 0.5rem; } .w-full { width: 100%; }
        .sr-only { position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip: rect(0, 0, 0, 0); white-space: nowrap; border-width: 0; }
        @media (max-width: 1024px) { .content-wrapper { flex-direction: column; } .sidebar { flex: none; width: 100%; order: 2; } .main-content { order: 1; } }
        @media (max-width: 768px) { .container { padding: 1rem; } .page-header { flex-direction: column; align-items: flex-start;} .user-menu { width: 100%; justify-content: flex-end; } .form-col { flex-basis: 100%; } .action-buttons { flex-direction: column; } .action-buttons .btn { width: 100%; } .modal-content { width: 95%; margin: 5% auto; } #toast-container { width: 90%; right: 5%; left: 5%; } .pagination { font-size: 0.8rem; } }
        label.sr-only + input#client_search, label.sr-only + input#client_search_tab { position: static !important; width: 100% !important; height: auto !important; padding: 0.625rem 0.75rem !important; margin: 0 0 1rem 0 !important; overflow: visible !important; clip: auto !important; white-space: normal !important; border-width: 1px !important; }
    </style>
</head>
<body>
    <div class="container">
        <div class="page-header">
            <div class="page-title">
                <h1>GST Invoice Generator</h1>
                <p>Create and manage your invoices efficiently</p>
            </div>
            <div class="user-menu">
                <span class="user-name">Welcome, <?php echo h($username); ?></span>
                <a href="logout.php" class="btn btn-outline btn-sm">Sign Out</a>
            </div>
        </div>

        <div class="content-wrapper">
            <!-- Sidebar -->
            <div class="sidebar">
                <div class="sidebar-box">
                    <div class="sidebar-header">Company Information</div>
                    <div class="sidebar-body">
                         <?php if (!empty($company) && isset($company['id'])): ?>
                            <div class="mb-2">
                                <div class="font-semibold mb-1"><?php echo h($company['name']); ?></div>
                                <div class="text-sm mb-1"><?php echo nl2br(h($company['address'])); ?></div>
                                <?php if (!empty($company['phone'])): ?><div class="text-xs text-muted">Phone: <?php echo h($company['phone']); ?></div><?php endif; ?>
                                <?php if (!empty($company['email'])): ?><div class="text-xs text-muted">Email: <?php echo h($company['email']); ?></div><?php endif; ?>
                                <?php if (!empty($company['gstin'])): ?><div class="text-xs text-muted">GSTIN: <?php echo h($company['gstin']); ?></div><?php endif; ?>
                                <?php if (!empty($company['upi_qr_code_path']) && file_exists($company['upi_qr_code_path'])): ?>
                                     <div class="text-xs text-muted mt-2">QR: <img src="<?php echo h($company['upi_qr_code_path']).'?t='.time(); ?>" alt="UPI QR" class="img-preview"></div>
                                <?php endif; ?>
                                 <?php if (!empty($company['stamp_path']) && file_exists($company['stamp_path'])): ?>
                                     <div class="text-xs text-muted mt-2">Stamp: <img src="<?php echo h($company['stamp_path']).'?t='.time(); ?>" alt="Company Stamp" class="img-preview"></div>
                                <?php endif; ?>
                                <a href="bank.php" class="btn btn-outline btn-sm mt-2" style="display: inline-block;">Manage Banks</a>
                            </div>
                            <button type="button" class="btn btn-outline btn-sm mt-2 company-edit-btn" onclick="editCompany()">Edit Details</button>
                        <?php else: ?>
                            <p class="text-muted text-sm">Company details not set up.</p>
                            <button type="button" class="btn btn-primary btn-sm mt-2 company-edit-btn" onclick="editCompany()">Add Company Details</button>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="sidebar-box">
                    <div class="sidebar-header">Quick Actions</div>
                    <div class="sidebar-body">
                        <div class="flex flex-column gap-2">
                            <button type="button" class="btn btn-primary w-full" onclick="showTab('create-invoice')"><i class="fas fa-plus btn-icon"></i> Create New Invoice</button>
                            <a href="estimates.php" class="btn btn-outline w-full"><i class="fas fa-file-alt btn-icon"></i> Manage Estimates</a>
                            <button type="button" class="btn btn-outline w-full" onclick="showTab('clients')"><i class="fas fa-users btn-icon"></i> Manage Clients</button>
                            <hr style="border-top: 1px solid var(--border-color); margin: 0.5rem 0;">
                            <a href="reports.php" class="btn btn-outline w-full"><i class="fas fa-chart-pie btn-icon"></i> Reports Dashboard</a>
                            <a href="list.php" class="btn btn-outline w-full"><i class="fas fa-list btn-icon"></i> Invoice List Report</a>
                            <a href="financial_liability_report.php" class="btn btn-outline w-full"><i class="fas fa-file-invoice-dollar btn-icon"></i> Financial Liability</a>
                            <a href="bank_report.php" class="btn btn-outline w-full"><i class="fas fa-landmark btn-icon"></i> Bank Report</a>
                            <a href="client_reports.php" class="btn btn-outline w-full"><i class="fas fa-address-book btn-icon"></i> Client Status Report</a>
                            <hr style="border: none; border-top: 1px solid var(--border-color); margin: 0.5rem 0;">
                            <a href="bank.php" class="btn btn-outline w-full"><i class="fas fa-university btn-icon"></i> Manage Banks</a>
                            <button type="button" class="btn btn-outline w-full company-edit-btn" onclick="editCompany()"><i class="fas fa-cog btn-icon"></i> Company Settings</button>
                        </div>
                    </div>
                </div>
            </div> <!-- End Sidebar -->

            <!-- Main Content -->
            <div class="main-content">
                <?php if (!empty($message)): ?> <div class="alert alert-success" id="php-flash-message-success"><div class="alert-icon">✓</div><div><?php echo h($message); ?></div></div> <?php endif; ?>
                <?php if (!empty($error)): ?> <div class="alert alert-danger" id="php-flash-message-error"><div class="alert-icon">✗</div><div><?php echo h($error); ?></div></div> <?php endif; ?>

                <div class="card">
                    <div class="tabs">
                        <div class="tab" data-tab="invoices">Invoices</div>
                        <div class="tab" data-tab="clients">Clients</div>
                        <div class="tab" data-tab="create-invoice">Create Invoice</div>
                    </div>

                    <!-- Invoices Tab -->
                    <div class="tab-content" id="invoices-tab">
                        <div class="card-body">
                            <div class="flex justify-between items-center mb-4 flex-wrap gap-2">
                                <h2 class="text-lg font-semibold">Your Invoices (<?php echo $total_invoices; ?>)</h2>
                                <button type="button" class="btn btn-primary btn-sm" onclick="showTab('create-invoice')"><i class="fas fa-plus btn-icon"></i> New Invoice</button>
                            </div>

                            <div class="table-responsive">
                                <table>
                                    <thead>
                                        <tr>
                                            <th>Invoice #</th> <th>Date</th> <th>Client</th>
                                            <th class="text-right">Total Amt (₹)</th>
                                            <th class="text-center">Status</th>
                                            <th class="text-center">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (count($invoices) > 0): ?>
                                            <?php foreach ($invoices as $invoice):
                                                $status_val = strtolower(trim($invoice['status'] ?? 'unknown'));
                                                $status_class = 'status-default'; $status_text = 'Unknown';
                                                if ($status_val === 'paid') { $status_class = 'status-paid'; $status_text = 'Paid'; }
                                                elseif ($status_val === 'unpaid') { $status_class = 'status-unpaid'; $status_text = 'Unpaid'; }
                                                elseif ($status_val === 'partially_paid') { $status_class = 'status-partially_paid'; $status_text = 'Partial'; }
                                            ?>
                                                <tr>
                                                    <td class="font-semibold"><?php echo h($invoice['invoice_number']); ?></td>
                                                    <td><?php echo date('d-m-Y', strtotime($invoice['invoice_date'])); ?></td>
                                                    <td><?php echo h($invoice['client_name'] ?? 'N/A'); ?></td>
                                                    <td class="text-right"><?php echo number_format((float)($invoice['total_amount'] ?? 0), 2); ?></td>
                                                    <td class="text-center"><span class="status-badge <?php echo $status_class; ?>"><?php echo $status_text; ?></span></td>
                                                    <td class="text-center">
                                                        <div class="btn-group">
                                                            <button type="button" class="btn btn-outline btn-sm" title="View & Download PDF" onclick="viewInvoice(<?php echo $invoice['id']; ?>)"><i class="fas fa-eye"></i></button>
                                                            <button type="button" class="btn btn-outline btn-sm" title="Edit Invoice" onclick="editInvoice(<?php echo $invoice['id']; ?>)"><i class="fas fa-edit"></i></button>
                                                            <button type="button" class="btn btn-outline btn-sm" title="Download Original Copy" onclick="downloadInvoiceCopy(<?php echo $invoice['id']; ?>, 'ORIGINAL')"><i class="fas fa-print"></i></button>
                                                            <button type="button" class="btn btn-outline btn-sm" title="Download Duplicate Copy" onclick="downloadInvoiceCopy(<?php echo $invoice['id']; ?>, 'DUPLICATE')"><i class="fas fa-copy"></i></button>
                                                            <button type="button" class="btn btn-danger btn-sm" title="Delete Invoice" onclick="deleteInvoice(<?php echo $invoice['id']; ?>, this)"><i class="fas fa-trash"></i></button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr><td colspan="6" class="empty-table"><?php echo ($total_invoices == 0) ? 'No invoices created yet.' : 'No invoices found on this page.'; ?></td></tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>

                            <?php if ($total_invoice_pages > 1): ?>
                                <div class="pagination">
                                    <?php if ($current_invoice_page > 1): ?> <a href="?invoice_page=<?php echo $current_invoice_page - 1; ?>#invoices">« Prev</a> <?php else: ?> <span class="disabled">« Prev</span> <?php endif; ?>
                                    <?php for ($i = 1; $i <= $total_invoice_pages; $i++): if ($i == 1 || $i == $total_invoice_pages || ($i >= $current_invoice_page - 2 && $i <= $current_invoice_page + 2)): ?>
                                        <?php if ($i == $current_invoice_page): ?> <span class="current"><?php echo $i; ?></span>
                                        <?php else: ?> <a href="?invoice_page=<?php echo $i; ?>#invoices"><?php echo $i; ?></a> <?php endif; ?>
                                    <?php elseif (($i == $current_invoice_page - 3) || ($i == $current_invoice_page + 3)): ?> <span class="disabled">...</span> <?php endif; endfor; ?>
                                    <?php if ($current_invoice_page < $total_invoice_pages): ?> <a href="?invoice_page=<?php echo $current_invoice_page + 1; ?>#invoices">Next »</a> <?php else: ?> <span class="disabled">Next »</span> <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Clients Tab -->
                    <div class="tab-content" id="clients-tab">
                         <div class="card-body">
                             <div class="flex justify-between items-center mb-4 flex-wrap gap-2"> <h2 class="text-lg font-semibold">Your Clients</h2> <button type="button" class="btn btn-primary btn-sm" onclick="openClientModal()"> <i class="fas fa-user-plus btn-icon"></i> Add Client </button> </div>
                             <div class="form-group mb-4"> <label for="client_search_tab" class="sr-only">Search Clients</label> <input type="text" id="client_search_tab" placeholder="Search Clients (Name, GSTIN, Email, Phone, Address)..."> </div>
                            <div class="table-responsive">
                                <table id="clients-table">
                                     <thead> <tr> <th>Name</th> <th>GSTIN</th> <th>State</th> <th>Contact</th> <th class="text-center">Actions</th> </tr> </thead>
                                    <tbody id="clients-table-body"></tbody>
                                </table>
                             </div>
                            <div id="client-pagination" class="pagination" style="display: none;"></div>
                        </div>
                    </div>

                    <!-- Create Invoice Tab -->
                    <div class="tab-content" id="create-invoice-tab">
                        <div class="card-body">
                            <h2 class="text-lg font-semibold mb-4">Create New Invoice</h2>
                            <form id="invoice-form" onsubmit="return false;">
                                <input type="hidden" name="invoice_id" value="">
                                <div class="box">
                                    <h3 class="box-title">Invoice Details</h3>
                                    <div class="form-row">
                                        <div class="form-col"><label for="invoice_number">Invoice Number</label><input type="text" id="invoice_number" name="invoice_number" value="<?php echo h($next_invoice_num_display); ?>" readonly><small class="text-muted text-xs">Auto-generated.</small></div>
                                        <div class="form-col"><label for="invoice_date">Invoice Date <span class="text-danger">*</span></label><input type="date" id="invoice_date" name="invoice_date" value="<?php echo date('Y-m-d'); ?>" required></div>
                                        <div class="form-col"><label for="due_date">Due Date</label><input type="date" id="due_date" name="due_date" value="<?php echo date('Y-m-d'); ?>"></div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-col"><label for="hsn_code">HSN/SAC Code</label><input type="text" id="hsn_code" name="hsn_code" placeholder="e.g., 9983"></div>
                                        <div class="form-col"><label for="po_number">PO/Order Ref</label><input type="text" id="po_number" name="po_number"></div>
                                    </div>
                                </div>
                                <div class="box">
                                    <h3 class="box-title">Client & Bank Information</h3>
                                    <div class="form-row">
                                        <div class="form-col"><label for="client_search" class="sr-only">Search Client</label><input type="text" id="client_search" placeholder="Search Client..." class="mb-2"><label for="client_id">Select Client <span class="text-danger">*</span></label><select id="client_id" name="client_id" required><option value="">-- Select Client --</option></select><div id="client-loading" style="display: none;" class="text-muted text-xs mt-1">Loading...</div></div>
                                        <div class="form-col" style="flex: 0 0 auto; align-self: flex-end;"><button type="button" class="btn btn-outline btn-sm" onclick="openClientModal()" title="Add New Client"><i class="fas fa-user-plus"></i> New</button></div>
                                    </div>
                                    <div id="client-details" style="display: none;" class="mt-2 mb-4"><div class="p-3" style="background-color: var(--light); border-radius: var(--radius);"><div class="flex justify-between flex-wrap gap-2"><div><div class="font-semibold text-primary-dark" id="show-client-name"></div> <div class="text-xs mt-1 text-muted" id="show-client-address"></div></div><div class="text-right text-xs text-muted"><div>GSTIN: <span id="show-client-gstin">-</span></div> <div>State: <span id="show-client-state">-</span></div></div></div></div></div>
                                    <div class="form-group"><label for="bank_account_id">Bank Account (Optional)</label><select id="bank_account_id" name="bank_account_id"><option value="">-- No Bank Details --</option></select><div id="bank-loading" style="display: none;" class="text-muted text-xs mt-1">Loading...</div></div>
                                </div>
                                <div class="box">
                                    <h3 class="box-title">Invoice Items <span class="text-danger">*</span></h3>
                                    <div class="table-responsive"><table id="items-table"><thead><tr><th width="45%">Description</th><th width="15%">Quantity</th><th width="15%">Rate (₹)</th><th width="15%">Amount (₹)</th><th width="10%" class="text-center">Action</th></tr></thead><tbody id="invoice-items"></tbody></table></div>
                                    <button type="button" class="btn btn-outline btn-sm mt-2" onclick="addItem()"><i class="fas fa-plus btn-icon"></i> Add Item</button>
                                    <div class="flex justify-end mt-4"><div style="width: 100%; max-width: 350px;">
                                        <table class="w-full text-sm totals-table">
                                            <tr><td>Subtotal:</td><td class="text-right">₹ <span id="subtotal" class="amount-display">0.00</span></td></tr>
                                            <tr><td><label for="discount_rate">Discount (%):</label> <input type="number" id="discount_rate" name="discount_rate" value="0.00" min="0" max="100" step="0.01"></td><td class="text-right" style="color:#e67e22;">- ₹ <span id="discount-amount" class="amount-display">0.00</span></td></tr>
                                            <tr><td><label for="cgst_rate">CGST (%):</label> <input type="number" id="cgst_rate" name="cgst_rate" value="9.00" min="0" step="0.01"></td><td class="text-right">₹ <span id="cgst-amount" class="amount-display">0.00</span></td></tr>
                                            <tr><td><label for="sgst_rate">SGST (%):</label> <input type="number" id="sgst_rate" name="sgst_rate" value="9.00" min="0" step="0.01"></td><td class="text-right">₹ <span id="sgst-amount" class="amount-display">0.00</span></td></tr>
                                            <tr><td><label for="convenience_fee">Conv. Fee:</label></td><td class="text-right"><span class="text-xs mr-1">₹</span><input type="number" id="convenience_fee" name="convenience_fee" value="0.00" min="0" step="0.01"></td></tr>
                                            <tr style="border-top: 1px solid var(--border-color);"><td class="font-semibold pt-1">Total:</td><td class="text-right font-semibold pt-1">₹ <span id="total-amount" class="amount-display">0.00</span></td></tr>
                                            <tr><td><label for="advance_paid">Advance Paid:</label></td><td class="text-right"><span class="text-xs mr-1">₹</span><input type="number" id="advance_paid" name="advance_paid" value="0.00" min="0" step="0.01"></td></tr>
                                            <tr class="grand-total"><td>Amount Due:</td><td class="text-right">₹ <span id="amount-due" class="amount-display">0.00</span></td></tr>
                                        </table>
                                    </div></div>
                                </div>
                                <div class="box">
                                    <h3 class="box-title">Notes / Terms</h3>
                                    <div class="form-group mb-0"><label for="notes" class="sr-only">Notes</label><textarea id="notes" name="notes" rows="3"><?php echo h($company['default_notes'] ?? ''); ?></textarea><small class="text-muted text-xs">Uses Company Default if blank.</small></div>
                                </div>
                                <div class="action-buttons"><button type="button" class="btn btn-secondary" onclick="previewInvoice()"><i class="fas fa-search btn-icon"></i>Preview</button><button type="button" class="btn btn-success" id="save-invoice-btn" onclick="saveInvoice(this)"><i class="fas fa-save btn-icon"></i>Save Invoice</button></div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="client-modal" class="modal"> <div class="modal-content"> <form id="client-form" onsubmit="return false;"> <div class="modal-header"> <h2 class="modal-title" id="client-modal-title">Add Client</h2> <button type="button" class="modal-close" onclick="closeClientModal()">×</button> </div> <div class="modal-body"> <input type="hidden" id="client_form_id" name="id" value=""> <div class="form-row"> <div class="form-col"> <label for="client_name">Client Name <span class="text-danger">*</span></label> <input type="text" id="client_name" name="name" required> </div> <div class="form-col"> <label for="client_gstin">GSTIN</label> <input type="text" id="client_gstin" name="gstin"> </div> </div> <div class="form-group"> <label for="client_address">Address</label> <textarea id="client_address" name="address" rows="2"></textarea> </div> <div class="form-row"> <div class="form-col"> <label for="client_state">State</label> <input type="text" id="client_state" name="state"> </div> <div class="form-col"> <label for="client_state_code">State Code</label> <input type="text" id="client_state_code" name="state_code" pattern="\d{1,2}"> </div> </div> <div class="form-row"> <div class="form-col"> <label for="client_phone">Phone</label> <input type="tel" id="client_phone" name="phone"> </div> <div class="form-col"> <label for="client_email">Email</label> <input type="email" id="client_email" name="email"> </div> </div> </div> <div class="modal-footer"> <button type="button" class="btn btn-outline" onclick="closeClientModal()">Cancel</button> <button type="button" class="btn btn-primary" id="save-client-btn" onclick="saveClient(this)">Save Client</button> </div> </form> </div> </div>
    <div id="company-modal" class="modal"> <div class="modal-content"> <form id="company-form" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" enctype="multipart/form-data"> <div class="modal-header"> <h2 class="modal-title">Company Info</h2> <button type="button" class="modal-close" onclick="closeCompanyModal()">×</button> </div> <div class="modal-body"> <input type="hidden" name="save_company" value="1"> <div class="form-row"> <div class="form-col"><label for="m_company_name">Name <span class="text-danger">*</span></label><input type="text" id="m_company_name" name="company_name" value="<?php echo h($company['name'] ?? ''); ?>" required></div> <div class="form-col"><label for="m_company_gstin">GSTIN</label><input type="text" id="m_company_gstin" name="company_gstin" value="<?php echo h($company['gstin'] ?? ''); ?>"></div> </div> <div class="form-group"><label for="m_company_address">Address <span class="text-danger">*</span></label><textarea id="m_company_address" name="company_address" rows="3" required><?php echo h($company['address'] ?? ''); ?></textarea></div> <div class="form-row"> <div class="form-col"><label for="m_company_phone">Phone</label><input type="tel" id="m_company_phone" name="company_phone" value="<?php echo h($company['phone'] ?? ''); ?>"></div> <div class="form-col"><label for="m_company_email">Email</label><input type="email" id="m_company_email" name="company_email" value="<?php echo h($company['email'] ?? ''); ?>"></div> </div> <div class="form-group"><label for="m_company_website">Website</label><input type="url" id="m_company_website" name="company_website" value="<?php echo h($company['website'] ?? ''); ?>"></div> <hr> <h3 class="font-semibold text-sm mb-2">Images & Notes</h3> <div class="form-group"> <label for="m_company_upi_qr_code">UPI QR Code</label> <input type="file" id="m_company_upi_qr_code" name="company_upi_qr_code" accept="image/*" class="text-sm"> <?php if (!empty($company['upi_qr_code_path']) && file_exists($company['upi_qr_code_path'])): ?> <div class="file-input-info"> <img src="<?php echo h($company['upi_qr_code_path']).'?t='.time(); ?>" alt="QR"><input type="checkbox" name="remove_qr_code" id="m_remove_qr_code" value="1"><label for="m_remove_qr_code">Remove</label> </div> <?php endif; ?></div> <div class="form-group"> <label for="m_company_stamp">Stamp</label> <input type="file" id="m_company_stamp" name="company_stamp" accept="image/*" class="text-sm"> <?php if (!empty($company['stamp_path']) && file_exists($company['stamp_path'])): ?> <div class="file-input-info"> <img src="<?php echo h($company['stamp_path']).'?t='.time(); ?>" alt="Stamp"><input type="checkbox" name="remove_stamp" id="m_remove_stamp" value="1"><label for="m_remove_stamp">Remove</label> </div> <?php endif; ?></div> <div class="form-group"> <label for="m_company_default_notes">Default Notes</label> <textarea id="m_company_default_notes" name="company_default_notes" rows="3"><?php echo h($company['default_notes'] ?? ''); ?></textarea> </div> </div> <div class="modal-footer"> <button type="button" class="btn btn-outline" onclick="closeCompanyModal()">Cancel</button> <button type="submit" class="btn btn-primary">Save Info</button> </div> </form> </div> </div>
    <div id="invoice-preview-modal" class="modal"> <div class="modal-content"> <div class="modal-header"> <h2 class="modal-title">Invoice Preview</h2> <button type="button" class="modal-close" onclick="closeInvoicePreviewModal()">×</button> </div> <div class="modal-body"><div id="invoice-preview-content"></div></div> <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="printInvoice()"><i class="fas fa-print btn-icon"></i>Print</button><button type="button" class="btn btn-success" onclick="downloadInvoicePDF()"><i class="fas fa-file-pdf btn-icon"></i>Download PDF</button><button type="button" class="btn btn-secondary" onclick="closeInvoicePreviewModal()">Close</button></div></div> </div>
    <div id="toast-container"></div>

    <script>
        // --- Elements Cache & Constants ---
        const tabs = document.querySelectorAll('.tab');
        const tabContents = document.querySelectorAll('.tab-content');
        const clientModal = document.getElementById('client-modal');
        const companyModal = document.getElementById('company-modal');
        const previewModal = document.getElementById('invoice-preview-modal');
        const toastContainer = document.getElementById('toast-container');
        const clientSearchInput = document.getElementById('client_search');
        const clientSearchTabInput = document.getElementById('client_search_tab');
        const clientSelect = document.getElementById('client_id');
        const bankSelect = document.getElementById('bank_account_id');
        const clientDetailsDiv = document.getElementById('client-details');
        const clientsTableBody = document.getElementById('clients-table-body');
        const clientPaginationDiv = document.getElementById('client-pagination');
        const invoiceItemsTbody = document.getElementById('invoice-items');
        const CLIENTS_PER_PAGE = 10;
        let clientSearchTimeout;

        // --- Utility Functions ---
        function roundTo(n, d=2) { const m=Math.pow(10,d); return Math.round(parseFloat((n*m).toFixed(11)))/m; }
        function escapeHtml(u) { return u.replace(/[&<>"']/g, m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'})[m]); }
        function showToast(title, message, type = 'info') { const t=document.createElement('div'); t.className=`toast toast-${type}`; t.innerHTML=`<div class="toast-header"><strong class="mr-auto">${escapeHtml(title)}</strong><button type="button" class="ml-2 mb-1 close" onclick="this.parentElement.parentElement.remove()">&times;</button></div><div class="toast-body">${escapeHtml(message)}</div>`; toastContainer.appendChild(t); }
        function openModal(el) { if(el) el.style.display='block'; }
        function closeModal(el) { if(el) el.style.display='none'; }
        
        // --- Modal Control ---
        function openClientModal(id=null){ const f=document.getElementById('client-form'); f.reset(); f.id.value=''; document.getElementById('client-modal-title').textContent='Add Client'; if(id){fetchClientForEdit(id);}else{openModal(clientModal);} }
        function fetchClientForEdit(id){fetch(`api.php?action=get_client&id=${id}`).then(r=>r.json()).then(d=>{if(d.success&&d.client){const c=d.client;const f=document.getElementById('client-form');f.id.value=c.id;f.name.value=c.name||'';f.address.value=c.address||'';f.gstin.value=c.gstin||'';f.state.value=c.state||'';f.state_code.value=c.state_code||'';f.phone.value=c.phone||'';f.email.value=c.email||'';document.getElementById('client-modal-title').textContent='Edit Client';openModal(clientModal);}}).catch(e=>showToast('Error','Failed to load client.','error'));}
        function closeClientModal(){closeModal(clientModal);}
        function editCompany(){openModal(companyModal);}
        function closeCompanyModal(){closeModal(companyModal);}
        function closeInvoicePreviewModal(){closeModal(previewModal);}
        window.addEventListener('click',e=>{if(e.target===clientModal)closeClientModal();if(e.target===companyModal)closeCompanyModal();if(e.target===previewModal)closeInvoicePreviewModal();});

        // --- Tab Management & Client Handling ---
        function showTab(tabName){tabs.forEach(t=>t.classList.remove('active'));tabContents.forEach(c=>c.classList.remove('active'));document.querySelector(`.tab[data-tab="${tabName}"]`).classList.add('active');document.getElementById(`${tabName}-tab`).classList.add('active');window.location.hash=tabName;if(tabName==='clients')loadClients(1);}
        tabs.forEach(t=>t.addEventListener('click',()=>showTab(t.dataset.tab)));
        function loadClientDropdown(search='', selId=null){const curVal=selId?String(selId):clientSelect.value; fetch(`api.php?action=get_clients&search=${encodeURIComponent(search)}&limit=100`).then(r=>r.json()).then(d=>{clientSelect.innerHTML='<option value="">-- Select Client --</option>';if(d.success&&d.clients.length>0){d.clients.forEach(c=>{const opt=new Option(`${escapeHtml(c.name)} ${c.gstin?`(${escapeHtml(c.gstin)})`:''}`,c.id);Object.keys(c).forEach(k=>opt.dataset[k]=c[k]||'');clientSelect.appendChild(opt);});if(curVal&&clientSelect.querySelector(`option[value="${curVal}"]`))clientSelect.value=curVal;} updateClientDetailsDisplay();});}
        function updateClientDetailsDisplay(){const opt=clientSelect.options[clientSelect.selectedIndex];if(clientSelect.value&&opt.dataset.name){Object.keys(opt.dataset).forEach(k=>{const el=document.getElementById(`show-client-${k}`);if(el)el.innerHTML=(k==='address'?(opt.dataset[k]||'').replace(/\n/g,'<br>'):opt.dataset[k]||'-');});clientDetailsDiv.style.display='block';}else{clientDetailsDiv.style.display='none';}}
        clientSelect?.addEventListener('change', updateClientDetailsDisplay);
        clientSearchInput?.addEventListener('input',function(){clearTimeout(clientSearchTimeout);clientSearchTimeout=setTimeout(()=>loadClientDropdown(this.value.trim()),350);});
        function loadClients(page=1,search=''){clientsTableBody.innerHTML=`<tr><td colspan="5" class="empty-table">Loading...</td></tr>`; fetch(`api.php?action=get_clients&search=${encodeURIComponent(search)}&page=${page}&limit=${CLIENTS_PER_PAGE}`).then(r=>r.json()).then(d=>{clientsTableBody.innerHTML='';if(d.success&&d.clients.length>0){d.clients.forEach(c=>{const row=clientsTableBody.insertRow();row.innerHTML=`<td class="font-semibold">${escapeHtml(c.name)}</td><td>${escapeHtml(c.gstin||'-')}</td><td>${escapeHtml(c.state||'-')}</td><td class="text-xs">${c.phone?`Ph: ${escapeHtml(c.phone)}<br>`:''}${c.email?`@: ${escapeHtml(c.email)}`:''}</td><td class="text-center"><div class="btn-group"><button class="btn btn-outline btn-sm" onclick="openClientModal(${c.id})"><i class="fas fa-edit"></i></button><button class="btn btn-danger btn-sm" onclick="deleteClient(${c.id}, this)"><i class="fas fa-trash"></i></button></div></td>`;});renderClientPagination(page,d.total_clients,search);}else{clientsTableBody.innerHTML=`<tr><td colspan="5" class="empty-table">No clients found.</td></tr>`;}}); }
        function renderClientPagination(page, total, search) { /* ... Pagination logic ... */ }
        function saveClient(btn){const f=document.getElementById('client-form');if(!f.checkValidity()){f.reportValidity();return;}const data=new FormData(f);data.append('action','save_client');btn.disabled=true;fetch('api.php',{method:'POST',body:data}).then(r=>r.json()).then(d=>{if(d.success){showToast('Success',d.message,'success');closeClientModal();loadClients(1,clientSearchTabInput.value.trim());loadClientDropdown('',d.client?.id);}else{showToast('Error',d.message,'error');}}).finally(()=>btn.disabled=false);}
        function deleteClient(id,btn){if(!confirm('Delete?'))return;btn.disabled=true;fetch(`api.php?action=delete_client&id=${id}`).then(r=>r.json()).then(d=>{if(d.success){showToast('Success',d.message,'success');loadClients(1,clientSearchTabInput.value.trim());loadClientDropdown();}else{showToast('Error',d.message,'error');}}).finally(()=>btn.disabled=false);}

        // --- Invoice Form Logic ---
        function loadBankDropdown(id){const sel=document.getElementById(id);fetch('api.php?action=get_banks').then(r=>r.json()).then(d=>{sel.innerHTML='<option value="">-- No Bank Details --</option>';if(d.success&&d.banks.length>0){d.banks.forEach(b=>{const opt=new Option(`${escapeHtml(b.bank_name)} (...${(b.account_number||'').slice(-4)})`,b.id);sel.appendChild(opt);});}});}
        function addItem(){const tr=invoiceItemsTbody.insertRow();tr.innerHTML=`<td><input name="description[]" required></td><td><input type="number" name="quantity[]" value="1.00" step="any" required></td><td><input type="number" name="rate[]" value="0.00" step="0.01" required></td><td><input name="amount[]" readonly class="text-right"></td><td class="text-center"><button type="button" class="btn btn-danger btn-sm remove-item">×</button></td>`;updateTotals();}
        invoiceItemsTbody?.addEventListener('input', e=>{if(e.target.name==='quantity[]'||e.target.name==='rate[]')updateTotals();});
        invoiceItemsTbody?.addEventListener('click', e=>{if(e.target.classList.contains('remove-item'))e.target.closest('tr').remove();updateTotals();});
        function updateTotals(){let sub=0;invoiceItemsTbody.querySelectorAll('tr').forEach(r=>{const q=parseFloat(r.querySelector('[name="quantity[]"]').value)||0;const t=parseFloat(r.querySelector('[name="rate[]"]').value)||0;const a=roundTo(q*t);r.querySelector('[name="amount[]"]').value=a.toFixed(2);sub+=a;});sub=roundTo(sub);const discR=parseFloat(document.getElementById('discount_rate').value)||0;const cgstR=parseFloat(document.getElementById('cgst_rate').value)||0;const sgstR=parseFloat(document.getElementById('sgst_rate').value)||0;const convF=parseFloat(document.getElementById('convenience_fee').value)||0;const advP=parseFloat(document.getElementById('advance_paid').value)||0;const discA=roundTo(sub*discR/100);const taxA=sub-discA;const cgstA=roundTo(taxA*cgstR/100);const sgstA=roundTo(taxA*sgstR/100);const total=roundTo(taxA+cgstA+sgstA+convF);const due=roundTo(total-advP);document.getElementById('subtotal').textContent=sub.toFixed(2);document.getElementById('discount-amount').textContent=discA.toFixed(2);document.getElementById('cgst-amount').textContent=cgstA.toFixed(2);document.getElementById('sgst-amount').textContent=sgstA.toFixed(2);document.getElementById('total-amount').textContent=total.toFixed(2);document.getElementById('amount-due').textContent=due.toFixed(2);}
        document.querySelectorAll('#cgst_rate, #sgst_rate, #convenience_fee, #advance_paid, #discount_rate').forEach(el=>el.addEventListener('input',updateTotals));
        function saveInvoice(btn){const f=document.getElementById('invoice-form');if(!f.checkValidity()){f.reportValidity();return;}const data=new FormData(f);data.append('action','save_invoice');btn.disabled=true;fetch('api.php',{method:'POST',body:data}).then(r=>r.json()).then(d=>{if(d.success){localStorage.setItem('flashMessage',JSON.stringify({type:'success',message:d.message}));window.location.href='index.php#invoices';}else{showToast('Error',d.message,'error');}}).finally(()=>btn.disabled=false);}
        function resetCreateInvoiceForm(){document.getElementById('invoice-form').reset();document.getElementById('invoice_number').value='<?php echo h($next_invoice_num_display); ?>';document.getElementById('invoice_date').valueAsDate=new Date();clientSelect.value='';updateClientDetailsDisplay();invoiceItemsTbody.innerHTML='';addItem();updateTotals();document.getElementById('notes').value='<?php echo h($company['default_notes'] ?? ''); ?>';}
        
        function editInvoice(id){window.location.href=`edit_invoice.php?id=${id}`;}
        function deleteInvoice(id,btn){if(!confirm('Delete?'))return;btn.disabled=true;fetch(`api.php?action=delete_invoice&id=${id}`).then(r=>r.json()).then(d=>{if(d.success){showToast('Success',d.message,'success');fetch('api_estimates.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({action:'revert_estimate_from_invoice',invoice_id:id})}).catch(e=>console.error("BG Revert Failed:",e));btn.closest('tr').style.opacity=0;setTimeout(()=>window.location.reload(),500);}else{showToast('Error',d.message,'error');}}).finally(()=>btn.disabled=false);}
        
        // --- Filename Helper ---
        function buildFileName(data, prefix = 'Invoice', copyType = '') {
            let clientName = (data.client || 'Client').replace(/\s+/g, '_').replace(/[\\/:*?"<>|]/g, '');
            const date = new Date(data.date + 'T00:00:00');
            const formattedDate = String(date.getDate()).padStart(2, '0') + '-' + String(date.getMonth() + 1).padStart(2, '0') + '-' + date.getFullYear();
            const copySuffix = copyType ? `_${copyType.toUpperCase()}` : '';
            return `${prefix}_${data.number}_${clientName}_${formattedDate}${copySuffix}.pdf`;
        }

        // --- Preview, Download, Print ---
        function viewInvoice(id) {
            const previewContentEl = document.getElementById('invoice-preview-content');
            const downloadBtn = document.querySelector('#invoice-preview-modal .btn-success');
            if (!previewContentEl) return;
            previewContentEl.innerHTML = '<p class="text-center p-4">Loading...</p>';
            if(downloadBtn) downloadBtn.setAttribute('onclick', '');
            
            openModal(previewModal);
            fetch(`api.php?action=get_invoice&id=${id}`)
                .then(r => r.ok ? r.json() : Promise.reject('API Error'))
                .then(d => {
                    if (d.success) {
                        previewContentEl.innerHTML = d.html;
                        if (d.fileNameData && downloadBtn) {
                            const fileName = buildFileName(d.fileNameData, 'Invoice');
                            downloadBtn.setAttribute('onclick', `downloadInvoicePDF('${escapeHtml(fileName)}')`);
                        }
                    } else { showToast('Error', d.message, 'error'); }
                });
        }
        
        function previewInvoice() { // For "Create Invoice" tab
            const form = document.getElementById('invoice-form');
            if(!form.checkValidity()) { form.reportValidity(); return; }
            const formData = new FormData(form);
            formData.append('action', 'preview_invoice');
            
            const previewContentEl = document.getElementById('invoice-preview-content');
            const downloadBtn = document.querySelector('#invoice-preview-modal .btn-success');
            if (previewContentEl) previewContentEl.innerHTML = '<p class="p-4 text-center">Generating...</p>';
            if(downloadBtn) downloadBtn.setAttribute('onclick', '');

            openModal(previewModal);
            fetch('api.php', { method: 'POST', body: formData })
                .then(r => r.json())
                .then(d => {
                    if (d.success) {
                        if (previewContentEl) previewContentEl.innerHTML = d.html;
                        if (downloadBtn) {
                           const clientName = clientSelect.options[clientSelect.selectedIndex]?.dataset.name || 'Client';
                           const fileName = buildFileName({ client: clientName, number: form.invoice_number.value, date: form.invoice_date.value }, 'Invoice');
                           downloadBtn.setAttribute('onclick', `downloadInvoicePDF('${escapeHtml(fileName)}')`);
                        }
                    } else { showToast('Error', d.message, 'error'); }
                });
        }
        
        function downloadInvoicePDF(fileName) {
            const contentEl = document.getElementById('invoice-preview-content');
            if (!contentEl?.firstElementChild) return;
            showToast('Info', 'Generating PDF...', 'info');
            const opt = { margin: 0.5, filename: fileName, image: { type: 'jpeg', quality: 0.98 }, html2canvas: { scale: 2, useCORS: true }, jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' } };
            html2pdf().set(opt).from(contentEl.firstElementChild).save();
        }

        // ** NEW: Direct Download for Original/Duplicate **
        function downloadInvoiceCopy(invoiceId, copyType) {
            showToast('Info', `Generating ${copyType} copy...`, 'info');
            fetch(`api.php?action=get_invoice&id=${invoiceId}`)
                .then(r => r.ok ? r.json() : Promise.reject('API Error'))
                .then(data => {
                    if (data.success && data.html) {
                        const tempContainer = document.createElement('div');
                        tempContainer.innerHTML = data.html;
                        const invoiceWrapper = tempContainer.querySelector('div[style*="font-family"]');
                        if (invoiceWrapper) {
                            const allDivs = invoiceWrapper.getElementsByTagName('div');
                            for (let div of allDivs) {
                                if (div.textContent.trim() === 'Original for Recipient') {
                                    div.textContent = (copyType === 'DUPLICATE') ? 'Duplicate for Transporter' : 'Original for Recipient';
                                    break;
                                }
                            }
                            const watermark = document.createElement('div');
                            watermark.textContent = copyType.toUpperCase();
                            Object.assign(watermark.style, { position: 'absolute', top: '45%', left: '50%', transform: 'translate(-50%, -50%) rotate(-45deg)', fontSize: '4.5rem', fontWeight: '800', color: 'rgba(255, 0, 0, 0.12)', zIndex: '0', whiteSpace: 'nowrap', pointerEvents: 'none', textTransform: 'uppercase', letterSpacing: '5px', border: '6px solid rgba(255, 0, 0, 0.15)', borderRadius: '10px', padding: '0 2rem' });
                            invoiceWrapper.insertBefore(watermark, invoiceWrapper.firstChild);
                        }
                        
                        const fileName = buildFileName(data.fileNameData, 'Invoice', copyType);
                        const opt = { margin: 0.5, filename: fileName, image: { type: 'jpeg', quality: 0.98 }, html2canvas: { scale: 2, useCORS: true }, jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' } };
                        html2pdf().set(opt).from(tempContainer.firstElementChild).save();

                    } else { showToast('Error', data.message || 'Failed to load invoice.', 'error'); }
                }).catch(e => showToast('Error', 'Could not generate copy.', 'error'));
        }

        // Old print function, kept for "Print" button in modal
        function printInvoice() {
            const contentEl = document.getElementById('invoice-preview-content');
            if(!previewModal || !contentEl?.querySelector('table')) { showToast('Info','Generate a preview first.','info'); return; }
            const tempIframe = document.createElement('iframe');
            tempIframe.style.cssText = 'position:fixed;top:-9999px;left:-9999px;width:0;height:0;border:0;';
            document.body.appendChild(tempIframe);
            const doc = tempIframe.contentWindow.document;
            doc.open();
            doc.write(`<!DOCTYPE html><html><head><title>Invoice</title><link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet"><style>@media print{ body{-webkit-print-color-adjust: exact; font-size: 10pt !important; } @page{size: A4; margin: 1cm;} .status-badge{display:none!important;} }</style></head><body>${contentEl.innerHTML}</body></html>`);
            doc.close();
            setTimeout(() => {
                try { tempIframe.contentWindow.focus(); tempIframe.contentWindow.print(); }
                catch(e){ showToast('Error','Printing failed.','error'); }
                setTimeout(() => { document.body.removeChild(tempIframe); }, 1000);
            }, 350);
        }

        // --- Initial Page Load ---
        document.addEventListener('DOMContentLoaded', function() {
             let initialTab = window.location.hash.substring(1) || 'invoices';
             if (!document.getElementById(`${initialTab}-tab`)) initialTab = 'invoices';
             showTab(initialTab);
             loadClientDropdown();
             loadBankDropdown('bank_account_id');
             if (invoiceItemsTbody && invoiceItemsTbody.rows.length === 0) { addItem(); }
             updateTotals();
             setTimeout(() => { document.getElementById('php-flash-message-success')?.remove(); document.getElementById('php-flash-message-error')?.remove(); }, 7000);
             const flash = localStorage.getItem('flashMessage');
             if(flash) { try { const f = JSON.parse(flash); showToast(f.type === 'success' ? 'Success' : 'Error', f.message, f.type); localStorage.removeItem('flashMessage'); } catch(e){} }
        });
    </script>
</body>
</html>