<?php
// Include config and check login
require_once 'db_config.php';
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}
$user_id = $_SESSION["id"];
$username = $_SESSION["username"];
function h($text) { return htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8'); }

// Default Date Range (e.g., current year)
$default_start_date = date('Y-01-01');
$default_end_date = date('Y-m-d');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Libraries -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"> <!-- Optional: for icons -->
    <title>Client Status Report - GST Invoice System</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* --- PASTE ALL CSS from index.php / bank.php here --- */
        /* Ensure styles for :root, body, .container, .card, .btn, forms, tables, etc. are present */
         :root {
            --primary: #1e40af; --primary-light: #3b82f6; --primary-dark: #1e3a8a;
            --secondary: #64748b; --accent: #f59e0b; --danger: #ef4444; --success: #10b981;
            --warning: #f59e0b; --info: #3b82f6; --light: #f8fafc; --dark: #1e293b;
            --body-bg: #f1f5f9; --card-bg: #ffffff; --border-color: #e2e8f0;
            --text-primary: #334155; --text-secondary: #64748b; --text-muted: #94a3b8;
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            --radius-sm: 0.125rem; --radius: 0.25rem; --radius-md: 0.375rem; --radius-lg: 0.5rem; --radius-xl: 0.75rem;
            --status-paid-bg: #d1fae5; --status-paid-text: #065f46; /* Lighter green */
            --status-unpaid-bg: #fee2e2; --status-unpaid-text: #991b1b; /* Lighter red */
            --status-partial-bg: #fef3c7; --status-partial-text: #92400e; /* Lighter amber */
            --status-default-bg: #e5e7eb; --status-default-text: #4b5563; /* Light Gray for Unknown/Default */
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Poppins', sans-serif; background-color: var(--body-bg); color: var(--text-primary); line-height: 1.6; font-size: 14px; }
        /* Layout */
        .container { max-width: 1300px; margin: 0 auto; padding: 1.5rem; } /* Slightly wider than standard dashboard */
        .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; padding-bottom: 1rem; border-bottom: 1px solid var(--border-color); }
        .page-title h1 { font-size: 1.5rem; font-weight: 600; color: var(--primary); }
        .user-menu { display: flex; align-items: center; gap: 0.75rem; }
        .user-name { font-weight: 500; }
        .card { background: var(--card-bg); border-radius: var(--radius-lg); box-shadow: var(--shadow); overflow: hidden; margin-bottom: 1.5rem; } /* Slightly lighter shadow */
        .card-header { padding: 0.8rem 1.25rem; border-bottom: 1px solid var(--border-color); background-color: var(--light); display: flex; justify-content: space-between; align-items: center; }
        .card-title { font-size: 1rem; font-weight: 600; color: var(--text-primary); }
        .card-body { padding: 1.25rem; }
        /* Forms */
        .form-row { display: flex; flex-wrap: wrap; gap: 1rem; margin-bottom: 1rem; }
        .form-col { flex: 1; min-width: 200px; }
        label { display: block; font-weight: 500; margin-bottom: 0.4rem; color: var(--text-primary); font-size: 0.8rem; }
        input[type="date"], select { width: 100%; padding: 0.5rem 0.75rem; border: 1px solid var(--border-color); border-radius: var(--radius); font-size: 0.875rem; }
        input:focus, select:focus { outline: none; border-color: var(--primary-light); box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.2); }
        /* Buttons */
        .btn { display: inline-flex; align-items: center; justify-content: center; padding: 0.5rem 1rem; border-radius: var(--radius); font-weight: 500; cursor: pointer; transition: all 0.2s ease; border: 1px solid transparent; font-size: 0.875rem; text-decoration: none; white-space: nowrap; }
        .btn-primary { background-color: var(--primary); color: white; } .btn-primary:hover:not(:disabled) { background-color: var(--primary-dark); }
        .btn-outline { background-color: transparent; border-color: var(--border-color); color: var(--text-primary); } .btn-outline:hover:not(:disabled) { border-color: var(--primary); color: var(--primary); background-color: rgba(30, 64, 175, 0.05); }
        .btn-sm { padding: 0.25rem 0.625rem; font-size: 0.75rem; }
        .btn-icon { margin-right: 0.3rem; }
        .btn:disabled { background-color: var(--secondary) !important; opacity: 0.6; cursor: not-allowed; }
        /* Tables */
        .table-responsive { overflow-x: auto; max-height: 65vh; } /* Max height for scroll */
        .report-table { width: 100%; border-collapse: collapse; }
        .report-table th, .report-table td { padding: 0.6rem 0.8rem; border-bottom: 1px solid var(--border-color); vertical-align: middle; font-size: 0.85rem; }
        .report-table thead th { background-color: var(--light); font-weight: 600; text-align: left; border-bottom-width: 2px; color: var(--text-secondary); white-space: nowrap; position: sticky; top: 0; z-index: 5; }
        .report-table tbody tr:hover { background-color: #f0f9ff; }
        .report-table .currency, .report-table th.currency { text-align: right; white-space: nowrap;}
        .report-table .count, .report-table th.count { text-align: center;}
        .report-table .client-name { font-weight: 500; }
        .report-table .due-amount { color: var(--danger); font-weight: 500; }
        .report-table .paid-amount { color: var(--success); }
        .empty-table td { text-align: center; padding: 2rem; color: var(--text-secondary); }
        #loading-indicator { text-align: center; padding: 2rem; color: var(--text-secondary); font-style: italic; }
        /* Select2 Styles */
        .select2-container--default .select2-selection--multiple { border: 1px solid var(--border-color); border-radius: var(--radius); padding: 0.2rem 0.5rem; min-height: 38px; } /* Adjust height */
        .select2-container--default.select2-container--focus .select2-selection--multiple { border-color: var(--primary-light); box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.2); }
        .select2-container--default .select2-selection--multiple .select2-selection__choice { background-color: var(--primary-light); border: 1px solid var(--primary); color: white; padding: 0.1rem 0.5rem; margin-right: 0.3rem; margin-top: 0.2rem; }
        .select2-container--default .select2-selection--multiple .select2-selection__choice__remove { color: rgba(255, 255, 255, 0.7); margin-left: 0.3rem; font-size: 0.9em;}
        .select2-dropdown { border: 1px solid var(--border-color); border-radius: var(--radius); }
         /* Toast */
        #toast-container { position: fixed; top: 1rem; right: 1rem; z-index: 9999; width: 320px; }
        .toast { /* ... Copy toast styles from index.php ... */ background-color: white; border-radius: var(--radius); box-shadow: var(--shadow-lg); margin-bottom: 0.75rem; overflow: hidden; border-left: 4px solid var(--dark); animation: slideInRight 0.3s ease-out, fadeOut 0.5s ease-out 4.5s forwards; }
        .toast-header { padding: 0.5rem 1rem; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--border-color); } .toast-title { font-weight: 600; font-size: 0.875rem; } .toast-close { background: transparent; border: none; font-size: 1.25rem; line-height: 1; cursor: pointer; color: var(--text-secondary); opacity: 0.7;} .toast-close:hover { opacity: 1; } .toast-body { padding: 0.75rem 1rem; font-size: 0.875rem;}
        .toast-success { border-left-color: var(--success); } .toast-error { border-left-color: var(--danger); }
        @keyframes slideInRight { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        @keyframes fadeOut { from { opacity: 1; } to { opacity: 0; } }

    </style>
</head>
<body>
    <div class="container">
        <div class="page-header">
            <div class="page-title"><h1>Client Status Report</h1></div>
            <div class="user-menu">
                <a href="index.php" class="btn btn-outline btn-sm"><i class="fas fa-arrow-left btn-icon"></i>Dashboard</a>
                <span class="user-name"><?php echo h($username); ?></span>
                <a href="logout.php" class="btn btn-outline btn-sm">Sign Out</a>
            </div>
        </div>

        <!-- Filter Card -->
        <div class="card">
            <div class="card-header"><h2 class="card-title">Report Filters</h2></div>
            <div class="card-body">
                <form id="client-report-filter-form" onsubmit="return false;">
                    <div class="form-row">
                        <div class="form-col">
                            <label for="start_date">Start Date (Invoice Date)</label>
                            <input type="date" id="start_date" name="start_date" value="<?php echo h($default_start_date); ?>">
                        </div>
                        <div class="form-col">
                            <label for="end_date">End Date (Invoice Date)</label>
                            <input type="date" id="end_date" name="end_date" value="<?php echo h($default_end_date); ?>">
                        </div>
                        <div class="form-col">
                            <label for="report_client_ids">Clients</label>
                            <select id="report_client_ids" name="client_ids[]" multiple="multiple" style="width: 100%;" required>
                                <!-- Loaded by JS -->
                            </select>
                        </div>
                         <div class="form-col" style="flex: 0 0 auto; align-self: flex-end;">
                            <button type="button" class="btn btn-primary" onclick="runClientStatusReport()">
                                <i class="fas fa-paper-plane btn-icon"></i>Generate Report
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Results Card -->
        <div class="card">
             <div class="card-header">
                <h2 class="card-title">Report Results</h2>
                <button type="button" class="btn btn-outline btn-sm" id="export-report-csv-btn" onclick="exportClientStatusReport()" disabled>
                    <i class="fas fa-file-csv btn-icon"></i>Export CSV
                </button>
            </div>
            <div class="card-body">
                 <div id="loading-indicator" style="display: none;"><p>Loading report data...</p></div>
                <div id="report-content">
                     <!-- Overall KPIs can go here if desired -->
                    <div class="table-responsive">
                        <table class="report-table" id="client-status-table">
                            <thead>
                                <tr>
                                     <th class="client-name">Client Name</th>
                                     <th class="count">Total Invoices</th>
                                     <th class="currency">Total Billed</th>
                                    <th class="count"># Paid</th>
                                     <th class="count"># Unpaid/Partial</th>
                                     <th class="currency paid-amount">Total Paid Amt</th>
                                     <th class="currency due-amount">Total Due Amt</th>
                                </tr>
                            </thead>
                            <tbody id="client-status-table-body">
                                <tr><td colspan="7" class="empty-table">Apply filters and click "Generate Report".</td></tr>
                            </tbody>
                            <tfoot id="client-status-table-foot" style="font-weight: bold; background-color: var(--light);">
                                <!-- Totals row populated by JS -->
                            </tfoot>
                        </table>
                     </div>
                 </div>
            </div>
        </div>

    </div> <!-- End Container -->
    <div id="toast-container"></div> <!-- Notifications -->

    <script>
        // Utilities (assuming escapeHtml, showToast, formatCurrency are available or copied)
        function escapeHtml(unsafe) { /* Copy from previous */ if (typeof unsafe !== 'string') return unsafe ?? ''; const map = { '&': '&', '<': '<', '>': '>', '"': '"', "'": '&#039' }; return unsafe.replace(/[&<>"']/g, m => map[m]); }
        function showToast(title, message, type = 'info') { /* Copy from previous */ const tc = document.getElementById('toast-container'); if(!tc) return; const t = document.createElement('div'); t.className = `toast toast-${type}`; let i = type === 'success' ? '✓' : (type === 'error' ? '✗' : 'ℹ️'); t.innerHTML = `<div class="toast-header"><span class="toast-title">${i} ${escapeHtml(title)}</span><button type="button" class="toast-close" onclick="this.parentElement.parentElement.remove()">×</button></div><div class="toast-body">${escapeHtml(message)}</div>`; tc.appendChild(t); }
        const currencyFormatter = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', minimumFractionDigits: 2, maximumFractionDigits: 2 });
        function formatCurrency(amount) { return currencyFormatter.format(parseFloat(amount) || 0); }

        // Store last used valid filters for export
        let lastValidFiltersForExport = null;

        // Initialize Select2 and Load Clients
        $(document).ready(function() {
            $('#report_client_ids').select2({
                placeholder: "Select one or more clients...",
                width: '100%'
             });

            $.ajax({ // Load clients into the selector
                url: 'api.php', data: { action: 'get_clients', limit: 10000 },
                dataType: 'json',
                 success: function(data) {
                     if (data.success && data.clients) {
                        const $select = $('#report_client_ids');
                        $select.empty(); // Clear placeholder/old options
                        data.clients.forEach(client => {
                            $select.append(new Option(escapeHtml(client.name) + (client.gstin ? ` (${escapeHtml(client.gstin)})` : ''), client.id));
                         });
                    } else { console.error("Failed loading clients:", data.message); showToast('Error', 'Failed to load client list', 'error');}
                 },
                error: function() { console.error("AJAX Error loading clients"); showToast('Error', 'Network error loading clients', 'error'); }
            });
        });

        // Main report function
        function runClientStatusReport() {
            const $clientSelect = $('#report_client_ids');
            const startDate = $('#start_date').val();
            const endDate = $('#end_date').val();
            const clientIds = $clientSelect.val(); // Returns array of selected IDs

            // Validation
            if (!startDate || !endDate) { showToast('Input Needed', 'Please select a Start and End date.', 'warning'); return; }
            if (startDate > endDate) { showToast('Input Error', 'Start Date cannot be after End Date.', 'warning'); return; }
            if (!clientIds || clientIds.length === 0) { showToast('Input Needed', 'Please select at least one client.', 'warning'); $clientSelect.select2('open'); return; }

            // Update UI
            $('#loading-indicator').show();
             $('#report-content').hide(); // Hide results area while loading
            $('#client-status-table-body').html('<tr><td colspan="7" class="empty-table">Generating report...</td></tr>');
            $('#client-status-table-foot').html(''); // Clear footer totals
            $('#export-report-csv-btn').prop('disabled', true); // Disable export btn
             lastValidFiltersForExport = null; // Clear last filters

            // Prepare data for API
            const filters = {
                action: 'get_client_status_report', // ** Use the new action name **
                start_date: startDate,
                end_date: endDate,
                'client_ids[]': clientIds // Use name with [] for array
            };

            // API Call
            $.ajax({
                url: 'api.php', type: 'GET',
                data: filters, dataType: 'json',
                success: function(data) {
                     $('#loading-indicator').hide();
                    if (data.success && data.summary && data.summary.length > 0) {
                         renderClientStatusTable(data.summary);
                         $('#report-content').show();
                         $('#export-report-csv-btn').prop('disabled', false); // Enable export
                        lastValidFiltersForExport = filters; // Store successful filters
                    } else if (data.success) {
                         $('#client-status-table-body').html('<tr><td colspan="7" class="empty-table">No invoices found for the selected criteria.</td></tr>');
                        $('#report-content').show(); // Show the table container even if empty
                    } else {
                        showToast('Error', data.message || 'Failed to generate report.', 'error');
                         $('#client-status-table-body').html(`<tr><td colspan="7" class="empty-table text-danger">Error: ${escapeHtml(data.message || 'Unknown error')}</td></tr>`);
                        $('#report-content').show();
                    }
                 },
                error: function(jqXHR, textStatus, errorThrown) {
                    $('#loading-indicator').hide();
                    console.error("Report AJAX Error:", textStatus, errorThrown, jqXHR.responseText);
                     showToast('Error', 'A network or server error occurred.', 'error');
                    $('#client-status-table-body').html('<tr><td colspan="7" class="empty-table text-danger">Network/Server Error</td></tr>');
                    $('#report-content').show();
                }
            });
        }

        function renderClientStatusTable(summaryData) {
            const $tableBody = $('#client-status-table-body');
            const $tableFoot = $('#client-status-table-foot');
            $tableBody.empty(); // Clear previous results
            $tableFoot.empty();

            let grandTotalInvoices = 0, grandTotalBilled = 0, grandTotalPaidCount = 0, grandTotalUnpaidCount = 0, grandTotalPaidAmt = 0, grandTotalDueAmt = 0;

            summaryData.forEach(client => {
                const invoiced = parseFloat(client.total_invoiced) || 0;
                const paidAmt = parseFloat(client.total_paid_amount) || 0;
                const dueAmt = parseFloat(client.total_due_amount) || 0;
                const paidCount = parseInt(client.paid_count) || 0;
                const unpaidCount = parseInt(client.unpaid_partial_count) || 0;
                 const totalCount = parseInt(client.total_invoice_count) || (paidCount + unpaidCount); // Fallback count

                grandTotalInvoices += totalCount;
                grandTotalBilled += invoiced;
                grandTotalPaidCount += paidCount;
                grandTotalUnpaidCount += unpaidCount;
                 grandTotalPaidAmt += paidAmt;
                 grandTotalDueAmt += dueAmt;

                const row = $tableBody[0].insertRow(); // Use vanilla JS for rows
                row.innerHTML = `
                     <td class="client-name">${escapeHtml(client.client_name)}</td>
                     <td class="count">${totalCount}</td>
                    <td class="currency">${formatCurrency(invoiced)}</td>
                    <td class="count">${paidCount}</td>
                    <td class="count">${unpaidCount}</td>
                     <td class="currency paid-amount">${formatCurrency(paidAmt)}</td>
                     <td class="currency due-amount">${formatCurrency(dueAmt)}</td>
                `;
             });

             // Add totals row to footer
            const footerRow = $tableFoot[0].insertRow();
            footerRow.innerHTML = `
                 <td><strong>Grand Totals</strong></td>
                <td class="count"><strong>${grandTotalInvoices}</strong></td>
                <td class="currency"><strong>${formatCurrency(grandTotalBilled)}</strong></td>
                <td class="count"><strong>${grandTotalPaidCount}</strong></td>
                <td class="count"><strong>${grandTotalUnpaidCount}</strong></td>
                 <td class="currency paid-amount"><strong>${formatCurrency(grandTotalPaidAmt)}</strong></td>
                <td class="currency due-amount"><strong>${formatCurrency(grandTotalDueAmt)}</strong></td>
             `;
         }

        // --- Export ---
        function exportClientStatusReport() {
            if (!lastValidFiltersForExport) {
                 showToast('Run Report First', 'Please generate a report before exporting.', 'info');
                return;
            }

            // Remove existing action and add the export action
            const exportParams = new URLSearchParams();
            Object.entries(lastValidFiltersForExport).forEach(([key, value]) => {
                 if (key !== 'action') { // Exclude the 'get' action
                    if (Array.isArray(value)) { // Handle client_ids array
                         value.forEach(val => exportParams.append(key, val));
                    } else {
                         exportParams.set(key, value);
                     }
                 }
             });
            exportParams.set('action', 'export_client_status_csv'); // Set export action

             const exportUrl = `api.php?${exportParams.toString()}`;

            // Use window.location to trigger download
             console.log('Export URL:', exportUrl); // Debugging
             window.location.href = exportUrl;
             showToast('Export Started', 'Your CSV export is generating...', 'info');
        }

    </script>
</body>
</html>