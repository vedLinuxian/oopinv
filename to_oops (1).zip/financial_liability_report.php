<?php
// Include database configuration and start session
require_once 'db_config.php';

// Check if the user is logged in
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}

// Get user information
$user_id = $_SESSION["id"];
$username = $_SESSION["username"];

// --- Helper Functions ---
function h($text) { return htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8'); }

// --- Financial Year Calculation (Now Dynamic) ---

// 1. Fetch all financial years the user has data for
$available_fys = [];
$sql_fys = "SELECT DISTINCT IF(MONTH(invoice_date) >= 4, YEAR(invoice_date), YEAR(invoice_date) - 1) AS fy_start_year
            FROM invoices WHERE user_id = :user_id ORDER BY fy_start_year DESC";
$fys_result = query($conn, $sql_fys, ['user_id' => $user_id]);
if ($fys_result) {
    $available_fys = fetch_all($fys_result);
}

// 2. Determine the selected or default financial year
$selected_fy_start_year = null;
if (isset($_GET['fy']) && ctype_digit((string)$_GET['fy'])) {
    // Check if the selected year is valid for this user
    foreach ($available_fys as $fy_option) {
        if ($fy_option['fy_start_year'] == $_GET['fy']) {
            $selected_fy_start_year = (int)$_GET['fy'];
            break;
        }
    }
}

// If no valid year is selected, default to the most recent one or the current FY
if (is_null($selected_fy_start_year)) {
    if (!empty($available_fys)) {
        $selected_fy_start_year = (int)$available_fys[0]['fy_start_year']; // Most recent year from data
    } else {
        // Fallback to current FY if there's no invoice data at all
        $current_month = (int)date('n');
        $current_year = (int)date('Y');
        $selected_fy_start_year = ($current_month >= 4) ? $current_year : $current_year - 1;
    }
}

// 3. Calculate the date range based on the determined financial year
$fy_start_date = $selected_fy_start_year . '-04-01';
$fy_end_date = ($selected_fy_start_year + 1) . '-03-31';
$fy_label = $selected_fy_start_year . '-' . substr(($selected_fy_start_year + 1), -2);

// --- Report Data Initialization ---
$report_data = [];
$top_defaulters = [];
$summary_kpis = [
    'total_outstanding_amount' => 0.00, 'total_gst_liability' => 0.00,
    'total_invoices' => 0, 'total_clients' => 0
];
$error_message = null;

try {
    // --- The Main Report Query (Now uses dynamic dates) ---
    $sql_report = "SELECT 
                       i.id, i.invoice_number, i.invoice_date, i.total_amount, i.advance_paid,
                       (i.cgst_amount + i.sgst_amount) as gst_liability,
                       GREATEST(0, i.total_amount - i.advance_paid) as outstanding_amount,
                       c.id as client_id, c.name as client_name
                   FROM invoices i
                   LEFT JOIN clients c ON i.client_id = c.id
                   WHERE i.user_id = :user_id
                     AND i.status IN ('unpaid', 'partially_paid')
                     AND i.invoice_date BETWEEN :fy_start_date AND :fy_end_date
                   ORDER BY outstanding_amount DESC";
    
    $params = [ 'user_id' => $user_id, 'fy_start_date' => $fy_start_date, 'fy_end_date' => $fy_end_date ];
    $report_result = query($conn, $sql_report, $params);
    $report_data = $report_result ? fetch_all($report_result) : [];

    // --- Process Data for Statistics ---
    if (!empty($report_data)) {
        $client_outstanding = [];
        foreach($report_data as $invoice) {
            $summary_kpis['total_outstanding_amount'] += (float)$invoice['outstanding_amount'];
            $summary_kpis['total_gst_liability'] += (float)$invoice['gst_liability'];
            if (!isset($client_outstanding[$invoice['client_id']])) {
                $client_outstanding[$invoice['client_id']] = ['name' => $invoice['client_name'], 'total_due' => 0];
            }
            $client_outstanding[$invoice['client_id']]['total_due'] += (float)$invoice['outstanding_amount'];
        }
        $summary_kpis['total_invoices'] = count($report_data);
        $summary_kpis['total_clients'] = count($client_outstanding);
        uasort($client_outstanding, function($a, $b) { return $b['total_due'] <=> $a['total_due']; });
        $top_defaulters = array_slice($client_outstanding, 0, 5, true);
    }

    // --- Handle CSV Export Request ---
    if (isset($_GET['export']) && $_GET['export'] === 'csv') {
        $filename = "Financial_Liability_Report_FY_{$fy_label}.csv";
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        $output = fopen('php://output', 'w');
        fputcsv($output, ['Invoice #', 'Invoice Date', 'Client Name', 'Total Amount (₹)', 'Amount Paid (₹)', 'Outstanding Amount (₹)', 'GST Liability (₹)']);
        foreach ($report_data as $invoice) {
            fputcsv($output, [$invoice['invoice_number'], $invoice['invoice_date'], $invoice['client_name'], number_format((float)$invoice['total_amount'], 2), number_format((float)$invoice['advance_paid'], 2), number_format((float)$invoice['outstanding_amount'], 2), number_format((float)$invoice['gst_liability'], 2)]);
        }
        fputcsv($output, []);
        fputcsv($output, ["SUMMARY FOR FINANCIAL YEAR: {$fy_label}"]);
        fputcsv($output, ['Total Outstanding Amount:', number_format($summary_kpis['total_outstanding_amount'], 2)]);
        fputcsv($output, ['Total GST Liability:', number_format($summary_kpis['total_gst_liability'], 2)]);
        fclose($output);
        exit;
    }

} catch (Exception $e) {
    $error_message = "A database error occurred. Please try again.";
    error_log("Financial Liability Report Error for user $user_id: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Financial Liability Report - GST Invoice Generator</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root{--primary:#1e40af;--danger:#ef4444;--light:#f8fafc;--body-bg:#f1f5f9;--card-bg:#ffffff;--border-color:#e2e8f0;--text-primary:#334155;--text-secondary:#64748b;--shadow:0 1px 3px 0 rgba(0,0,0,0.1),0 1px 2px 0 rgba(0,0,0,0.06);--radius-lg:0.5rem;}
        *{margin:0;padding:0;box-sizing:border-box}
        body{font-family:'Poppins',sans-serif;background-color:var(--body-bg);color:var(--text-primary);font-size:14px;line-height:1.6}
        .container{max-width:1400px;margin:1.5rem auto;padding:0 1.5rem}
        .page-header{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:1rem;margin-bottom:1.5rem;padding-bottom:1rem;border-bottom:1px solid var(--border-color)}
        .page-title h1{font-size:1.5rem;font-weight:600;color:var(--primary)}
        .header-controls{display:flex;align-items:center;gap:1rem}
        .card{background:var(--card-bg);border-radius:var(--radius-lg);box-shadow:var(--shadow);margin-bottom:1.5rem}
        .card-header{padding:.8rem 1.25rem;border-bottom:1px solid var(--border-color);display:flex;justify-content:space-between;align-items:center}
        .card-title{font-size:1rem;font-weight:600}
        .card-body{padding:1.25rem}
        .btn{display:inline-flex;align-items:center;padding:.6rem 1rem;border-radius:.25rem;font-weight:500;cursor:pointer;border:1px solid transparent;font-size:.875rem;text-decoration:none}
        .btn-outline{border-color:var(--border-color);color:var(--text-primary)} .btn-outline:hover{border-color:var(--primary);color:var(--primary)}
        .btn-sm{padding:.3rem .7rem;font-size:.75rem} .btn-icon{margin-right:.4rem}
        .btn:disabled{opacity:.6;cursor:not-allowed}
        select#fy-picker{padding:0.4rem 0.6rem; font-size: 0.875rem; border: 1px solid var(--border-color); border-radius: 0.25rem; font-family: inherit; margin-left: .5rem;}
        .kpi-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;margin-bottom:1.5rem}
        .kpi-card{text-align:center;padding:1.25rem;background-color:var(--light);border:1px solid var(--border-color);border-radius:.5rem}
        .kpi-value{font-size:2rem;font-weight:700;display:block;color:var(--danger)}
        .kpi-value .sub{font-size:1.5rem;color:var(--text-primary)}
        .kpi-label{font-size:.8rem;color:var(--text-secondary);text-transform:uppercase}
        .report-grid{display:grid;grid-template-columns:3fr 1fr;gap:1.5rem;align-items:start}
        .table-responsive{overflow-x:auto}
        .data-table{width:100%;border-collapse:collapse}
        .data-table th,.data-table td{padding:.6rem .8rem;border-bottom:1px solid var(--border-color);text-align:left;font-size:.85rem}
        .data-table thead th{background-color:var(--light);font-weight:600;white-space:nowrap}
        .data-table .currency,.data-table .amount-due,.data-table .gst-liability{text-align:right} 
        .data-table .days-overdue{text-align:center;font-weight:600;color:var(--danger)}
        .data-table .amount-due{font-weight:600;} .data-table .gst-liability{font-weight:600;color:var(--primary-dark)}
        .top-defaulters-list{list-style:none;padding:0}
        .top-defaulters-list li{display:flex;justify-content:space-between;padding:.75rem 0;border-bottom:1px solid var(--border-color)}
        .top-defaulters-list li:last-child{border-bottom:none}
        .defaulter-name{font-weight:500} .defaulter-amount{font-weight:600;color:var(--danger)}
        @media(max-width:992px){.report-grid{grid-template-columns:1fr}}
        @media(max-width:768px){.kpi-grid{grid-template-columns:1fr}}
    </style>
</head>
<body>
    <div class="container">
        <div class="page-header">
            <div class="page-title">
                <h1>Financial Liability Report (FY: <?php echo h($fy_label); ?>)</h1>
            </div>
            <div class="header-controls">
                <form id="report-filter-form" method="GET" action="financial_liability_report.php" class="d-flex align-items-center">
                    <label for="fy-picker">Change FY:</label>
                    <select name="fy" id="fy-picker" onchange="this.form.submit()">
                        <?php foreach($available_fys as $fy): 
                            $fy_start = (int)$fy['fy_start_year'];
                            $fy_option_label = $fy_start . '-' . substr($fy_start + 1, -2);
                        ?>
                        <option value="<?php echo h($fy_start); ?>" <?php echo ($fy_start == $selected_fy_start_year) ? 'selected' : ''; ?>>
                            <?php echo h($fy_option_label); ?>
                        </option>
                        <?php endforeach; ?>
                        <?php if (empty($available_fys)): ?>
                            <option value="<?php echo h($selected_fy_start_year); ?>" selected><?php echo h($fy_label); ?></option>
                        <?php endif; ?>
                    </select>
                </form>
                <a href="index.php" class="btn btn-outline btn-sm"><i class="fas fa-arrow-left btn-icon"></i>Back to Dashboard</a>
            </div>
        </div>
        
        <?php if ($error_message): ?>
            <div class="card"><div class="card-body" style="color:var(--danger);"><?php echo h($error_message); ?></div></div>
        <?php else: ?>
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">Summary for Financial Year <?php echo h($fy_label); ?></h2>
                    <form method="GET" action="financial_liability_report.php">
                        <input type="hidden" name="fy" value="<?php echo h($selected_fy_start_year); ?>">
                        <button type="submit" name="export" value="csv" class="btn btn-outline btn-sm" <?php echo empty($report_data) ? 'disabled' : ''; ?>>
                            <i class="fas fa-file-csv btn-icon"></i>Export as CSV
                        </button>
                    </form>
                </div>
                <div class="card-body">
                    <div class="kpi-grid">
                        <div class="kpi-card"><span class="kpi-value">₹<?php echo number_format($summary_kpis['total_outstanding_amount'], 2); ?></span><span class="kpi-label">Total Outstanding Amount</span></div>
                        <div class="kpi-card"><span class="kpi-value">₹<?php echo number_format($summary_kpis['total_gst_liability'], 2); ?></span><span class="kpi-label">Total GST Liability</span></div>
                        <div class="kpi-card"><span class="kpi-value"><span class="sub"><?php echo $summary_kpis['total_invoices']; ?></span> from <span class="sub"><?php echo $summary_kpis['total_clients']; ?></span> Clients</span><span class="kpi-label">Outstanding Invoices</span></div>
                    </div>
                </div>
            </div>

            <div class="report-grid">
                <div class="main-report">
                    <div class="card">
                        <div class="card-header"><h2 class="card-title">Detailed List of Outstanding Invoices</h2></div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="data-table">
                                    <thead><tr><th>Invoice #</th><th>Client Name</th><th>Invoice Date</th><th class="currency">Outstanding (₹)</th><th class="currency">GST Liability (₹)</th></tr></thead>
                                    <tbody>
                                        <?php if (!empty($report_data)): ?>
                                            <?php foreach ($report_data as $invoice): ?>
                                            <tr>
                                                <td><a href="edit_invoice.php?id=<?php echo $invoice['id']; ?>" title="View Invoice"><?php echo h($invoice['invoice_number']); ?></a></td>
                                                <td><?php echo h($invoice['client_name']); ?></td>
                                                <td><?php echo h(date('d-m-Y', strtotime($invoice['invoice_date']))); ?></td>
                                                <td class="currency"><?php echo number_format((float)$invoice['outstanding_amount'], 2); ?></td>
                                                <td class="currency"><?php echo number_format((float)$invoice['gst_liability'], 2); ?></td>
                                            </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr><td colspan="5" class="empty-table">No outstanding invoices for FY <?php echo h($fy_label); ?>.</td></tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="sidebar-report">
                    <div class="card">
                        <div class="card-header"><h2 class="card-title">Top 5 Defaulters (FY <?php echo h($fy_label); ?>)</h2></div>
                        <div class="card-body">
                            <?php if (!empty($top_defaulters)): ?>
                                <ol class="top-defaulters-list">
                                    <?php foreach($top_defaulters as $client): ?>
                                    <li><span class="defaulter-name"><?php echo h($client['name']); ?></span><span class="defaulter-amount">₹<?php echo number_format($client['total_due'], 2); ?></span></li>
                                    <?php endforeach; ?>
                                </ol>
                            <?php else: ?>
                                <p style="color:var(--text-muted); text-align:center; padding: 1rem 0;">No outstanding amounts found.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>