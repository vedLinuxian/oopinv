<?php
// Include database configuration
// db_config.php already handles starting the session if needed.
require_once 'db_config.php';

// Check if the user is logged in (using session started in db_config.php)
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    // Differentiate response for AJAX vs direct access
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        header('Content-Type: application/json');
        http_response_code(401); // Unauthorized
        echo json_encode(['success' => false, 'message' => 'Unauthorized access. Please login again.']);
        exit;
    } else {
        header("location: login.php"); // Redirect non-AJAX requests
        exit;
    }
}

// Get user ID
$user_id = $_SESSION["id"];

// --- Helper Functions ---

// Gets company details including stamp path
function getCompanyDetails($conn, $user_id) {
    $sql = "SELECT * FROM companies WHERE user_id = :user_id LIMIT 1";
    $result = query($conn, $sql, ['user_id' => $user_id]);
    if ($result && fetch_count($conn, $result) > 0) {
        return fetch_one($result);
    }
    return null;
}

// Generates the next sequential invoice number based on month/year prefix
/*function generateNextInvoiceNumber($conn, $user_id) {
    $year = date('Y');
    $month = date('m');
    $prefix = "INV-" . $year . $month . "-";

    $sql = "SELECT invoice_number FROM invoices WHERE user_id = :user_id AND invoice_number LIKE :prefix ORDER BY invoice_number DESC LIMIT 1";
    $result = query($conn, $sql, ['user_id' => $user_id, 'prefix' => $prefix . '%']);
    $nextNumber = 1;

    if ($result && fetch_count($conn, $result) > 0) {
        $lastInvoice = fetch_one($result);
        // Refined regex to better handle potential leading zeros or different formats
        if (preg_match('/-(\d{4,})$/', $lastInvoice['invoice_number'], $matches)) { // Look for 4 or more digits at the end
             $nextNumber = (int)$matches[1] + 1;
        } elseif (preg_match('/-(\d+)$/', $lastInvoice['invoice_number'], $matches)) { // Fallback for any digits at the end
            $nextNumber = (int)$matches[1] + 1;
        } else {
            // Fallback to counting if regex fails
            error_log("Unexpected invoice format, falling back to count for user $user_id: " . ($lastInvoice['invoice_number'] ?? 'N/A'));
            $sql_count = "SELECT COUNT(*) as count FROM invoices WHERE user_id = :user_id AND invoice_number LIKE :prefix";
            $res_count = query($conn, $sql_count, ['user_id' => $user_id, 'prefix' => $prefix . '%']);
            if($res_count) {
                $count_data = fetch_one($res_count);
                $count = isset($count_data['count']) ? (int)$count_data['count'] : 0;
                $nextNumber = $count + 1;
            } else {
                error_log("Failed to count invoices for fallback number generation. User: $user_id. Error: " . mysqli_error($conn));
                $nextNumber = 1; // Default if count fails
            }
        }
    }
    return $prefix . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);
}*/

// Generates the next sequential invoice number based on Financial Year YY-YY-XXXX format
function generateNextInvoiceNumber($conn, $user_id) {
    // Determine current Indian Financial Year (April 1st to March 31st)
    $current_month = (int)date('n'); // Month number 1-12
    $current_year = (int)date('Y'); // 4-digit year

    if ($current_month >= 4) { // Financial year starts in current year
        $start_yy = date('y'); // Current 2-digit year
        $end_yy = substr((string)($current_year + 1), -2); // Next 2-digit year
    } else { // Financial year started in previous year
        $start_yy = substr((string)($current_year - 1), -2); // Previous 2-digit year
        $end_yy = date('y'); // Current 2-digit year
    }
    // Format: YY-YY- (e.g., 25-26-)
    $fy_prefix = $start_yy . "-" . $end_yy . "-";

    // Find the highest sequence number *for this financial year*
    $sql = "SELECT invoice_number FROM invoices
            WHERE user_id = :user_id AND invoice_number LIKE :prefix
            ORDER BY invoice_number DESC LIMIT 1";

    // Prepare parameters (only user_id and the FY prefix are needed now)
    $params = ['user_id' => $user_id, 'prefix' => $fy_prefix . '%'];

    $result = query($conn, $sql, $params);
    $nextNumber = 1; // Default to 1 for the first invoice of the FY

    if ($result && fetch_count($conn, $result) > 0) {
        $lastInvoice = fetch_one($result);
        // Extract the 4-digit sequence number after the last dash
        // Example: 25-26-0099 -> Match 0099
        if (preg_match('/-(\d{4})$/', $lastInvoice['invoice_number'], $matches)) {
            $nextNumber = (int)$matches[1] + 1;
        } else {
            // Fallback if somehow the format is wrong (e.g., manual entry), count existing for FY
            error_log("Unexpected invoice format for FY prefix '$fy_prefix', falling back to count for user $user_id. Last#: " . ($lastInvoice['invoice_number'] ?? 'N/A'));
            $sql_count = "SELECT COUNT(*) as count FROM invoices WHERE user_id = :user_id AND invoice_number LIKE :prefix";
            $res_count = query($conn, $sql_count, $params); // Reuse params
            if($res_count) {
                $count_data = fetch_one($res_count);
                $nextNumber = isset($count_data['count']) ? (int)$count_data['count'] + 1 : 1;
            } else {
                $nextNumber = 1; // Default if count fails
            }
        }
    }

    // Format the final invoice number with 4-digit padding
    return $fy_prefix . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);
}


// Helper to calculate invoice status - Robust Calculation
function calculateInvoiceStatus($total_amount, $advance_paid) {
    $tolerance = 0.01; // Tolerance for floating point comparisons
    // Ensure values are numeric, default to 0 if not
    $total_amount_float = is_numeric($total_amount) ? (float)$total_amount : 0.0;
    $advance_paid_float = is_numeric($advance_paid) ? (float)$advance_paid : 0.0;

    $total = round($total_amount_float, 2);
    $paid = round($advance_paid_float, 2);

    // If total is zero or negative, consider it paid (or settled/not applicable)
    if ($total <= $tolerance) {
        return 'paid';
    }
    // If amount paid is essentially equal to the total
    elseif (abs($total - $paid) < $tolerance) {
        return 'paid';
    }
    // If *some* amount has been paid, but less than the total
    elseif ($paid > $tolerance && $paid < $total) {
        return 'partially_paid';
    }
    // Otherwise (paid amount is zero or negative - default to unpaid)
    // Note: Handled cases where paid might technically exceed total (e.g., refund scenario?), defaulting to unpaid unless specifically handled.
    else {
        return 'unpaid';
    }
}


// --- Main Request Handling ---
$action = $_REQUEST['action'] ?? null;

if ($action) {
    header('Content-Type: application/json');
    switch ($action) {
        // Client actions
        case 'save_client': saveClient(); break;
        case 'get_client': getClient(); break;
        case 'get_clients': getClients(); break; // Modified for address search
        case 'delete_client': deleteClient(); break;

        // Invoice actions
        case 'save_invoice': saveInvoice(); break;          // Modified for bank_account_id & status saving
        case 'get_invoice': getInvoice(); break;            // Modified for bank_account_id & status return
        case 'delete_invoice': deleteInvoice(); break;
        case 'preview_invoice': previewInvoice(); break;    // Modified for bank_account_id & status display
        // case 'download_pdf': downloadPdf(); break;       // Not implemented yet

        // *** BANK ACTIONS (Set Default Removed) ***
        case 'get_banks': getBanks(); break;
        case 'save_bank': saveBank(); break;
        case 'delete_bank': deleteBank(); break;
        // REMOVED: case 'set_default_bank': setDefaultBank(); break;
        // *** END BANK ACTIONS ***

        // *** CLIENT STATUS REPORT ACTIONS ***
        case 'get_client_status_report': getClientStatusReport(); break;
        case 'export_client_status_csv': exportClientStatusReport('csv'); break;
        // *** END CLIENT STATUS REPORT ACTIONS ***

        // Add future actions here...
        case 'build_report': // Placeholder for Query Builder Backend
            http_response_code(501); // Not Implemented
            echo json_encode(['success' => false, 'message' => 'Report builder backend not yet implemented.']);
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid action specified']);
            break;
    }
    exit;
} else {
     header('Content-Type: application/json');
     http_response_code(400);
     echo json_encode(['success' => false, 'message' => 'No action specified']);
     exit;
}

// --- Action Functions ---

// ========= Client Functions (Unchanged from original except getClients) =========
function saveClient() {
    global $conn, $user_id;
    if (empty($_POST['name'])) { http_response_code(400); echo json_encode(['success' => false, 'message' => 'Client name is required']); return; }
    $client_id = isset($_POST['id']) && !empty($_POST['id']) && ctype_digit((string)$_POST['id']) ? (int)$_POST['id'] : null; // More robust ID check
    $name = sanitize($conn, $_POST['name']);
    $address = sanitize($conn, $_POST['address'] ?? null);
    $gstin_raw = trim($_POST['gstin'] ?? '');
    $gstin = !empty($gstin_raw) ? sanitize($conn, $gstin_raw) : null;
    $state = sanitize($conn, $_POST['state'] ?? null);
    $state_code = sanitize($conn, $_POST['state_code'] ?? null);
    $phone = sanitize($conn, $_POST['phone'] ?? null);
    $email_raw = trim($_POST['email'] ?? '');
    $email = !empty($email_raw) ? sanitize_email($email_raw) : null;

    if (!empty($email_raw) && $email === null) { http_response_code(400); echo json_encode(['success' => false, 'message' => 'Invalid email format provided.']); return; }

    $sql = ''; $params = []; $action_type = '';
    try {
        if ($client_id) { // UPDATE
            // Verify ownership before update
            $sql_check_owner = "SELECT id FROM clients WHERE id = :id AND user_id = :user_id";
            $res_check = query($conn, $sql_check_owner, ['id' => $client_id, 'user_id' => $user_id]);
            if (!$res_check || fetch_count($conn, $res_check) === 0) {
                http_response_code(403); // Forbidden
                echo json_encode(['success' => false, 'message' => 'Error: Client not found or access denied.']);
                return;
            }

            $sql = "UPDATE clients SET name = :name, address = :address, gstin = :gstin, state = :state, state_code = :state_code, phone = :phone, email = :email WHERE id = :id AND user_id = :user_id";
            $params = ['name' => $name, 'address' => $address, 'gstin' => $gstin, 'state' => $state, 'state_code' => $state_code, 'phone' => $phone, 'email' => $email, 'id' => $client_id, 'user_id' => $user_id];
            $action_type = 'updated';
        } else { // INSERT
             $sql = "INSERT INTO clients (user_id, name, address, gstin, state, state_code, phone, email) VALUES (:user_id, :name, :address, :gstin, :state, :state_code, :phone, :email)";
             $params = ['user_id' => $user_id, 'name' => $name, 'address' => $address, 'gstin' => $gstin, 'state' => $state, 'state_code' => $state_code, 'phone' => $phone, 'email' => $email];
             $action_type = 'added';
        }

        $result = query($conn, $sql, $params);
        if ($result) {
            $current_client_id = $client_id ?: last_id($conn);
             // Fetch the saved/updated client data to return it
             $sql_get = "SELECT * FROM clients WHERE id = :id AND user_id = :user_id";
            $result_get = query($conn, $sql_get, ['id' => $current_client_id, 'user_id' => $user_id]);
             if ($result_get && fetch_count($conn, $result_get) > 0) {
                echo json_encode(['success' => true, 'message' => "Client {$action_type} successfully.", 'client' => fetch_one($result_get)]);
            } else {
                 error_log("Client save ($action_type) OK, but failed retrieve client ID: $current_client_id user: $user_id");
                 // Provide fallback success message even if retrieve fails, crucial for UI update
                 echo json_encode(['success' => true, 'message' => "Client {$action_type} successfully (details might need refresh).", 'client_id' => $current_client_id]); // Return ID even if fetch fails
            }
        } else {
             http_response_code(500);
             $db_error = mysqli_error($conn);
             error_log("Database error during client {$action_type} for user $user_id: " . $db_error . " | SQL: " . $sql); // Log SQL for easier debug
             echo json_encode(['success' => false, 'message' => "Database error during client {$action_type}. Please check logs or contact support."]);
        }
    } catch (Exception $e) {
        http_response_code(500);
        error_log("!! Exception in saveClient !! user $user_id: " . $e->getMessage() . "\nTrace: " . $e->getTraceAsString());
        echo json_encode(['success' => false, 'message' => 'An unexpected server error occurred: ' . $e->getMessage()]);
    }
}

function getClient() {
    global $conn, $user_id;
    $client_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if (!$client_id) { http_response_code(400); echo json_encode(['success' => false, 'message' => 'Invalid client ID provided.']); return; }

    $sql = "SELECT * FROM clients WHERE id = :id AND user_id = :user_id";
    $result = query($conn, $sql, ['id' => $client_id, 'user_id' => $user_id]);
    if ($result && fetch_count($conn, $result) > 0) {
        echo json_encode(['success' => true, 'client' => fetch_one($result)]);
    } else {
         http_response_code(404);
         echo json_encode(['success' => false, 'message' => 'Client not found or access denied.']);
    }
}

/**
 * Get Clients with Pagination and Search (including Address).
 */
function getClients() {
    global $conn, $user_id;
    $search = isset($_GET['search']) ? sanitize($conn, $_GET['search']) : '';
    $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
    $limit = isset($_GET['limit']) ? max(1, (int)$_GET['limit']) : 10; // Default pagination limit
    $offset = ($page - 1) * $limit;

    $sql_select = "SELECT id, name, gstin, state, state_code, address, email, phone FROM clients";
    $sql_where = " WHERE user_id = :user_id";
    $sql_order = " ORDER BY name ASC"; // Or ID DESC, etc.
    $sql_limit = " LIMIT :limit OFFSET :offset";

    $params = ['user_id' => $user_id]; // Base parameters for data query
    $count_params = ['user_id' => $user_id]; // Base parameters for count query

    // Apply search term if provided
    if (!empty($search)) {
        $search_term = '%' . $search . '%'; // Prepare for LIKE search

        // Build the search condition across multiple fields, including address
        $search_condition = "(name LIKE :search_name OR gstin LIKE :search_gstin OR email LIKE :search_email OR phone LIKE :search_phone OR address LIKE :search_address)";

        // Define parameters for the search condition (ensure unique keys)
        $search_params = [
            'search_name' => $search_term,
            'search_gstin' => $search_term,
            'search_email' => $search_term,
            'search_phone' => $search_term,
            'search_address' => $search_term // Added address parameter
        ];

        // Append search condition to WHERE clauses
        $sql_where .= " AND " . $search_condition;

        // Merge search parameters into the main parameter arrays
        $params = array_merge($params, $search_params);
        $count_params = array_merge($count_params, $search_params);

        // --- Alternative for FULLTEXT Search (if FT index exists on 'address') ---
        // $search_condition = "(name LIKE :search_name OR gstin LIKE :search_gstin OR email LIKE :search_email OR phone LIKE :search_phone OR MATCH(address) AGAINST (:search_address IN BOOLEAN MODE))";
        // $search_params = [ ... // other LIKE params ... 'search_address' => $search . '*']; // Use appropriate FT search mode/syntax
        // ... merge params ...
        // --- End Alternative ---
    }

    // **IMPORTANT**: Add LIMIT/OFFSET params *after* potentially merging search params
    $params['limit'] = $limit;
    $params['offset'] = $offset;

    // Fetch total count matching the criteria (without limit/offset)
    $sql_count = "SELECT COUNT(*) as total FROM clients" . $sql_where;
    $total_clients = 0;
    try {
        $result_count = query($conn, $sql_count, $count_params);
        if ($result_count) {
            $count_data = fetch_one($result_count);
            $total_clients = isset($count_data['total']) ? (int)$count_data['total'] : 0;
        } else {
            error_log("Error fetching client count for user $user_id with search '$search': " . mysqli_error($conn));
        }
    } catch (Exception $e) {
        error_log("Exception fetching client count for user $user_id with search '$search': " . $e->getMessage());
    }

    // Fetch paginated data
    $sql_data = $sql_select . $sql_where . $sql_order . $sql_limit;
    $clients = [];
    try {
        $result_data = query($conn, $sql_data, $params);
        if ($result_data) {
            $clients = fetch_all($result_data);
            // Send back data, total count for pagination, and current page/limit for reference
            echo json_encode([
                'success' => true,
                'clients' => $clients,
                'total_clients' => $total_clients,
                'page' => $page,
                'limit' => $limit
            ]);
        } else {
             error_log("Error fetching paginated clients list for user $user_id: " . mysqli_error($conn));
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Failed to fetch clients list due to a database error.']);
        }
    } catch (Exception $e) {
        error_log("Exception fetching paginated clients list for user $user_id: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'An unexpected server error occurred while fetching clients: ' . $e->getMessage()]);
    }
}


function deleteClient() {
    global $conn, $user_id;
    // Allow ID from POST or GET for flexibility
    $client_id = isset($_POST['id']) ? (int)$_POST['id'] : (isset($_GET['id']) ? (int)$_GET['id'] : 0);
    if (!$client_id) { http_response_code(400); echo json_encode(['success' => false, 'message' => 'Invalid client ID specified.']); return; }

     // 1. Verify Ownership
     $sql_check_owner = "SELECT id FROM clients WHERE id = :id AND user_id = :user_id";
     $res_check_owner = query($conn, $sql_check_owner, ['id' => $client_id, 'user_id' => $user_id]);
     if (!$res_check_owner || fetch_count($conn, $res_check_owner) === 0) {
         http_response_code(403); // Forbidden
         echo json_encode(['success' => false, 'message' => 'Error: Client not found or access denied.']); return;
     }

    // 2. Check for Linked Invoices (prevent deletion if linked)
    $sql_check_invoices = "SELECT COUNT(*) as count FROM invoices WHERE client_id = :client_id AND user_id = :user_id";
    $result_check = query($conn, $sql_check_invoices, ['client_id' => $client_id, 'user_id' => $user_id]);
    if ($result_check) {
        $invoice_count_data = fetch_one($result_check);
        $invoice_count = isset($invoice_count_data['count']) ? (int)$invoice_count_data['count'] : 0;
        if ($invoice_count > 0) {
            http_response_code(409); // Conflict
            echo json_encode(['success' => false, 'message' => 'Cannot delete client. This client has '.$invoice_count.' invoice(s) linked.']); return;
        }
    } else {
        // Log error but proceed with caution? Or block deletion? Blocking is safer.
        error_log("Failed to check for invoices before deleting client $client_id for user $user_id: " . mysqli_error($conn));
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Database error checking for linked invoices before deletion. Please try again.']); return;
    }

    // 3. Perform Deletion (only if checks pass)
    $sql_delete = "DELETE FROM clients WHERE id = :id AND user_id = :user_id";
    $result_delete = query($conn, $sql_delete, ['id' => $client_id, 'user_id' => $user_id]);

    if ($result_delete && mysqli_affected_rows($conn) > 0) {
        echo json_encode(['success' => true, 'message' => 'Client deleted successfully.']);
    } elseif ($result_delete) { // Query succeeded but 0 rows affected (shouldn't happen after owner check)
        http_response_code(404); echo json_encode(['success' => false, 'message' => 'Client not found or already deleted (unexpected).']);
    } else { // Query failed
        error_log("Failed to delete client $client_id for user $user_id: " . mysqli_error($conn));
        http_response_code(500); echo json_encode(['success' => false, 'message' => 'Failed to delete client due to a database error.']);
    }
}
// ========= END Client Functions =========


// ========= Invoice Functions (MODIFIED FOR BANK ID) =========
/**
 * Saves or Updates an Invoice.
 * Handles invoice items and calculates totals server-side.
 * NOW INCLUDES 'bank_account_id' selection.
 */
/*function saveInvoice() {
    global $conn, $user_id;

    // --- Basic Input Validation ---
    $invoice_id_from_post = isset($_POST['invoice_id']) && ctype_digit((string)$_POST['invoice_id']) && (int)$_POST['invoice_id'] > 0 ? (int)$_POST['invoice_id'] : null;
    $is_update = !is_null($invoice_id_from_post);

    $required_fields = ['invoice_date', 'client_id'];
    $missing_fields = [];
    foreach($required_fields as $field) { if (empty($_POST[$field])) { $missing_fields[] = $field; } }
    if (!isset($_POST['client_id']) || !filter_var($_POST['client_id'], FILTER_VALIDATE_INT)) { $missing_fields[] = 'valid client ID'; }
    if (!isset($_POST['description']) || !is_array($_POST['description']) || count($_POST['description']) === 0) { $missing_fields[] = 'invoice items'; }
    if ($is_update && !$invoice_id_from_post) { $missing_fields[] = 'invoice ID for update'; }

    if (!empty($missing_fields)) {
        http_response_code(400); echo json_encode(['success' => false, 'message' => 'Missing required invoice data: ' . implode(', ', array_unique($missing_fields))]); return;
    }

    // Validate item descriptions (at least one must be non-empty)
    $valid_item_found = false;
    if (is_array($_POST['description'])) {
        foreach ($_POST['description'] as $desc) { if (!empty(trim($desc))) { $valid_item_found = true; break; } }
    }
    if (!$valid_item_found) { http_response_code(400); echo json_encode(['success' => false, 'message' => 'Invoice must contain at least one item with a description.']); return; }

    // --- Start Transaction ---
    begin_transaction($conn);
    try {
        // --- Collect & Sanitize Basic Invoice Data ---
        $invoice_date = sanitize($conn, $_POST['invoice_date']);
        $client_id = (int)$_POST['client_id'];
        $due_date = !empty($_POST['due_date']) ? sanitize($conn, $_POST['due_date']) : null;
        $hsn_code = !empty(trim($_POST['hsn_code'] ?? '')) ? sanitize($conn, trim($_POST['hsn_code'])) : null;
        $po_number = !empty(trim($_POST['po_number'] ?? '')) ? sanitize($conn, trim($_POST['po_number'])) : null;
        $cgst_rate = isset($_POST['cgst_rate']) && is_numeric($_POST['cgst_rate']) ? (float)$_POST['cgst_rate'] : 0.0;
        $sgst_rate = isset($_POST['sgst_rate']) && is_numeric($_POST['sgst_rate']) ? (float)$_POST['sgst_rate'] : 0.0;
        $convenience_fee = isset($_POST['convenience_fee']) && is_numeric($_POST['convenience_fee']) ? round((float)$_POST['convenience_fee'], 2) : 0.0;
        $advance_paid = isset($_POST['advance_paid']) && is_numeric($_POST['advance_paid']) ? round((float)$_POST['advance_paid'], 2) : 0.0;
        $notes = !empty(trim($_POST['notes'] ?? '')) ? sanitize($conn, $_POST['notes']) : null;

        // *** NEW: Get selected Bank Account ID ***
        $bank_account_id = isset($_POST['bank_account_id']) && ctype_digit((string)$_POST['bank_account_id']) && (int)$_POST['bank_account_id'] > 0
                           ? (int)$_POST['bank_account_id']
                           : null; // Store as null if empty, not selected, or invalid

        // --- Server-side Recalculation of Items and Totals (Crucial for data integrity) ---
        $calculated_subtotal = 0; $item_count = 0; $invoice_items_data = [];
        if (isset($_POST['description'], $_POST['quantity'], $_POST['rate']) &&
            is_array($_POST['description']) && is_array($_POST['quantity']) && is_array($_POST['rate']) &&
            count($_POST['description']) === count($_POST['quantity']) && count($_POST['description']) === count($_POST['rate']))
        {
            for ($i = 0; $i < count($_POST['description']); $i++) {
                $description_item = trim($_POST['description'][$i]);
                if (!empty($description_item)) {
                    $qty_raw = $_POST['quantity'][$i] ?? 0; $rate_raw = $_POST['rate'][$i] ?? 0;
                    $qty = is_numeric($qty_raw) ? (float)$qty_raw : 0; $rate = is_numeric($rate_raw) ? (float)$rate_raw : 0;

                    if ($qty < 0 || $rate < 0) { throw new Exception("Quantity and Rate cannot be negative for item: '" . htmlspecialchars($description_item, ENT_QUOTES, 'UTF-8') . "'. Please correct and try again."); }

                    $amount = round($qty * $rate, 2); $calculated_subtotal += $amount; $item_count++;

                    $invoice_items_data[] = ['description' => sanitize($conn, $description_item), 'quantity' => $qty, 'rate' => $rate, 'amount' => $amount];
                }
            }
        }
        if ($item_count === 0) { throw new Exception("No valid invoice items were provided after filtering empty rows."); }

        $calculated_subtotal = round($calculated_subtotal, 2);
        $calculated_cgst_amount = round(($calculated_subtotal * $cgst_rate) / 100, 2);
        $calculated_sgst_amount = round(($calculated_subtotal * $sgst_rate) / 100, 2);
        $convenience_fee = max(0, $convenience_fee);
        $calculated_total_amount = round($calculated_subtotal + $calculated_cgst_amount + $calculated_sgst_amount + $convenience_fee, 2);

        // --- Determine Final Status ---
        $allowed_statuses = ['paid', 'unpaid', 'partially_paid'];
        $final_status = 'unpaid';
        if (isset($_POST['status']) && in_array($_POST['status'], $allowed_statuses)) { $final_status = sanitize($conn, $_POST['status']); }
        else { $final_status = calculateInvoiceStatus($calculated_total_amount, $advance_paid); }

        // --- Verify Ownership & Client Existence ---
        $sql_check_client = "SELECT id FROM clients WHERE id = :client_id AND user_id = :user_id";
        $res_check_client = query($conn, $sql_check_client, ['client_id' => $client_id, 'user_id' => $user_id]);
        if (!$res_check_client || fetch_count($conn, $res_check_client) === 0) { throw new Exception("Selected client not found or access denied."); }

        // *** NEW: Verify ownership of selected Bank Account ID if provided ***
        if ($bank_account_id !== null) {
            $sql_check_bank = "SELECT id FROM user_banks WHERE id = :bank_id AND user_id = :user_id";
            $res_check_bank = query($conn, $sql_check_bank, ['bank_id' => $bank_account_id, 'user_id' => $user_id]);
            if (!$res_check_bank || fetch_count($conn, $res_check_bank) === 0) {
                 throw new Exception("Selected bank account not found or access denied.");
             }
         }
         // --- End Bank Verification ---

        // --- Prepare SQL and Parameters for Invoice Table ---
        $invoice_id_to_use = null;
        $invoice_number = null;

        if ($is_update) { // ----- UPDATE existing invoice -----
            $sql_check_invoice_owner = "SELECT id, invoice_number FROM invoices WHERE id = :id AND user_id = :user_id";
            $result_check_invoice = query($conn, $sql_check_invoice_owner, ['id' => $invoice_id_from_post, 'user_id' => $user_id]);
            if (!$result_check_invoice || fetch_count($conn, $result_check_invoice) === 0) { throw new Exception("Invoice not found or access denied for update."); }
             $existing_invoice_data = fetch_one($result_check_invoice);
             $invoice_id_to_use = $existing_invoice_data['id'];
             $invoice_number = $existing_invoice_data['invoice_number'];

            $sql_invoice = "UPDATE invoices SET
                            invoice_date = :invoice_date, client_id = :client_id, due_date = :due_date,
                            hsn_code = :hsn_code, po_number = :po_number,
                            cgst_rate = :cgst_rate, sgst_rate = :sgst_rate, convenience_fee = :convenience_fee, advance_paid = :advance_paid,
                            subtotal = :subtotal, cgst_amount = :cgst_amount, sgst_amount = :sgst_amount, total_amount = :total_amount,
                            notes = :notes,
                            status = :status,
                            bank_account_id = :bank_account_id -- Include bank_account_id
                           WHERE id = :id AND user_id = :user_id";
            $params_invoice = [
                'invoice_date' => $invoice_date, 'client_id' => $client_id, 'due_date' => $due_date, 'hsn_code' => $hsn_code, 'po_number' => $po_number,
                'cgst_rate' => $cgst_rate, 'sgst_rate' => $sgst_rate, 'convenience_fee' => $convenience_fee, 'advance_paid' => $advance_paid,
                'subtotal' => $calculated_subtotal, 'cgst_amount' => $calculated_cgst_amount, 'sgst_amount' => $calculated_sgst_amount, 'total_amount' => $calculated_total_amount,
                'notes' => $notes,
                'status' => $final_status,
                'bank_account_id' => $bank_account_id, // Pass bank ID
                'id' => $invoice_id_to_use,
                'user_id' => $user_id
            ];
            $action_type = 'updated';

        } else { // ----- INSERT new invoice -----
            $invoice_number = generateNextInvoiceNumber($conn, $user_id);

            $sql_invoice = "INSERT INTO invoices (user_id, client_id, invoice_number, invoice_date, due_date, hsn_code, po_number, cgst_rate, sgst_rate, convenience_fee, advance_paid, subtotal, cgst_amount, sgst_amount, total_amount, notes, status, bank_account_id) -- Add bank_account_id column
                           VALUES (:user_id, :client_id, :invoice_number, :invoice_date, :due_date, :hsn_code, :po_number, :cgst_rate, :sgst_rate, :convenience_fee, :advance_paid, :subtotal, :cgst_amount, :sgst_amount, :total_amount, :notes, :status, :bank_account_id)"; // Add placeholder
            $params_invoice = [
                'user_id' => $user_id, 'client_id' => $client_id, 'invoice_number' => $invoice_number, 'invoice_date' => $invoice_date, 'due_date' => $due_date, 'hsn_code' => $hsn_code, 'po_number' => $po_number,
                'cgst_rate' => $cgst_rate, 'sgst_rate' => $sgst_rate, 'convenience_fee' => $convenience_fee, 'advance_paid' => $advance_paid,
                'subtotal' => $calculated_subtotal, 'cgst_amount' => $calculated_cgst_amount, 'sgst_amount' => $calculated_sgst_amount, 'total_amount' => $calculated_total_amount,
                'notes' => $notes,
                'status' => $final_status,
                'bank_account_id' => $bank_account_id // Pass bank ID
            ];
            $action_type = 'created';
        }

        // --- Execute Invoice Save/Update ---
        $result_invoice = query($conn, $sql_invoice, $params_invoice);
        if (!$result_invoice) {
            if (mysqli_errno($conn) == 1062 && !$is_update && strpos(mysqli_error($conn), 'invoice_number') !== false) {
                 error_log("Duplicate invoice number error for user $user_id. Generated: $invoice_number. DB Error: " . mysqli_error($conn));
                 throw new Exception("Error: Invoice number '{$invoice_number}' might already exist. Please try creating the invoice again.");
             } else { throw new Exception("Database error saving invoice record. Error: " . mysqli_error($conn)); }
        }
        $current_invoice_id = $is_update ? $invoice_id_to_use : last_id($conn);
        if (!$current_invoice_id) { throw new Exception("Failed to retrieve invoice ID after saving."); }

        // --- Manage Invoice Items (Delete old only on UPDATE, then insert new) ---
        if ($is_update) {
            $sql_delete_items = "DELETE FROM invoice_items WHERE invoice_id = :invoice_id";
            if (!query($conn, $sql_delete_items, ['invoice_id' => $current_invoice_id])) {
                 error_log("Error deleting old items for invoice update. Invoice ID: $current_invoice_id. Error: " . mysqli_error($conn));
                 throw new Exception("Failed to clear old invoice items during update. Please try again.");
            }
        }

        // Insert all items
        $sql_item = "INSERT INTO invoice_items (invoice_id, description, quantity, rate, amount) VALUES (:invoice_id, :description, :quantity, :rate, :amount)";
        foreach ($invoice_items_data as $item_data) {
             $params_item = ['invoice_id' => $current_invoice_id] + $item_data;
             if (!query($conn, $sql_item, $params_item)) {
                 error_log("Failed to save invoice item. Invoice ID: $current_invoice_id. Desc: {$item_data['description']}. Error: " . mysqli_error($conn));
                throw new Exception("Failed to save invoice item: '" . htmlspecialchars($item_data['description'], ENT_QUOTES, 'UTF-8') . "'. Database error occurred.");
            }
        }

        // --- Final Steps ---
        commit_transaction($conn);

        echo json_encode(['success' => true, 'message' => "Invoice {$action_type} successfully.", 'invoice_id' => $current_invoice_id, 'invoice_number' => $invoice_number]);

    } catch (Exception $e) {
        rollback_transaction($conn);
        error_log("!!! Exception in saveInvoice !!! user $user_id: " . $e->getMessage() . "\nTrace: " . $e->getTraceAsString());
        http_response_code(($e->getCode() >= 400 && $e->getCode() < 500) ? $e->getCode() : 400);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}*/

function saveInvoice() {
    global $conn, $user_id;

    // --- Basic Input Validation (mostly unchanged) ---
    $invoice_id_from_post = isset($_POST['invoice_id']) && ctype_digit((string)$_POST['invoice_id']) && (int)$_POST['invoice_id'] > 0 ? (int)$_POST['invoice_id'] : null;
    $is_update = !is_null($invoice_id_from_post);

    $required_fields = ['invoice_date', 'client_id'];
    $missing_fields = [];
    foreach($required_fields as $field) { if (empty($_POST[$field])) { $missing_fields[] = $field; } }
    if (!isset($_POST['client_id']) || !filter_var($_POST['client_id'], FILTER_VALIDATE_INT)) { $missing_fields[] = 'valid client ID'; }
    if (!isset($_POST['description']) || !is_array($_POST['description']) || count($_POST['description']) === 0) { $missing_fields[] = 'invoice items'; }
    if ($is_update && !$invoice_id_from_post) { $missing_fields[] = 'invoice ID for update'; }

    if (!empty($missing_fields)) {
        http_response_code(400); echo json_encode(['success' => false, 'message' => 'Missing required invoice data: ' . implode(', ', array_unique($missing_fields))]); return;
    }

    $valid_item_found = false;
    if (is_array($_POST['description'])) {
        foreach ($_POST['description'] as $desc) { if (!empty(trim($desc))) { $valid_item_found = true; break; } }
    }
    if (!$valid_item_found) { http_response_code(400); echo json_encode(['success' => false, 'message' => 'Invoice must contain at least one item with a description.']); return; }

    // --- Start Transaction ---
    begin_transaction($conn);
    try {
        // --- Collect & Sanitize Basic Invoice Data ---
        $invoice_date = sanitize($conn, $_POST['invoice_date']);
        $client_id = (int)$_POST['client_id'];
        $due_date = !empty($_POST['due_date']) ? sanitize($conn, $_POST['due_date']) : null;
        $hsn_code = !empty(trim($_POST['hsn_code'] ?? '')) ? sanitize($conn, trim($_POST['hsn_code'])) : null;
        $po_number = !empty(trim($_POST['po_number'] ?? '')) ? sanitize($conn, trim($_POST['po_number'])) : null;

        // *** Get Discount Rate ***
        $discount_rate_raw = $_POST['discount_rate'] ?? 0.00;
        $discount_rate = 0.00;
        if (is_numeric($discount_rate_raw)) {
            $discount_rate = max(0, min(100, (float)$discount_rate_raw)); // Clamp 0-100
        }
        // --- End Discount Rate ---

        $cgst_rate = isset($_POST['cgst_rate']) && is_numeric($_POST['cgst_rate']) ? max(0, (float)$_POST['cgst_rate']) : 0.0; // Ensure non-negative
        $sgst_rate = isset($_POST['sgst_rate']) && is_numeric($_POST['sgst_rate']) ? max(0, (float)$_POST['sgst_rate']) : 0.0; // Ensure non-negative
        $convenience_fee = isset($_POST['convenience_fee']) && is_numeric($_POST['convenience_fee']) ? round(max(0,(float)$_POST['convenience_fee']), 2) : 0.0; // Ensure non-negative
        $advance_paid = isset($_POST['advance_paid']) && is_numeric($_POST['advance_paid']) ? round(max(0,(float)$_POST['advance_paid']), 2) : 0.0; // Ensure non-negative
        $notes = !empty(trim($_POST['notes'] ?? '')) ? sanitize($conn, $_POST['notes']) : null;

        // Get selected Bank Account ID (Keep existing logic)
        $bank_account_id = isset($_POST['bank_account_id']) && ctype_digit((string)$_POST['bank_account_id']) && (int)$_POST['bank_account_id'] > 0
                           ? (int)$_POST['bank_account_id'] : null;

        // --- Server-side Recalculation (Including Discount) ---
        $calculated_subtotal = 0; $item_count = 0; $invoice_items_data = [];
        if (isset($_POST['description'], $_POST['quantity'], $_POST['rate']) && /* rest of check */ is_array($_POST['description']) && is_array($_POST['quantity']) && is_array($_POST['rate']) && count($_POST['description']) === count($_POST['quantity']))
        {
            for ($i = 0; $i < count($_POST['description']); $i++) {
                $description_item = trim($_POST['description'][$i]);
                if (!empty($description_item)) {
                    $qty_raw = $_POST['quantity'][$i] ?? 0; $rate_raw = $_POST['rate'][$i] ?? 0;
                    $qty = is_numeric($qty_raw) ? max(0,(float)$qty_raw) : 0;
                    $rate = is_numeric($rate_raw) ? max(0,(float)$rate_raw) : 0;

                    // Note: Removed exception throwing here as validation can happen earlier
                    // Keep only if strictly needed to halt on negative inputs

                    $amount = round($qty * $rate, 2);
                    $calculated_subtotal += $amount;
                    $item_count++;
                    $invoice_items_data[] = [
                        'description' => sanitize($conn, $description_item), 'quantity' => $qty,
                        'rate' => $rate, 'amount' => $amount
                    ];
                }
            }
        }
        if ($item_count === 0) { throw new Exception("No valid invoice items provided."); }

        $calculated_subtotal = round($calculated_subtotal, 2);

        // *** Apply Discount ***
        $calculated_discount_amount = round(($calculated_subtotal * $discount_rate) / 100, 2);
        $taxable_amount = round($calculated_subtotal - $calculated_discount_amount, 2);

        // Calculate taxes on the taxable amount
        $calculated_cgst_amount = round(($taxable_amount * $cgst_rate) / 100, 2);
        $calculated_sgst_amount = round(($taxable_amount * $sgst_rate) / 100, 2);

        // Calculate final total amount
        $calculated_total_amount = round($taxable_amount + $calculated_cgst_amount + $calculated_sgst_amount + $convenience_fee, 2);

        // --- Determine Final Status ---
        $final_status = calculateInvoiceStatus($calculated_total_amount, $advance_paid); // Use updated total
        // Override with submitted status if valid
        $allowed_statuses = ['paid', 'unpaid', 'partially_paid'];
        if (isset($_POST['status']) && in_array(strtolower(trim($_POST['status'])), $allowed_statuses)) {
           $final_status = sanitize($conn, strtolower(trim($_POST['status'])));
        }

        // --- Verify Client & Bank Account ---
        $sql_check_client = "SELECT id FROM clients WHERE id = :client_id AND user_id = :user_id";
        $res_check_client = query($conn, $sql_check_client, ['client_id' => $client_id, 'user_id' => $user_id]);
        if (!$res_check_client || fetch_count($conn, $res_check_client) === 0) { throw new Exception("Selected client not found or access denied."); }

        if ($bank_account_id !== null) { // Verify Bank if selected
            $sql_check_bank = "SELECT id FROM user_banks WHERE id = :bank_id AND user_id = :user_id";
            $res_check_bank = query($conn, $sql_check_bank, ['bank_id' => $bank_account_id, 'user_id' => $user_id]);
            if (!$res_check_bank || fetch_count($conn, $res_check_bank) === 0) {
                throw new Exception("Selected bank account not found or access denied.");
            }
        }

        // --- Prepare SQL for INSERT/UPDATE ---
        $invoice_id_to_use = null; $invoice_number = null; $action_type = '';

        if ($is_update) { // ----- UPDATE -----
            $sql_check_invoice_owner = "SELECT id, invoice_number FROM invoices WHERE id = :id AND user_id = :user_id";
            // ... (Check ownership, get existing number - same as your provided code) ...
             $result_check_invoice = query($conn, $sql_check_invoice_owner, ['id' => $invoice_id_from_post, 'user_id' => $user_id]);
             if (!$result_check_invoice || fetch_count($conn, $result_check_invoice) === 0) { throw new Exception("Invoice not found or access denied for update."); }
             $existing_invoice_data = fetch_one($result_check_invoice);
             $invoice_id_to_use = $existing_invoice_data['id'];
             $invoice_number = $existing_invoice_data['invoice_number'];

            $sql_invoice = "UPDATE invoices SET
                            invoice_date = :invoice_date, client_id = :client_id, due_date = :due_date,
                            hsn_code = :hsn_code, po_number = :po_number,
                            discount_rate = :discount_rate,         /* ADDED */
                            discount_amount = :discount_amount,     /* ADDED */
                            cgst_rate = :cgst_rate, sgst_rate = :sgst_rate, convenience_fee = :convenience_fee, advance_paid = :advance_paid,
                            subtotal = :subtotal, cgst_amount = :cgst_amount, sgst_amount = :sgst_amount, total_amount = :total_amount,
                            notes = :notes, status = :status, bank_account_id = :bank_account_id
                           WHERE id = :id AND user_id = :user_id";
            $params_invoice = [
                'invoice_date' => $invoice_date, 'client_id' => $client_id, 'due_date' => $due_date, 'hsn_code' => $hsn_code, 'po_number' => $po_number,
                'discount_rate' => $discount_rate,         /* ADDED */
                'discount_amount' => $calculated_discount_amount, /* ADDED */
                'cgst_rate' => $cgst_rate, 'sgst_rate' => $sgst_rate, 'convenience_fee' => $convenience_fee, 'advance_paid' => $advance_paid,
                'subtotal' => $calculated_subtotal, // Original item sum
                'cgst_amount' => $calculated_cgst_amount, // Calculated on taxable amount
                'sgst_amount' => $calculated_sgst_amount, // Calculated on taxable amount
                'total_amount' => $calculated_total_amount, // Final total after discount/tax
                'notes' => $notes, 'status' => $final_status, 'bank_account_id' => $bank_account_id,
                'id' => $invoice_id_to_use, 'user_id' => $user_id
            ];
            $action_type = 'updated';

        } else { // ----- INSERT -----
            $invoice_number = generateNextInvoiceNumber($conn, $user_id); // Get next number (FY logic if implemented)

            $sql_invoice = "INSERT INTO invoices (
                                user_id, client_id, invoice_number, invoice_date, due_date, hsn_code, po_number,
                                discount_rate, discount_amount,    /* ADDED */
                                cgst_rate, sgst_rate, convenience_fee, advance_paid,
                                subtotal, cgst_amount, sgst_amount, total_amount,
                                notes, status, bank_account_id
                           ) VALUES (
                                :user_id, :client_id, :invoice_number, :invoice_date, :due_date, :hsn_code, :po_number,
                                :discount_rate, :discount_amount,  /* ADDED */
                                :cgst_rate, :sgst_rate, :convenience_fee, :advance_paid,
                                :subtotal, :cgst_amount, :sgst_amount, :total_amount,
                                :notes, :status, :bank_account_id
                           )";
            $params_invoice = [
                'user_id' => $user_id, 'client_id' => $client_id, 'invoice_number' => $invoice_number, 'invoice_date' => $invoice_date, 'due_date' => $due_date, 'hsn_code' => $hsn_code, 'po_number' => $po_number,
                'discount_rate' => $discount_rate,         /* ADDED */
                'discount_amount' => $calculated_discount_amount, /* ADDED */
                'cgst_rate' => $cgst_rate, 'sgst_rate' => $sgst_rate, 'convenience_fee' => $convenience_fee, 'advance_paid' => $advance_paid,
                'subtotal' => $calculated_subtotal,
                'cgst_amount' => $calculated_cgst_amount,
                'sgst_amount' => $calculated_sgst_amount,
                'total_amount' => $calculated_total_amount,
                'notes' => $notes, 'status' => $final_status, 'bank_account_id' => $bank_account_id
            ];
            $action_type = 'created';
        }

        // --- Execute Invoice Save/Update ---
        $result_invoice = query($conn, $sql_invoice, $params_invoice);
        if (!$result_invoice) { /* ... Existing error handling ... */
             if (mysqli_errno($conn) == 1062 && !$is_update && strpos(mysqli_error($conn), 'invoice_number') !== false) {
                throw new Exception("Error: Invoice number '{$invoice_number}' might already exist.");
            } else { throw new Exception("Database error saving invoice record. Error: " . mysqli_error($conn)); }
         }
        $current_invoice_id = $is_update ? $invoice_id_to_use : last_id($conn);
        if (!$current_invoice_id) { throw new Exception("Failed to retrieve invoice ID."); }

        // --- Manage Invoice Items (Delete/Insert - Unchanged) ---
        if ($is_update) {
             $sql_delete_items = "DELETE FROM invoice_items WHERE invoice_id = :invoice_id";
            if (!query($conn, $sql_delete_items, ['invoice_id' => $current_invoice_id])) { /*...*/ }
        }
        $sql_item = "INSERT INTO invoice_items (invoice_id, description, quantity, rate, amount) VALUES (:invoice_id, :description, :quantity, :rate, :amount)";
        foreach ($invoice_items_data as $item_data) {
            $params_item = ['invoice_id' => $current_invoice_id] + $item_data;
            if (!query($conn, $sql_item, $params_item)) { /*...*/ }
        }

        // --- Final Steps ---
        commit_transaction($conn);
        echo json_encode(['success' => true, 'message' => "Invoice {$action_type} successfully.", 'invoice_id' => $current_invoice_id, 'invoice_number' => $invoice_number]);

    } catch (Exception $e) {
        rollback_transaction($conn);
        error_log("!!! Exception in saveInvoice (Discount Logic) !!! user $user_id: " . $e->getMessage()); // Added Discount note to log
        // Determine appropriate status code (check if http_code property exists on Exception object maybe?)
        http_response_code(property_exists($e, 'http_code') && $e->http_code >= 400 ? $e->http_code : 400);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}



function getInvoice() {
    global $conn, $user_id;
    $invoice_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if (!$invoice_id) { http_response_code(400); echo json_encode(['success' => false, 'message' => 'Invalid invoice ID.']); return; }

    $company = getCompanyDetails($conn, $user_id);

    $sql_invoice = "SELECT i.id, i.invoice_number, i.invoice_date, i.due_date, i.hsn_code, i.po_number,
                           i.discount_rate, i.discount_amount,
                           i.cgst_rate, i.sgst_rate, i.convenience_fee, i.advance_paid, i.notes,
                           i.subtotal, i.cgst_amount, i.sgst_amount, i.total_amount, i.status,
                           i.client_id, i.bank_account_id,
                           c.name as client_name, c.address as client_address, c.gstin as client_gstin,
                           c.state as client_state, c.state_code as client_state_code
                    FROM invoices i
                    LEFT JOIN clients c ON i.client_id = c.id
                    WHERE i.id = :id AND i.user_id = :user_id";
    $result_invoice = query($conn, $sql_invoice, ['id' => $invoice_id, 'user_id' => $user_id]);

    if (!$result_invoice || fetch_count($conn, $result_invoice) === 0) {
        http_response_code(404); echo json_encode(['success' => false, 'message' => 'Invoice not found or access denied.']); return;
    }
    $invoice = fetch_one($result_invoice);

    $allowed_statuses = ['paid', 'unpaid', 'partially_paid'];
    $status_from_db = strtolower(trim($invoice['status'] ?? 'unpaid'));

    if (!in_array($status_from_db, $allowed_statuses) || empty($status_from_db)) {
        error_log("Invalid or empty status '{$status_from_db}' for Invoice ID $invoice_id (User $user_id). Recalculating.");
        $invoice['status'] = calculateInvoiceStatus($invoice['total_amount'] ?? 0, $invoice['advance_paid'] ?? 0);
    } else {
        $invoice['status'] = $status_from_db;
    }

    $sql_items = "SELECT * FROM invoice_items WHERE invoice_id = :invoice_id ORDER BY id ASC";
    $result_items = query($conn, $sql_items, ['invoice_id' => $invoice_id]);
    $items = $result_items ? fetch_all($result_items) : [];
    
    $html = generateInvoiceHTML($invoice, $items, $company);

    // ================== START: MODIFICATION FOR FILENAME ==================
    // Create a data object specifically for the filename.
    $fileNameData = [
        'number' => $invoice['invoice_number'],
        'client' => $invoice['client_name'],
        'date' => $invoice['invoice_date']
    ];

    echo json_encode([
        'success' => true,
        'invoice' => $invoice,
        'items' => $items,
        'company' => $company,
        'html' => $html,
        'fileNameData' => $fileNameData // Add the new data to the response
    ]);
    // =================== END: MODIFICATION FOR FILENAME ===================
}

function deleteInvoice() {
     global $conn, $user_id;
     // Allow ID from GET or POST
     $invoice_id = isset($_GET['id']) ? (int)$_GET['id'] : (isset($_POST['id']) ? (int)$_POST['id'] : 0);
     if (!$invoice_id) { http_response_code(400); echo json_encode(['success' => false, 'message' => 'Invalid invoice ID specified.']); return; }

     begin_transaction($conn);
     try {
         // 1. Verify Ownership before proceeding
         $sql_check_invoice = "SELECT id FROM invoices WHERE id = :id AND user_id = :user_id";
         $check_res = query($conn, $sql_check_invoice, ['id' => $invoice_id, 'user_id' => $user_id]);
         if (!$check_res || fetch_count($conn, $check_res) === 0) {
             http_response_code(404); echo json_encode(['success' => false, 'message' => 'Invoice not found or access denied.']);
             // No rollback needed, just exit.
             return;
         }

         // 2. Delete associated items first (within transaction)
         $sql_delete_items = "DELETE FROM invoice_items WHERE invoice_id = :invoice_id";
         if (!query($conn, $sql_delete_items, ['invoice_id' => $invoice_id])) {
            throw new Exception("Failed to delete associated invoice items (DB error: " . mysqli_error($conn) . ")");
         }

         // 3. Delete the invoice itself (ownership already verified)
         $sql_delete_invoice = "DELETE FROM invoices WHERE id = :id AND user_id = :user_id";
         $result_invoice = query($conn, $sql_delete_invoice, ['id' => $invoice_id, 'user_id' => $user_id]);

         if (!$result_invoice) {
             throw new Exception("Failed to delete invoice record (DB error: " . mysqli_error($conn) . ")");
         }

        // Check if deletion actually happened
         if (mysqli_affected_rows($conn) > 0) {
            commit_transaction($conn); // Commit only if everything succeeded
            echo json_encode(['success' => true, 'message' => 'Invoice deleted successfully.']);
         } else {
             throw new Exception("Invoice deletion query executed but no rows were affected (unexpected).");
         }

     } catch (Exception $e) {
         rollback_transaction($conn); // Rollback on any error during the transaction
         http_response_code(500); // Internal Server Error
         error_log("Error deleting invoice $invoice_id for user $user_id: " . $e->getMessage());
         echo json_encode(['success' => false, 'message' => 'Failed to delete invoice due to a server error: ' . $e->getMessage()]);
     }
}

/**
 * Generates HTML preview based on POST data.
 * Handles selected bank_account_id.
 */
/*function previewInvoice() {
    global $conn, $user_id;

    // --- Input Validation for Preview ---
    $missing_fields = [];
    if (empty($_POST['invoice_date'])) $missing_fields[] = 'Invoice Date';
    if (empty($_POST['client_id']) || !filter_var($_POST['client_id'], FILTER_VALIDATE_INT)) $missing_fields[] = 'Client Selection';
    if (!isset($_POST['description']) || !is_array($_POST['description'])) $missing_fields[] = 'Invoice Items';
    if (!isset($_POST['invoice_number'])) $_POST['invoice_number'] = 'PREVIEW-XXXX';

    $valid_item_found_preview = false;
    if (isset($_POST['description']) && is_array($_POST['description'])) {
         foreach ($_POST['description'] as $desc) { if (!empty(trim($desc))) { $valid_item_found_preview = true; break; } }
    }
    if (!$valid_item_found_preview) $missing_fields[] = 'At least one item description';

    if (!empty($missing_fields)) { http_response_code(400); echo json_encode(['success' => false, 'message' => 'Missing required data for preview: ' . implode(', ', $missing_fields)]); return; }

    // --- Get Company and Client Details ---
    $company = getCompanyDetails($conn, $user_id);

    $client_id = (int)$_POST['client_id'];
    $sql_client = "SELECT * FROM clients WHERE id = :id AND user_id = :user_id";
    $result_client = query($conn, $sql_client, ['id' => $client_id, 'user_id' => $user_id]);
    if (!$result_client || fetch_count($conn, $result_client) === 0) { http_response_code(404); echo json_encode(['success' => false, 'message' => 'Selected client not found for preview.']); return; }
    $client = fetch_one($result_client);

    // *** NEW: Get selected bank ID from POST data ***
    $preview_bank_id = isset($_POST['bank_account_id']) && ctype_digit((string)$_POST['bank_account_id']) && (int)$_POST['bank_account_id'] > 0
                        ? (int)$_POST['bank_account_id']
                        : null;

    // --- Prepare Invoice Data Array from POST ---
    $invoice_data = [
        'invoice_number' => htmlspecialchars($_POST['invoice_number'] ?? 'PREVIEW-XXXX', ENT_QUOTES, 'UTF-8'),
        'invoice_date' => sanitize($conn, $_POST['invoice_date']),
        'due_date' => !empty($_POST['due_date']) ? sanitize($conn, $_POST['due_date']) : null,
        'hsn_code' => !empty(trim($_POST['hsn_code'] ?? '')) ? sanitize($conn, trim($_POST['hsn_code'])) : null,
        'po_number' => !empty(trim($_POST['po_number'] ?? '')) ? sanitize($conn, trim($_POST['po_number'])) : null,
        'cgst_rate' => isset($_POST['cgst_rate']) && is_numeric($_POST['cgst_rate']) ? (float)$_POST['cgst_rate'] : 0.0,
        'sgst_rate' => isset($_POST['sgst_rate']) && is_numeric($_POST['sgst_rate']) ? (float)$_POST['sgst_rate'] : 0.0,
        'convenience_fee' => isset($_POST['convenience_fee']) && is_numeric($_POST['convenience_fee']) ? round((float)$_POST['convenience_fee'], 2) : 0.0,
        'advance_paid' => isset($_POST['advance_paid']) && is_numeric($_POST['advance_paid']) ? round((float)$_POST['advance_paid'], 2) : 0.0,
        'notes' => !empty(trim($_POST['notes'] ?? '')) ? sanitize($conn, $_POST['notes']) : null,
        // Client data fetched from DB
        'client_name' => $client['name'] ?? '', 'client_address' => $client['address'] ?? '', 'client_gstin' => $client['gstin'] ?? '', 'client_state' => $client['state'] ?? '', 'client_state_code' => $client['state_code'] ?? '',
        // Pass the bank ID for generateInvoiceHTML to use
        'bank_account_id' => $preview_bank_id
        // status will be determined below based on POST data
    ];

    // --- Prepare Item Data Array & Calculate Preview Subtotal ---
    $items_preview = []; $preview_subtotal = 0;
    $descriptions = $_POST['description'] ?? []; $quantities = $_POST['quantity'] ?? []; $rates = $_POST['rate'] ?? [];

    if (is_array($descriptions) && count($descriptions) === count($quantities) && count($descriptions) === count($rates)) {
        for ($i = 0; $i < count($descriptions); $i++) {
            $desc = trim($descriptions[$i]);
            if (empty($desc)) continue;

            $qty = isset($quantities[$i]) && is_numeric($quantities[$i]) ? (float)$quantities[$i] : 0;
            $rate = isset($rates[$i]) && is_numeric($rates[$i]) ? (float)$rates[$i] : 0;

            if ($qty < 0 || $rate < 0) { http_response_code(400); echo json_encode(['success' => false, 'message' => 'Preview Error: Quantity and Rate cannot be negative for item: ' . htmlspecialchars($desc, ENT_QUOTES, 'UTF-8')]); return; }

            $amount = round($qty * $rate, 2);
            $preview_subtotal += $amount;
            $items_preview[] = [
                'description' => sanitize($conn, $desc), 'quantity' => $qty, 'rate' => $rate, 'amount' => $amount
            ];
        }
    }
    if (empty($items_preview)) { http_response_code(400); echo json_encode(['success' => false, 'message' => 'Preview requires at least one valid invoice item.']); return; }

    // --- Re-calculate Totals and Status *Based on Preview Data* ---
    $invoice_data['subtotal'] = round($preview_subtotal, 2);
    $invoice_data['cgst_amount'] = round(($invoice_data['subtotal'] * $invoice_data['cgst_rate']) / 100, 2);
    $invoice_data['sgst_amount'] = round(($invoice_data['subtotal'] * $invoice_data['sgst_rate']) / 100, 2);
    $invoice_data['convenience_fee'] = max(0, $invoice_data['convenience_fee']);
    $invoice_data['total_amount'] = round($invoice_data['subtotal'] + $invoice_data['cgst_amount'] + $invoice_data['sgst_amount'] + $invoice_data['convenience_fee'], 2);

    // Determine Status for Preview: Prioritize 'status' from POST if valid, else calculate
    $allowed_statuses = ['paid', 'unpaid', 'partially_paid'];
     if (isset($_POST['status']) && in_array($_POST['status'], $allowed_statuses)) {
         $invoice_data['status'] = sanitize($conn, $_POST['status']);
     } else {
         $invoice_data['status'] = calculateInvoiceStatus($invoice_data['total_amount'], $invoice_data['advance_paid']);
     }

    // --- Generate HTML using the prepared data ---
    // generateInvoiceHTML now accepts invoice data containing bank_account_id
    $html = generateInvoiceHTML($invoice_data, $items_preview, $company);

    echo json_encode(['success' => true, 'html' => $html]);
}*/

function previewInvoice() {
    global $conn, $user_id;

    // --- Input Validation for Preview (mostly unchanged) ---
    $missing_fields = [];
    if (empty($_POST['invoice_date'])) $missing_fields[] = 'Invoice Date';
    if (empty($_POST['client_id']) || !filter_var($_POST['client_id'], FILTER_VALIDATE_INT)) $missing_fields[] = 'Client Selection';
    if (!isset($_POST['description']) || !is_array($_POST['description'])) $missing_fields[] = 'Invoice Items';
    if (!isset($_POST['invoice_number'])) $_POST['invoice_number'] = 'PREVIEW-XXXX';

    $valid_item_found_preview = false;
    if (isset($_POST['description']) && is_array($_POST['description'])) {
         foreach ($_POST['description'] as $desc) { if (!empty(trim($desc))) { $valid_item_found_preview = true; break; } }
    }
    if (!$valid_item_found_preview) { http_response_code(400); echo json_encode(['success' => false, 'message' => 'At least one item description is required for preview.']); return; }

    if (!empty($missing_fields)) { http_response_code(400); echo json_encode(['success' => false, 'message' => 'Missing required data for preview: ' . implode(', ', $missing_fields)]); return; }

    // --- Get Company and Client Details ---
    $company = getCompanyDetails($conn, $user_id);

    $client_id = (int)$_POST['client_id'];
    $sql_client = "SELECT * FROM clients WHERE id = :id AND user_id = :user_id";
    $result_client = query($conn, $sql_client, ['id' => $client_id, 'user_id' => $user_id]);
    if (!$result_client || fetch_count($conn, $result_client) === 0) { http_response_code(404); echo json_encode(['success' => false, 'message' => 'Selected client not found for preview.']); return; }
    $client = fetch_one($result_client);

    // Get selected bank ID from POST data (keep your existing logic)
    $preview_bank_id = isset($_POST['bank_account_id']) && ctype_digit((string)$_POST['bank_account_id']) && (int)$_POST['bank_account_id'] > 0
                        ? (int)$_POST['bank_account_id'] : null;

    // --- Prepare Invoice Data Array from POST (excluding calculated totals initially) ---
     // We get rates/fees etc directly from POST below for recalculation
    $invoice_data_base = [
        'invoice_number' => htmlspecialchars($_POST['invoice_number'] ?? 'PREVIEW-XXXX', ENT_QUOTES, 'UTF-8'),
        'invoice_date' => sanitize($conn, $_POST['invoice_date']),
        'due_date' => !empty($_POST['due_date']) ? sanitize($conn, $_POST['due_date']) : null,
        'hsn_code' => !empty(trim($_POST['hsn_code'] ?? '')) ? sanitize($conn, trim($_POST['hsn_code'])) : null,
        'po_number' => !empty(trim($_POST['po_number'] ?? '')) ? sanitize($conn, trim($_POST['po_number'])) : null,
        'notes' => !empty(trim($_POST['notes'] ?? '')) ? sanitize($conn, $_POST['notes']) : null,
        // Client data
        'client_name' => $client['name'] ?? '', 'client_address' => $client['address'] ?? '', 'client_gstin' => $client['gstin'] ?? '', 'client_state' => $client['state'] ?? '', 'client_state_code' => $client['state_code'] ?? '',
         // Bank ID
         'bank_account_id' => $preview_bank_id
    ];

    // --- Prepare Item Data Array & Calculate Preview Subtotal ---
    $items_preview = []; $preview_subtotal = 0;
    $descriptions = $_POST['description'] ?? []; $quantities = $_POST['quantity'] ?? []; $rates = $_POST['rate'] ?? [];

    if (is_array($descriptions) /*... rest of check ...*/) {
        for ($i = 0; $i < count($descriptions); $i++) {
            $desc = trim($descriptions[$i]);
            if (empty($desc)) continue;
            $qty = isset($quantities[$i]) && is_numeric($quantities[$i]) ? max(0, (float)$quantities[$i]) : 0;
            $rate = isset($rates[$i]) && is_numeric($rates[$i]) ? max(0, (float)$rates[$i]) : 0;
            // Validation for negative qty/rate kept from original code
             if ($qty < 0 || $rate < 0) { http_response_code(400); echo json_encode(['success' => false, 'message' => 'Preview Error: Quantity and Rate cannot be negative.']); return; }

            $amount = round($qty * $rate, 2);
            $preview_subtotal += $amount;
             $items_preview[] = [ 'description' => sanitize($conn, $desc), 'quantity' => $qty, 'rate' => $rate, 'amount' => $amount ];
        }
    }
    if (empty($items_preview)) { http_response_code(400); echo json_encode(['success' => false, 'message' => 'Preview requires at least one valid item.']); return; }
    $preview_subtotal = round($preview_subtotal, 2);


    // --- Get Rates, Fees, Discount, Advance from POST for Calculation ---
     $discount_rate = 0.00; if (isset($_POST['discount_rate']) && is_numeric($_POST['discount_rate'])) { $discount_rate = max(0, min(100, (float)$_POST['discount_rate'])); }
     $cgst_rate = isset($_POST['cgst_rate']) && is_numeric($_POST['cgst_rate']) ? max(0, (float)$_POST['cgst_rate']) : 0.0;
    $sgst_rate = isset($_POST['sgst_rate']) && is_numeric($_POST['sgst_rate']) ? max(0, (float)$_POST['sgst_rate']) : 0.0;
     $convenience_fee = isset($_POST['convenience_fee']) && is_numeric($_POST['convenience_fee']) ? round(max(0, (float)$_POST['convenience_fee']), 2) : 0.0;
    $advance_paid = isset($_POST['advance_paid']) && is_numeric($_POST['advance_paid']) ? round(max(0, (float)$_POST['advance_paid']), 2) : 0.0;

    // *** Recalculate Preview Totals Including Discount ***
    $preview_discount_amount = round(($preview_subtotal * $discount_rate) / 100, 2);
    $preview_taxable_amount = round($preview_subtotal - $preview_discount_amount, 2);
    $preview_cgst_amount = round(($preview_taxable_amount * $cgst_rate) / 100, 2);
    $preview_sgst_amount = round(($preview_taxable_amount * $sgst_rate) / 100, 2);
    $preview_total_amount = round($preview_taxable_amount + $preview_cgst_amount + $preview_sgst_amount + $convenience_fee, 2);

    // Determine Preview Status based on calculated total and posted advance
    $preview_status = calculateInvoiceStatus($preview_total_amount, $advance_paid);
     // Allow submitted status (from edit form) to override if valid
     $allowed_statuses = ['paid', 'unpaid', 'partially_paid'];
     if (isset($_POST['status']) && in_array(strtolower(trim($_POST['status'])), $allowed_statuses)) {
         $preview_status = sanitize($conn, strtolower(trim($_POST['status'])));
     }

    // --- Combine Base Data with Calculated Values for HTML Generation ---
    $final_invoice_data = array_merge($invoice_data_base, [
        'discount_rate' => $discount_rate,     // Rate used for calc
        'cgst_rate' => $cgst_rate,             // Rate used for calc
        'sgst_rate' => $sgst_rate,             // Rate used for calc
        'convenience_fee' => $convenience_fee, // Fee used for calc
        'advance_paid' => $advance_paid,       // Advance used for calc
        // Calculated amounts for display
        'subtotal' => $preview_subtotal,
         'discount_amount' => $preview_discount_amount,
        'cgst_amount' => $preview_cgst_amount,
        'sgst_amount' => $preview_sgst_amount,
        'total_amount' => $preview_total_amount,
        'status' => $preview_status             // Determined status
    ]);


    // --- Generate HTML using the prepared data ---
    $html = generateInvoiceHTML($final_invoice_data, $items_preview, $company);

    echo json_encode(['success' => true, 'html' => $html]);
}


// ========= END Invoice Functions =========


// *** BANK ACTION FUNCTIONS (Set Default Removed) ***

/**
 * Get all banks for the logged-in user.
 */
function getBanks() {
    global $conn, $user_id;
    // Remove 'is_default' from SELECT if not needed elsewhere, keep ORDER BY is_default temporarily if useful
    // ORDER BY clause is updated to just use bank_name
    $sql = "SELECT id, bank_name, account_holder_name, account_number, ifsc_code, branch_name, upi_id
            FROM user_banks
            WHERE user_id = :user_id
            ORDER BY bank_name ASC"; // Simpler sorting
    try {
        $result = query($conn, $sql, ['user_id' => $user_id]);
        if ($result) {
            $banks = fetch_all($result);
            // Remove is_default casting if the column selection was changed
            // foreach ($banks as $key => $bank) {
            //     $banks[$key]['is_default'] = (bool)$bank['is_default']; // REMOVED: Not needed anymore
            // }
            echo json_encode(['success' => true, 'banks' => $banks]);
        } else {
            throw new Exception("Database error fetching banks: " . mysqli_error($conn));
        }
    } catch (Exception $e) {
        error_log("Error in getBanks for user $user_id: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to retrieve bank accounts. Please check logs.']);
    }
}

/**
 * Save (Insert or Update) a bank account.
 * Does NOT handle the 'is_default' flag anymore.
 */
function saveBank() {
    global $conn, $user_id;

    // Basic Validation
    $required_fields = ['bank_name', 'account_number', 'ifsc_code'];
    $errors = [];
    foreach ($required_fields as $field) { if (empty(trim($_POST[$field]))) { $errors[] = ucfirst(str_replace('_', ' ', $field)) . ' is required.'; } }
    if (!empty($errors)) { http_response_code(400); echo json_encode(['success' => false, 'message' => implode(' ', $errors)]); return; }

    $bank_id = isset($_POST['id']) && ctype_digit((string)$_POST['id']) ? (int)$_POST['id'] : null;
    $bank_name = sanitize($conn, trim($_POST['bank_name']));
    $account_holder_name = isset($_POST['account_holder_name']) && !empty(trim($_POST['account_holder_name'])) ? sanitize($conn, trim($_POST['account_holder_name'])) : null;
    $account_number = sanitize($conn, trim($_POST['account_number']));
    $ifsc_code = sanitize($conn, trim($_POST['ifsc_code']));
    $branch_name = isset($_POST['branch_name']) && !empty(trim($_POST['branch_name'])) ? sanitize($conn, trim($_POST['branch_name'])) : null;
    $upi_id = isset($_POST['upi_id']) && !empty(trim($_POST['upi_id'])) ? sanitize($conn, trim($_POST['upi_id'])) : null;
    // No handling of is_default

    $sql = ''; $params = []; $action_type = '';

    try {
        if ($bank_id) { // UPDATE existing bank account
            $sql_check = "SELECT id FROM user_banks WHERE id = :id AND user_id = :user_id";
            $res_check = query($conn, $sql_check, ['id' => $bank_id, 'user_id' => $user_id]);
            if (!$res_check || fetch_count($conn, $res_check) === 0) { http_response_code(404); echo json_encode(['success' => false, 'message' => 'Bank account not found or access denied.']); return; }

            // Removed is_default update
            $sql = "UPDATE user_banks SET
                        bank_name = :bank_name, account_holder_name = :account_holder_name,
                        account_number = :account_number, ifsc_code = :ifsc_code,
                        branch_name = :branch_name, upi_id = :upi_id
                    WHERE id = :id AND user_id = :user_id";
            $params = [
                'bank_name' => $bank_name, 'account_holder_name' => $account_holder_name, 'account_number' => $account_number, 'ifsc_code' => $ifsc_code,
                'branch_name' => $branch_name, 'upi_id' => $upi_id,
                'id' => $bank_id, 'user_id' => $user_id
            ];
            $action_type = 'updated';
        } else { // INSERT new bank account
            // Removed is_default handling
             $sql = "INSERT INTO user_banks (user_id, bank_name, account_holder_name, account_number, ifsc_code, branch_name, upi_id)
                    VALUES (:user_id, :bank_name, :account_holder_name, :account_number, :ifsc_code, :branch_name, :upi_id)";
             $params = [
                 'user_id' => $user_id, 'bank_name' => $bank_name, 'account_holder_name' => $account_holder_name,
                 'account_number' => $account_number, 'ifsc_code' => $ifsc_code,
                 'branch_name' => $branch_name, 'upi_id' => $upi_id
             ];
             // is_default automatically defaults to FALSE (0) in the DB schema assumed
             $action_type = 'added';
        }

        $result = query($conn, $sql, $params);

        if ($result) {
            $current_bank_id = $bank_id ?: last_id($conn);
            // Fetch the saved/updated bank data (removed is_default)
             $sql_get = "SELECT id, bank_name, account_holder_name, account_number, ifsc_code, branch_name, upi_id FROM user_banks WHERE id = :id AND user_id = :user_id";
             $res_get = query($conn, $sql_get, ['id' => $current_bank_id, 'user_id' => $user_id]);
             if ($res_get && fetch_count($conn, $res_get) > 0) {
                 $bank_data = fetch_one($res_get);
                 // No need to cast is_default to bool
                 echo json_encode(['success' => true, 'message' => "Bank account {$action_type} successfully.", 'bank' => $bank_data]);
            } else {
                 error_log("Bank save ($action_type) OK, but failed retrieve bank ID: $current_bank_id user: $user_id");
                 echo json_encode(['success' => true, 'message' => "Bank account {$action_type} successfully (details might need refresh).", 'bank_id' => $current_bank_id]);
             }
        } else {
            if (mysqli_errno($conn) == 1062 && strpos(mysqli_error($conn), 'unique_user_account') !== false) {
                 http_response_code(409); echo json_encode(['success' => false, 'message' => "This account number is already registered for your profile."]);
             } else { throw new Exception("Database error saving bank account details. Error: " . mysqli_error($conn)); }
        }
    } catch (Exception $e) {
        error_log("Exception in saveBank for user $user_id: " . $e->getMessage());
         if(http_response_code() < 400){ http_response_code(500); }
         echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}


/**
 * Delete a specific bank account.
 * Removes check/warning for deleting default.
 */
function deleteBank() {
    global $conn, $user_id;
    $bank_id = isset($_REQUEST['id']) && ctype_digit((string)$_REQUEST['id']) ? (int)$_REQUEST['id'] : 0;
    if (!$bank_id) { http_response_code(400); echo json_encode(['success' => false, 'message' => 'Invalid bank ID specified.']); return; }

    try {
        // Check if the bank exists and belongs to the user (Removed is_default check)
        $sql_check = "SELECT id FROM user_banks WHERE id = :id AND user_id = :user_id";
        $res_check = query($conn, $sql_check, ['id' => $bank_id, 'user_id' => $user_id]);

        if (!$res_check) { throw new Exception("Database error checking bank account: " . mysqli_error($conn)); }
        if (fetch_count($conn, $res_check) === 0) { http_response_code(404); echo json_encode(['success' => false, 'message' => 'Bank account not found or access denied.']); return; }

        // REMOVED logic checking if $bank_details['is_default'] == 1

        // Proceed with deletion
        $sql_delete = "DELETE FROM user_banks WHERE id = :id AND user_id = :user_id";
        $result = query($conn, $sql_delete, ['id' => $bank_id, 'user_id' => $user_id]);

        if ($result && mysqli_affected_rows($conn) > 0) {
            // REMOVED warning message append
             echo json_encode(['success' => true, 'message' => 'Bank account deleted successfully.']);
        } elseif ($result) { http_response_code(404); echo json_encode(['success' => false, 'message' => 'Bank account could not be deleted (might have been deleted already).']);
        } else { throw new Exception("Database error deleting bank account: " . mysqli_error($conn)); }
    } catch (Exception $e) {
        error_log("Error in deleteBank for user $user_id, bank $bank_id: " . $e->getMessage());
        http_response_code(500); echo json_encode(['success' => false, 'message' => 'An error occurred while deleting the bank account. Please try again.']);
    }
}


// --- Client Status Report Functions (Unchanged) ---
function getClientStatusReport() {
     global $conn, $user_id;
     // --- Input Validation ---
     $start_date = isset($_GET['start_date']) && validateDate($_GET['start_date']) ? sanitize($conn, $_GET['start_date']) : null;
     $end_date = isset($_GET['end_date']) && validateDate($_GET['end_date']) ? sanitize($conn, $_GET['end_date']) : null;
     $client_ids_raw = isset($_GET['client_ids']) && is_array($_GET['client_ids']) ? $_GET['client_ids'] : [];
     $client_ids = [];
     foreach($client_ids_raw as $cid) { if (ctype_digit((string)$cid)) { $client_ids[] = (int)$cid; } }

     // Required field checks
     if (!$start_date || !$end_date || empty($client_ids)) { http_response_code(400); echo json_encode(['success' => false, 'message' => 'Start date, end date, and at least one client selection are required.']); return; }
     if ($start_date > $end_date) { http_response_code(400); echo json_encode(['success' => false, 'message' => 'Start date cannot be after end date.']); return; }

    // Ensure user owns selected clients before using them in the query
    $client_id_placeholders = rtrim(str_repeat('?,', count($client_ids)), ','); // Prepare placeholders for binding
    $sql_check_clients = "SELECT id FROM clients WHERE user_id = ? AND id IN ($client_id_placeholders)";
    $check_params = array_merge([$user_id], $client_ids); // Combine user ID and client IDs for checking

    // NOTE: The custom 'query' function likely doesn't support binding arrays directly for 'IN'.
    // We need a temporary workaround or adaptation for IN clause checking here, OR we trust the JS validation + initial load logic.
    // For safety, let's create the comma-separated list *after* confirming the IDs are digits (done above).
    $safe_client_id_list = implode(',', $client_ids); // String like "1,5,12" - safe as we validated digits
    if (empty($safe_client_id_list)) { // Double-check list isn't empty after validation
        http_response_code(400); echo json_encode(['success' => false, 'message' => 'No valid client IDs provided.']); return;
    }

     // Build WHERE clauses and parameters for the main query
     $where_clauses = [ "i.user_id = :user_id", "i.invoice_date BETWEEN :start_date AND :end_date", "i.client_id IN ($safe_client_id_list)" ];
     $where_sql = implode(" AND ", $where_clauses);
     $params = ['user_id' => $user_id, 'start_date' => $start_date, 'end_date' => $end_date ];

     // --- Main Aggregation Query ---
     $sql_summary = "
         SELECT
             c.id as client_id,
             c.name as client_name,
             COUNT(i.id) as total_invoice_count,
             COALESCE(SUM(i.total_amount), 0.00) as total_invoiced,
             SUM(CASE WHEN LOWER(i.status) = 'paid' THEN 1 ELSE 0 END) as paid_count,
             SUM(CASE WHEN LOWER(i.status) = 'unpaid' OR LOWER(i.status) = 'partially_paid' THEN 1 ELSE 0 END) as unpaid_partial_count,
             COALESCE(SUM(i.advance_paid), 0.00) as total_paid_amount,
             COALESCE(SUM(CASE WHEN LOWER(i.status) != 'paid' THEN GREATEST(0, i.total_amount - i.advance_paid) ELSE 0 END), 0.00) as total_due_amount
         FROM clients c
         LEFT JOIN invoices i ON c.id = i.client_id AND i.invoice_date BETWEEN :start_date AND :end_date AND i.user_id = :user_id -- Join condition includes date & user
         WHERE c.user_id = :user_id AND c.id IN ($safe_client_id_list) -- Filter clients table
         GROUP BY c.id, c.name
         ORDER BY c.name ASC";

     try {
         $result = query($conn, $sql_summary, $params);
         if ($result) {
            $summary = fetch_all($result);
            echo json_encode(['success' => true, 'summary' => $summary]);
         } else {
            throw new Exception("Database error generating client status report: " . mysqli_error($conn));
        }
     } catch (Exception $e) {
         error_log("Error in getClientStatusReport for user $user_id: " . $e->getMessage());
         http_response_code(500);
         echo json_encode(['success' => false, 'message' => $e->getMessage()]);
     }
}

function exportClientStatusReport($format = 'csv') {
    global $conn, $user_id;

     // --- Reuse Input Validation logic from getClientStatusReport ---
     $start_date = isset($_GET['start_date']) && validateDate($_GET['start_date']) ? sanitize($conn, $_GET['start_date']) : null;
     $end_date = isset($_GET['end_date']) && validateDate($_GET['end_date']) ? sanitize($conn, $_GET['end_date']) : null;
     $client_ids_raw = isset($_GET['client_ids']) && is_array($_GET['client_ids']) ? $_GET['client_ids'] : [];
     $client_ids = []; foreach($client_ids_raw as $cid) { if (ctype_digit((string)$cid)) { $client_ids[] = (int)$cid; } }

    if (!$start_date || !$end_date || empty($client_ids)) { http_response_code(400); die('Start date, end date, and client selection are required.'); }
    if ($start_date > $end_date) { http_response_code(400); die('Start date cannot be after end date.'); }
    $safe_client_id_list = implode(',', $client_ids);
    if (empty($safe_client_id_list)) { http_response_code(400); die('No valid client IDs provided.'); }

    // Reuse query from getClientStatusReport
    $where_clauses = [ "i.user_id = :user_id", "i.invoice_date BETWEEN :start_date AND :end_date", "i.client_id IN ($safe_client_id_list)" ];
    $where_sql = implode(" AND ", $where_clauses);
    $params = ['user_id' => $user_id, 'start_date' => $start_date, 'end_date' => $end_date ];
     $sql_summary = "
         SELECT
             c.name as client_name,
             COUNT(i.id) as total_invoice_count,
             COALESCE(SUM(i.total_amount), 0.00) as total_invoiced,
             SUM(CASE WHEN LOWER(i.status) = 'paid' THEN 1 ELSE 0 END) as paid_count,
             SUM(CASE WHEN LOWER(i.status) = 'unpaid' OR LOWER(i.status) = 'partially_paid' THEN 1 ELSE 0 END) as unpaid_partial_count,
             COALESCE(SUM(i.advance_paid), 0.00) as total_paid_amount,
             COALESCE(SUM(CASE WHEN LOWER(i.status) != 'paid' THEN GREATEST(0, i.total_amount - i.advance_paid) ELSE 0 END), 0.00) as total_due_amount
         FROM clients c
         LEFT JOIN invoices i ON c.id = i.client_id AND i.invoice_date BETWEEN :start_date AND :end_date AND i.user_id = :user_id
         WHERE c.user_id = :user_id AND c.id IN ($safe_client_id_list)
         GROUP BY c.id, c.name ORDER BY c.name ASC";

     try {
         $result = query($conn, $sql_summary, $params);
         if (!$result) { throw new Exception("Database error preparing export data: " . mysqli_error($conn)); }
         $summary = fetch_all($result);

        if ($format === 'csv') {
            $filename = "Client_Status_Report_" . date('Ymd') . ".csv";
            header('Content-Type: text/csv; charset=utf-8');
             header('Content-Disposition: attachment; filename="' . $filename . '"');
             $output = fopen('php://output', 'w');

            // Add Header Row
            fputcsv($output, [
                 'Client Name', 'Total Invoices', 'Total Billed (INR)', '# Paid', '# Unpaid/Partial', 'Total Paid Amt (INR)', 'Total Due Amt (INR)'
            ]);

             // Initialize totals
             $grandTotalInvoices = 0; $grandTotalBilled = 0; $grandTotalPaidCount = 0; $grandTotalUnpaidCount = 0; $grandTotalPaidAmt = 0; $grandTotalDueAmt = 0;

             // Add Data Rows and accumulate totals
            foreach ($summary as $row) {
                $billed = (float)($row['total_invoiced'] ?? 0);
                $paidAmt = (float)($row['total_paid_amount'] ?? 0);
                $dueAmt = (float)($row['total_due_amount'] ?? 0);
                $paidCount = (int)($row['paid_count'] ?? 0);
                $unpaidCount = (int)($row['unpaid_partial_count'] ?? 0);
                 $totalCount = (int)($row['total_invoice_count'] ?? ($paidCount + $unpaidCount)); // Calculate if missing

                fputcsv($output, [
                    $row['client_name'] ?? '',
                    $totalCount,
                    number_format($billed, 2, '.', ''),
                    $paidCount,
                    $unpaidCount,
                    number_format($paidAmt, 2, '.', ''),
                    number_format($dueAmt, 2, '.', '')
                ]);

                $grandTotalInvoices += $totalCount; $grandTotalBilled += $billed;
                $grandTotalPaidCount += $paidCount; $grandTotalUnpaidCount += $unpaidCount;
                 $grandTotalPaidAmt += $paidAmt; $grandTotalDueAmt += $dueAmt;
            }

            // Add Empty Row for spacing
             fputcsv($output, []);

            // Add Totals Row
            fputcsv($output, [
                'Grand Totals', $grandTotalInvoices, number_format($grandTotalBilled, 2, '.', ''),
                $grandTotalPaidCount, $grandTotalUnpaidCount, number_format($grandTotalPaidAmt, 2, '.', ''),
                number_format($grandTotalDueAmt, 2, '.', '')
            ]);

            fclose($output);
            exit;
        } else {
             http_response_code(400); echo json_encode(['success' => false, 'message' => 'Invalid export format specified.']); exit;
        }

     } catch (Exception $e) {
         error_log("Error during CSV export for user $user_id: " . $e->getMessage());
         http_response_code(500);
         // Don't echo JSON here, as headers might be sent. Just die.
         die("An error occurred during export.");
     }
}

// Helper function used by report functions
function validateDate($date, $format = 'Y-m-d') {
    $d = DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) === $date;
}

// *** END CLIENT STATUS REPORT FUNCTIONS ***


// --- HTML Generation Function (MODIFIED FOR SELECTED BANK) ---
/**
 * Generates the HTML markup for an invoice preview/display.
 * Fetches bank details based on the 'bank_account_id' provided in the $invoice array.
 */


// --- HTML Generation Function (Internal Use) - Updated for Discount & Full Styles ---

// --- HTML Generation Function (Internal Use) - Corrected for PDF Layout ---
function generateInvoiceHTML($invoice, $items, $company) {
    global $conn, $user_id; // Need access to DB and user context

    // Helper functions
    function h($str) { return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8'); }
    function format_date($date_str, $format = 'd-m-Y') { return !empty($date_str) ? date($format, strtotime($date_str)) : ''; }

    // --- Prepare Company Details ---
    $company_name = h($company['name'] ?? 'Your Company Name');
    $company_address = nl2br(h($company['address'] ?? ''));
    $company_phone = h($company['phone'] ?? '');
    $company_email = h($company['email'] ?? '');
    $company_website = h($company['website'] ?? '');
    $company_gstin = h($company['gstin'] ?? '');
    $company_stamp_path = $company['stamp_path'] ?? null;
    $company_upi_qr_code_path = $company['upi_qr_code_path'] ?? null;
    $default_notes_raw = $company['default_notes'] ?? 'Payment due within 30 days.';

    // --- Fetch Selected Bank Details ---
    $selected_bank = null;
    $selected_bank_id = $invoice['bank_account_id'] ?? null;
    if ($selected_bank_id) {
        $sql_get_selected_bank = "SELECT bank_name, account_holder_name, account_number, ifsc_code, branch_name, upi_id FROM user_banks WHERE id = :bank_id AND user_id = :user_id LIMIT 1";
        try {
            $result_bank = query($conn, $sql_get_selected_bank, ['bank_id' => $selected_bank_id, 'user_id' => $user_id]);
            if ($result_bank && fetch_count($conn, $result_bank) > 0) {
                $selected_bank = fetch_one($result_bank);
            }
        } catch (Exception $e) { error_log("Error fetching selected bank {$selected_bank_id}: " . $e->getMessage()); }
    }
    $display_bank_name = h($selected_bank['bank_name'] ?? '');
    $display_account_holder = h($selected_bank['account_holder_name'] ?? '');
    $display_account_number = h($selected_bank['account_number'] ?? '');
    $display_ifsc_code = h($selected_bank['ifsc_code'] ?? '');
    $display_branch_name = h($selected_bank['branch_name'] ?? '');
    $display_upi_id = h($selected_bank['upi_id'] ?? '');

    // --- Invoice & Client Details ---
    $invoice_date_formatted = format_date($invoice['invoice_date'] ?? '');
    $due_date_formatted = format_date($invoice['due_date'] ?? '');
    $invoice_number_display = h($invoice['invoice_number'] ?? 'INV-XXXX');
    $client_name = h($invoice['client_name'] ?? 'Client Name');
    $client_address = nl2br(h($invoice['client_address'] ?? ''));
    $client_gstin = h($invoice['client_gstin'] ?? '');
    $client_state = h($invoice['client_state'] ?? '');
    $client_state_code = h($invoice['client_state_code'] ?? '');

    // --- Financials ---
    $subtotal = (float)($invoice['subtotal'] ?? 0.0);
    $discount_rate = (float)($invoice['discount_rate'] ?? 0.0);
    $discount_amount = (float)($invoice['discount_amount'] ?? 0.0);
    $cgst_rate = (float)($invoice['cgst_rate'] ?? 0.0);
    $sgst_rate = (float)($invoice['sgst_rate'] ?? 0.0);
    $cgst_amount = (float)($invoice['cgst_amount'] ?? 0.0);
    $sgst_amount = (float)($invoice['sgst_amount'] ?? 0.0);
    $convenience_fee = (float)($invoice['convenience_fee'] ?? 0.0);
    $advance_paid = (float)($invoice['advance_paid'] ?? 0.0);
    $total_amount = (float)($invoice['total_amount'] ?? 0.0);
    $amount_due = max(0, round($total_amount - $advance_paid, 2));
    $taxable_amount_display = round($subtotal - $discount_amount, 2);

    // --- Status ---
    $status_val = strtolower(trim($invoice['status'] ?? 'unpaid'));
    $status_class = 'status-default'; $status_text = 'Unknown';
    if ($status_val === 'paid') { $status_class = 'status-paid'; $status_text = 'Paid'; }
    elseif ($status_val === 'unpaid') { $status_class = 'status-unpaid'; $status_text = 'Unpaid'; }
    elseif ($status_val === 'partially_paid') { $status_class = 'status-partially_paid'; $status_text = 'Partially Paid'; }

    // --- Notes & Images ---
    $final_notes = nl2br(h(!empty(trim($invoice['notes'] ?? '')) ? $invoice['notes'] : $default_notes_raw));
    $qr_code_data_uri = null; $stamp_data_uri = null;
    if ($company_upi_qr_code_path && file_exists($company_upi_qr_code_path)) {
        $qr_mime = @mime_content_type($company_upi_qr_code_path); if ($qr_mime) { $qr_code_data_uri = 'data:' . $qr_mime . ';base64,' . base64_encode(file_get_contents($company_upi_qr_code_path)); }
    }
    if ($company_stamp_path && file_exists($company_stamp_path)) {
        $stamp_mime = @mime_content_type($company_stamp_path); if ($stamp_mime) { $stamp_data_uri = 'data:' . $stamp_mime . ';base64,' . base64_encode(file_get_contents($company_stamp_path)); }
    }

    ob_start();
    ?>
    <div style="font-family: 'Poppins', sans-serif; color: #333; max-width: 800px; margin: 20px auto; padding: 25px; background-color: white; border: 1px solid #e2e8f0; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); position: relative; padding-bottom: 220px; min-height: 980px;">
        
        <!-- Main Content Area -->
        <div>
            <!-- Watermark -->
            <div style="position: absolute; top: 35%; left: 50%; transform: translate(-50%, -50%) rotate(-30deg); font-size: 5.5rem; font-weight: 800; color: rgba(0,0,0,0.05); z-index: 0; white-space: nowrap; pointer-events: none; text-transform: uppercase; letter-spacing: 2px;">
                <?php echo $status_text; ?>
            </div>

            <!-- Header: Company Info & Invoice Title -->
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 25px; position: relative; z-index: 1;">
                <tr>
                    <td style="width: 60%; vertical-align: top;">
                        <div style="font-size: 24px; font-weight: 700; color: #1e40af; margin-bottom: 8px;"><?php echo $company_name; ?></div>
                        <div style="font-size: 13px; color: #475569; line-height: 1.6;">
                            <?php echo $company_address; ?>
                            <?php if ($company_phone): ?><br>Phone: <?php echo $company_phone; ?><?php endif; ?>
                            <?php if ($company_email): ?><br>Email: <?php echo $company_email; ?><?php endif; ?>
                            <?php if ($company_website): ?><br>Website: <?php echo $company_website; ?><?php endif; ?>
                            <?php if ($company_gstin): ?><br>GSTIN: <?php echo $company_gstin; ?><?php endif; ?>
                        </div>
                    </td>
                    <td style="width: 40%; text-align: right; vertical-align: top;">
                        <div style="font-size: 28px; font-weight: 800; color: #1e3a8a; text-transform: uppercase; margin-bottom: 5px;">INVOICE</div>
                        <div style="color: #64748b; font-size: 12px;">Original for Recipient</div>
                        <div style="margin-top: 15px;">
                            <span style="padding: 0.4em 0.8em; font-size: 0.8rem; border-radius: 4px;"><?php echo $status_text; ?></span>
                        </div>
                    </td>
                </tr>
            </table>

            <!-- Client & Invoice Details -->
            <table style="width: 100%; border-collapse: separate; border-spacing: 0; margin-bottom: 25px; position: relative; z-index: 1;">
                <tr>
                    <td style="width: 50%; border: 1px solid #e2e8f0; padding: 12px 15px; vertical-align: top; border-radius: 6px 0 0 6px; background-color: #f8fafc;">
                        <div style="font-size: 11px; text-transform: uppercase; color: #94a3b8; margin-bottom: 4px; font-weight: 500;">BILL TO:</div>
                        <div style="font-weight: 600; color: #334155; margin-bottom: 4px;"><?php echo $client_name; ?></div>
                        <div style='font-size: 13px; color: #475569; line-height:1.5;'>
                            <?php echo $client_address; ?>
                            <?php echo $client_gstin ? "<br>GSTIN: {$client_gstin}" : ''; ?>
                            <?php echo $client_state ? "<br>State: {$client_state}" . ($client_state_code ? " (Code: {$client_state_code})" : '') : ''; ?>
                        </div>
                    </td>
                    <td style="width: 50%; border: 1px solid #e2e8f0; padding: 12px 15px; vertical-align: top; font-size: 13px; line-height: 1.8; border-left: none; border-radius: 0 6px 6px 0;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 5px;"><strong style="color: #475569;">Invoice #:</strong> <strong style="color: #1e293b;"><?php echo $invoice_number_display; ?></strong></div>
                        <div style="display: flex; justify-content: space-between; margin-bottom: 5px;"><strong style="color: #475569;">Date:</strong> <span><?php echo $invoice_date_formatted; ?></span></div>
                        <?php if ($due_date_formatted): ?><div style="display: flex; justify-content: space-between; margin-bottom: 5px;"><strong style="color: #475569;">Due Date:</strong> <span><?php echo $due_date_formatted; ?></span></div><?php endif; ?>
                        <?php if (!empty($invoice['po_number'])): ?><div style="display: flex; justify-content: space-between; margin-bottom: 5px;"><strong style="color: #475569;">PO/Ref:</strong> <span><?php echo h($invoice['po_number']); ?></span></div><?php endif; ?>
                        <?php if (!empty($invoice['hsn_code'])): ?><div style="display: flex; justify-content: space-between; margin-bottom: 5px;"><strong style="color: #475569;">HSN/SAC:</strong> <span><?php echo h($invoice['hsn_code']); ?></span></div><?php endif; ?>
                    </td>
                </tr>
            </table>

            <!-- Items Table -->
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 13px; position: relative; z-index: 1;">
                <thead style="background-color: #f8fafc;"><tr>
                    <th style="padding: 8px; text-align:left; border-bottom: 2px solid #e2e8f0; width:5%;">#</th>
                    <th style="padding: 8px; text-align:left; border-bottom: 2px solid #e2e8f0;">Description</th>
                    <th style="padding: 8px; text-align:right; border-bottom: 2px solid #e2e8f0;">Quantity</th>
                    <th style="padding: 8px; text-align:right; border-bottom: 2px solid #e2e8f0;">Rate (₹)</th>
                    <th style="padding: 8px; text-align:right; border-bottom: 2px solid #e2e8f0;">Amount (₹)</th>
                </tr></thead>
                <tbody>
                <?php $item_index = 1; foreach ($items as $item): ?>
                    <tr style="border-bottom: 1px solid #f1f5f9;">
                        <td style="padding: 8px; text-align: center;"><?php echo $item_index++; ?></td>
                        <td style="padding: 8px; text-align: left; font-weight: 500; color: #334155;"><?php echo h($item['description']); ?></td>
                        <td style="padding: 8px; text-align: right;"><?php echo number_format((float)($item['quantity'] ?? 0), 2); ?></td>
                        <td style="padding: 8px; text-align: right;"><?php echo number_format((float)($item['rate'] ?? 0), 2); ?></td>
                        <td style="padding: 8px; text-align: right; font-weight: 500;"><?php echo number_format((float)($item['amount'] ?? 0), 2); ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($items)): ?> <tr><td colspan="5" style="text-align: center; padding: 20px; color: #94a3b8;">No items added.</td></tr> <?php endif; ?>
                </tbody>
            </table>

            <!-- Notes, Payment, Totals Table -->
            <table style="width: 100%; border-collapse: collapse; position: relative; z-index: 1;">
                <tr style="vertical-align: top;">
                    <td style="width: 58%; padding-right: 25px;">
                        <?php if ($final_notes): ?><div style='margin-bottom: 15px;'><div style='font-weight: 600; font-size: 12px; margin-bottom: 4px;'>Terms & Conditions:</div><div style='font-size: 11px; color: #64748b;'><?php echo $final_notes; ?></div></div><?php endif; ?>
                        <?php if ($selected_bank): ?>
                            <div style="margin-bottom: 15px;">
                                <div style="font-weight: 600; font-size: 12px; margin-bottom: 4px;">Payment Details:</div>
                                <div style="font-size: 11px; color: #64748b; line-height: 1.5;">
                                    <?php echo $display_bank_name ? "Bank: {$display_bank_name}<br>" : ''; ?>
                                    <?php echo $display_account_holder ? "Holder: {$display_account_holder}<br>" : ''; ?>
                                    <?php echo $display_account_number ? "A/C: {$display_account_number}<br>" : ''; ?>
                                    <?php echo $display_ifsc_code ? "IFSC: {$display_ifsc_code}<br>" : ''; ?>
                                    <?php echo $display_branch_name ? "Branch: {$display_branch_name}<br>" : ''; ?>
                                    <?php echo $display_upi_id ? "UPI: {$display_upi_id}" : ''; ?>
                                </div>
                                <?php if ($qr_code_data_uri): ?><div style='margin-top: 10px;'><img src='<?php echo $qr_code_data_uri; ?>' alt='UPI QR' style='max-width: 90px; max-height: 90px; border: 1px solid #e2e8f0;'></div><?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </td>
                    <td style="width: 42%;">
                        <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
                            <tr><td style="padding: 7px 12px;">Subtotal:</td><td style="padding: 7px 12px; text-align:right;">₹ <?php echo number_format($subtotal, 2); ?></td></tr>
                            <?php if ($discount_amount > 0): ?>
                                <tr><td style="padding: 7px 12px;">Discount (<?php echo number_format($discount_rate, 2); ?>%):</td><td style="padding: 7px 12px; text-align:right; color: #e67e22;">- ₹ <?php echo number_format($discount_amount, 2); ?></td></tr>
                                <tr style="font-weight: bold;"><td style="padding: 7px 12px; border-top: 1px solid #f1f5f9;">Taxable Amount:</td><td style="padding: 7px 12px; text-align:right; border-top: 1px solid #f1f5f9;">₹ <?php echo number_format($taxable_amount_display, 2); ?></td></tr>
                            <?php endif; ?>
                            <tr><td style="padding: 7px 12px;">CGST (<?php echo number_format($cgst_rate, 2); ?>%):</td><td style="padding: 7px 12px; text-align:right;">₹ <?php echo number_format($cgst_amount, 2); ?></td></tr>
                            <tr><td style="padding: 7px 12px;">SGST (<?php echo number_format($sgst_rate, 2); ?>%):</td><td style="padding: 7px 12px; text-align:right;">₹ <?php echo number_format($sgst_amount, 2); ?></td></tr>
                            <?php if ($convenience_fee > 0): ?><tr><td style='padding: 7px 12px;'>Convenience Fee:</td><td style='padding: 7px 12px; text-align:right;'>₹ <?php echo number_format($convenience_fee, 2); ?></td></tr><?php endif; ?>
                            <tr style="font-weight: 700; font-size: 1.1em; border-top: 2px solid #e2e8f0;"><td style="padding: 8px 12px;">Total Amount:</td><td style="padding: 8px 12px; text-align:right;">₹ <?php echo number_format($total_amount, 2); ?></td></tr>
                            <?php if ($advance_paid > 0): ?><tr style='color: #10b981;'><td style='padding: 7px 12px;'>Advance Paid:</td><td style='padding: 7px 12px; text-align:right;'>- ₹ <?php echo number_format($advance_paid, 2); ?></td></tr><?php endif; ?>
                            <tr style="font-weight: 700; font-size: 1.2em; border-top: 1px solid #e2e8f0; background-color:#f8fafc;"><td style="padding: 10px 12px;">Amount Due:</td><td style="padding: 10px 12px; text-align:right;">₹ <?php echo number_format($amount_due, 2); ?></td></tr>
                        </table>
                    </td>
                </tr>
            </table>

        </div> <!-- End Main Content Wrapper -->
        
        <!-- Footer (Absolutely Positioned) -->
        <div style="position: absolute; bottom: 25px; left: 25px; right: 25px; z-index: 1;">
            <div style="padding-top: 25px; border-top: 1px dashed #cbd5e1; display: flex; justify-content: flex-end; align-items: flex-end; position: relative;">
                <?php if ($stamp_data_uri): ?><img src='<?php echo $stamp_data_uri; ?>' alt='Stamp' style='position: absolute; bottom: 40px; right: 165px; max-width: 90px; max-height: 90px; opacity: 0.8; mix-blend-mode: multiply;'><?php endif; ?>
                <div style="text-align: right;">
                    <div style="font-size: 13px; color: #334155; font-weight: 600; margin-bottom: 50px;">For <?php echo $company_name; ?></div>
                    <div style="display: inline-block; border-top: 1px solid #64748b; padding-top: 5px; font-size: 11px; color: #64748b;">Authorised Signatory</div>
                </div>
            </div>
            <div style="margin-top: 25px; text-align: center; font-size: 11px; color: #94a3b8;">This is a computer-generated invoice.</div>
        </div>
    </div>
    <?php
    $html = ob_get_clean();
    return $html;
}
?>
```