<?php
// Include database configuration and ensure session is started via db_config.php
require_once 'db_config.php';

// Check if the user is logged in, if not redirect to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}

// Get user information
$user_id = $_SESSION["id"];
$username = $_SESSION["username"];

// --- Validate Invoice ID from GET parameter ---
$invoice_id = null;
if (isset($_GET['id']) && ctype_digit((string)$_GET['id']) && (int)$_GET['id'] > 0) {
    $invoice_id = (int)$_GET['id'];
} else {
    error_log("Invalid or missing invoice ID for edit request. User: $user_id");
    $_SESSION['error_message'] = 'Invalid invoice ID specified.';
    header("location: index.php#invoices"); // Redirect back to invoices tab
    exit;
}

// --- Fetch Invoice Data from Database ---
// Fetch invoice details, including client info, advance_paid, STATUS, AND bank_account_id
$sql_invoice = "SELECT i.*, c.name as client_name, c.address as client_address, c.gstin as client_gstin, c.state as client_state, c.state_code as client_state_code
                FROM invoices i
                LEFT JOIN clients c ON i.client_id = c.id
                WHERE i.id = :id AND i.user_id = :user_id";
$result_invoice = query($conn, $sql_invoice, ['id' => $invoice_id, 'user_id' => $user_id]);

// Verify invoice exists and belongs to the user
if (!$result_invoice || fetch_count($conn, $result_invoice) === 0) {
    error_log("Invoice ID $invoice_id not found or access denied for user: $user_id during edit.");
    $_SESSION['error_message'] = 'Invoice not found or access denied.';
    header("location: index.php#invoices"); // Redirect back to invoices tab
    exit;
}
$invoice = fetch_one($result_invoice);

// *** Store the currently selected bank ID for JS pre-selection ***
$selected_bank_id = $invoice['bank_account_id'] ?? null;


// --- Fetch Invoice Items ---
$sql_items = "SELECT * FROM invoice_items WHERE invoice_id = :invoice_id ORDER BY id ASC";
$result_items = query($conn, $sql_items, ['invoice_id' => $invoice_id]);
$invoice_items = [];
if ($result_items) { $invoice_items = fetch_all($result_items); }
else { error_log("Error fetching items for invoice $invoice_id, user $user_id: " . mysqli_error($conn)); }
if (empty($invoice_items)) {
    $invoice_items[] = ['id' => null, 'description' => '', 'quantity' => 1.00, 'rate' => 0.00, 'amount' => 0.00];
    error_log("Warning: Invoice ID $invoice_id (User $user_id) has no items associated. Displaying blank row for edit.");
}

// --- Fetch User's Company Details ---
$company = [];
$sql_company = "SELECT * FROM companies WHERE user_id = :user_id LIMIT 1";
$result_company = query($conn, $sql_company, ['user_id' => $user_id]);
if ($result_company && fetch_count($conn, $result_company) > 0) { $company = fetch_one($result_company); }

// Determine notes to display
$display_notes = !empty(trim($invoice['notes'] ?? '')) ? ($invoice['notes']) : ($company['default_notes'] ?? '');

// Retrieve session messages
$message = $_SESSION['message'] ?? ''; unset($_SESSION['message']);
$error = $_SESSION['error_message'] ?? ''; unset($_SESSION['error_message']);

// Helper functions
function h($text) { return htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8'); }
function format_field_value($value, $decimals = 2) { return is_numeric($value) ? number_format((float)$value, $decimals, '.', '') : h($value ?? ''); }

// Status options for dropdown
$status_options = [
    'unpaid' => 'Unpaid', 'paid' => 'Paid', 'partially_paid' => 'Partially Paid'
];
$current_status = strtolower(trim($invoice['status'] ?? 'unpaid')); // lowercase + trim + default
$allowed_statuses = array_keys($status_options);
if (!in_array($current_status, $allowed_statuses) || empty($current_status)) {
     error_log("Invalid/empty status '{$current_status}' for Invoice ID {$invoice_id}, User {$user_id}. Defaulting dropdown.");
     $current_status = 'unpaid';
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Invoice #<?php echo h($invoice['invoice_number']); ?> - Invoice Generator</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Link FontAwesome if using icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* --- FULL CSS STYLES from original edit_invoice.php / index.php --- */
        :root {
            --primary: #1e40af; --primary-light: #3b82f6; --primary-dark: #1e3a8a;
            --secondary: #64748b; --accent: #f59e0b; --danger: #ef4444; --success: #10b981;
            --warning: #f59e0b; --info: #3b82f6; --light: #f8fafc; --dark: #1e293b;
            --body-bg: #f1f5f9; --card-bg: #ffffff; --border-color: #e2e8f0;
            --text-primary: #334155; --text-secondary: #64748b; --text-muted: #94a3b8;
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            --radius-sm: 0.125rem; --radius: 0.25rem; --radius-md: 0.375rem; --radius-lg: 0.5rem; --radius-xl: 0.75rem;
            --status-paid-bg: #d1fae5; --status-paid-text: #065f46;
            --status-unpaid-bg: #fee2e2; --status-unpaid-text: #991b1b;
            --status-partial-bg: #fef3c7; --status-partial-text: #92400e;
            --status-default-bg: #e5e7eb; --status-default-text: #4b5563;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Poppins', sans-serif; background-color: var(--body-bg); color: var(--text-primary); line-height: 1.6; font-size: 14px; }
        .container { max-width: 1280px; margin: 0 auto; padding: 2rem; }
        .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; padding-bottom: 1rem; border-bottom: 1px solid var(--border-color); }
        .page-title h1 { font-size: 1.75rem; font-weight: 700; color: var(--primary); margin-bottom: 0.25rem; }
        .page-title p { color: var(--text-secondary); font-size: 0.875rem; }
        .user-menu { display: flex; align-items: center; gap: 1rem; }
        .user-name { font-weight: 500; }
        .card { background: var(--card-bg); border-radius: var(--radius-lg); box-shadow: var(--shadow-md); overflow: hidden; margin-bottom: 1.5rem; }
        .card-body { padding: 1.5rem; }
        .box { border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 1.25rem; margin-bottom: 1.5rem; }
        .box-title { font-size: 1rem; font-weight: 600; color: var(--primary); margin-bottom: 1rem; padding-bottom: 0.5rem; border-bottom: 1px solid var(--border-color); }
        .form-group { margin-bottom: 1rem; }
        .form-row { display: flex; flex-wrap: wrap; gap: 0.75rem; margin-bottom: 0.75rem; }
        .form-col { flex: 1; min-width: 180px; }
        label { display: block; font-weight: 500; margin-bottom: 0.5rem; color: var(--text-primary); font-size: 0.875rem; }
        input, select, textarea { width: 100%; padding: 0.625rem 0.75rem; border: 1px solid var(--border-color); border-radius: var(--radius); font-family: inherit; font-size: 0.875rem; color: var(--text-primary); background-color: white; transition: border-color 0.2s ease, box-shadow 0.2s ease; }
        input:focus, select:focus, textarea:focus { outline: none; border-color: var(--primary-light); box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.25); }
        input[readonly], input:disabled, select:disabled, textarea:disabled { background-color: var(--light); cursor: not-allowed; color: var(--text-muted); opacity: 0.8;}
        input[type="number"] { text-align: right;}
        textarea { resize: vertical; min-height: 60px; }
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 1rem; }
        table th, table td { padding: 0.75rem; border-bottom: 1px solid var(--border-color); vertical-align: middle; font-size: 0.875rem; line-height: 1.4; }
        table th { text-align: left; font-weight: 600; background-color: var(--light); border-bottom-width: 2px; color: var(--text-primary); white-space: nowrap; }
        table tr:last-child td { border-bottom: none; }
        table input, table select { border-radius: var(--radius-sm); padding: 0.5rem; font-size: 0.875rem; }
        #items-table input[name="amount[]"] { background-color: var(--light); }
        .totals-table input[type=number] { padding: 0.3rem 0.5rem; font-size: 0.875rem; max-width: 80px; display: inline-block; vertical-align: middle; margin-left: 5px; border-radius: var(--radius-sm); text-align: right;}
        .totals-table td { padding: 0.4rem 0; }
        .totals-table label { margin-bottom: 0; font-weight: 400; }
        .totals-table .amount-display { font-weight: 500; display:inline-block; min-width: 60px; text-align: right;} /* Add min-width */
        .totals-table .grand-total td { font-weight: 700; font-size: 1.1em; border-top: 1px solid var(--border-color); padding-top: 0.6rem; padding-bottom: 0; }
        .btn { display: inline-flex; align-items: center; justify-content: center; padding: 0.5rem 1rem; border-radius: var(--radius); font-weight: 500; cursor: pointer; transition: all 0.2s ease; border: 1px solid transparent; font-size: 0.875rem; text-decoration: none; white-space: nowrap; }
        .btn:disabled { background-color: var(--secondary) !important; opacity: 0.7; cursor: not-allowed; color: white !important; }
        .btn-primary { background-color: var(--primary); color: white; } .btn-primary:hover:not(:disabled) { background-color: var(--primary-dark); }
        .btn-success { background-color: var(--success); color: white; } .btn-success:hover:not(:disabled) { background-color: #0d9488; }
        .btn-danger { background-color: var(--danger); color: white; } .btn-danger:hover:not(:disabled) { background-color: #dc2626; }
        .btn-secondary { background-color: var(--secondary); color: white; } .btn-secondary:hover:not(:disabled) { background-color: #475569; }
        .btn-outline { background-color: transparent; border-color: var(--border-color); color: var(--text-primary); } .btn-outline:hover:not(:disabled) { border-color: var(--primary); color: var(--primary); background-color: rgba(30, 64, 175, 0.05); }
        .btn-sm { padding: 0.25rem 0.625rem; font-size: 0.75rem; }
        .btn-icon { display: inline-block; margin-right: 0.5rem; width: 1em; height: 1em; line-height: 1;}
        .btn-icon-only { padding: 0.375rem; font-size: 1rem; } .btn-icon-only .btn-icon { margin-right: 0; }
        .btn-group { display: inline-flex; gap: 0.25rem; }
        .action-buttons { display: flex; justify-content: flex-end; gap: 0.75rem; margin-top: 1.5rem; }
        .alert { padding: 0.75rem 1rem; border-radius: var(--radius); margin-bottom: 1.5rem; display: flex; align-items: center; font-size: 0.875rem; border-left-width: 4px; border-left-style: solid;} .alert-icon { margin-right: 0.75rem; font-size: 1.25rem; line-height: 1;}
        .alert-success { background-color: #f0fdf4; color: #15803d; border-color: var(--success); } .alert-danger { background-color: #fef2f2; color: #b91c1c; border-color: var(--danger); }
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0, 0, 0, 0.6); backdrop-filter: blur(3px); }
        .modal-content { background-color: #fff; margin: 5% auto; padding: 0; border: 1px solid #ccc; width: 90%; max-width: 900px; border-radius: var(--radius-lg); box-shadow: var(--shadow-lg); animation: fadeInModal 0.3s ease-out; overflow: hidden; }
        .modal-header { padding: 1rem 1.5rem; background-color: var(--primary); color: white; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--border-color); }
        .modal-title { font-weight: 600; font-size: 1.25rem; line-height: 1.2; }
        .modal-close { background: transparent; border: none; color: white; font-size: 1.8rem; font-weight: bold; cursor: pointer; line-height: 1; padding: 0.2rem; opacity: 0.8; } .modal-close:hover { opacity: 1; }
        .modal-body { padding: 1.5rem; max-height: 70vh; overflow-y: auto;}
        .modal-footer { padding: 1rem 1.5rem; background-color: var(--light); border-top: 1px solid var(--border-color); display: flex; justify-content: flex-end; gap: 0.75rem; }
        @keyframes fadeInModal { from { opacity: 0; transform: translateY(-20px); } to { opacity: 1; transform: translateY(0); } }
        #toast-container { position: fixed; top: 1rem; right: 1rem; z-index: 9999; width: 320px; }
        .toast { background-color: white; border-radius: var(--radius); box-shadow: var(--shadow-lg); margin-bottom: 0.75rem; overflow: hidden; border-left: 4px solid var(--dark); animation: slideInRight 0.3s ease-out, fadeOut 0.5s ease-out 4.5s forwards; }
        .toast-header { padding: 0.5rem 1rem; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--border-color); } .toast-title { font-weight: 600; font-size: 0.875rem; } .toast-close { background: transparent; border: none; font-size: 1.25rem; line-height: 1; cursor: pointer; color: var(--text-secondary); opacity: 0.7;} .toast-close:hover { opacity: 1; } .toast-body { padding: 0.75rem 1rem; font-size: 0.875rem;}
        .toast-success { border-left-color: var(--success); } .toast-error { border-left-color: var(--danger); } .toast-warning { border-left-color: var(--warning); }
        @keyframes slideInRight { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        @keyframes fadeOut { from { opacity: 1; } to { opacity: 0; } }
        .mt-1 { margin-top: 0.25rem; } .mt-2 { margin-top: 0.5rem; } .mt-4 { margin-top: 1rem; } .mb-1 { margin-bottom: 0.25rem; } .mb-2 { margin-bottom: 0.5rem; } .mb-4 { margin-bottom: 1rem; } .ml-4 { margin-left: 1rem; }
        .p-3 { padding: 0.75rem; } .p-4 { padding: 1rem; } .text-right { text-align: right; } .text-center { text-align: center; }
        .font-semibold { font-weight: 600; } .text-sm { font-size: 0.875rem; } .text-xs { font-size: 0.75rem; } .text-lg { font-size: 1.125rem; }
        .text-muted { color: var(--text-muted); } .text-danger { color: var(--danger); } .text-primary-dark { color: var(--primary-dark); } .text-success { color: var(--success); }
        .flex { display: flex; } .justify-between { justify-content: space-between; } .justify-end { justify-content: flex-end; } .items-center { align-items: center; } .items-end { align-items: flex-end; } .gap-2 { gap: 0.5rem; } .w-full { width: 100%; } .border-top { border-top: 1px solid var(--border-color); } .sr-only { position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip: rect(0, 0, 0, 0); white-space: nowrap; border-width: 0; }
        /* Status Badge Styles (used in preview modal) */
        .status-badge { display: inline-block; padding: 0.3em 0.7em; font-size: 0.7rem; font-weight: 600; line-height: 1; text-align: center; white-space: nowrap; vertical-align: middle; border-radius: var(--radius-md); text-transform: uppercase; letter-spacing: 0.5px; border: 1px solid transparent; }
        .status-paid { background-color: var(--status-paid-bg); color: var(--status-paid-text); border-color: #6ee7b7; }
        .status-unpaid { background-color: var(--status-unpaid-bg); color: var(--status-unpaid-text); border-color: #fca5a5; }
        .status-partially_paid { background-color: var(--status-partial-bg); color: var(--status-partial-text); border-color: #fcd34d; }
        .status-default { background-color: var(--status-default-bg); color: var(--status-default-text); border-color: #d1d5db; }
        @media (max-width: 768px) { .container { padding: 1rem; } .page-header { flex-direction: column; align-items: flex-start; gap: 0.5rem;} .user-menu { width: 100%; justify-content: flex-end; } .form-col { flex-basis: 100%; min-width: 160px; } .action-buttons { flex-direction: column; gap: 0.5rem; } .action-buttons .btn { width: 100%; } .modal-content { width: 95%; margin: 5% auto;} #toast-container { width: 90%; right: 5%; left: 5%; } }
        /* Print specific styles */
        @media print {
            body { background-color: white !important; color: black !important; font-size: 10pt !important; } /* Explicitly set print defaults */
            .container, .page-header, .action-buttons, #toast-container, .alert, .user-menu { display: none !important; } /* Hide non-print elements */
            .card, .card-body, .box { box-shadow: none !important; border: none !important; padding: 0 !important; margin: 0 !important; background: none !important; }
            button.remove-item { display: none !important; } /* Hide remove item buttons in print */
             /* Target the form specifically for visibility control IF needed, otherwise it's handled by general hiding */
            /* #invoice-form { display:none !important;} */ /* Generally hide the form */

             /* Force ONLY the PREVIEW MODAL CONTENT to show when printing */
             body > *:not(#invoice-preview-modal) { display: none !important; } /* Hide everything except the preview modal */
            #invoice-preview-modal { display: block !important; position: absolute !important; left: 0; top: 0; width: 100% !important; height: auto !important; overflow: visible !important; background: none !important; padding: 0 !important; z-index: 9999;}
             #invoice-preview-modal .modal-content { margin: 0 !important; padding: 0 !important; box-shadow: none !important; border: none !important; max-width: 100% !important; border-radius: 0 !important; }
             #invoice-preview-modal .modal-header, #invoice-preview-modal .modal-footer { display: none !important; }
             #invoice-preview-modal .modal-body { padding: 0 !important; max-height: none !important; overflow: visible !important; }
             #invoice-preview-content > div { max-width: 100% !important; margin: 0 !important; padding: 0 !important; border: none !important; box-shadow: none !important; font-size: 10pt; } /* Target the invoice content div */
             #invoice-preview-content table th, #invoice-preview-content table td { font-size: 9pt !important; }
             #invoice-preview-content .status-badge { display: none !important; } /* Hide status badge */
            @page { size: A4; margin: 1cm; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="page-header">
            <div class="page-title">
                <h1>Edit Invoice</h1>
                <p>Modify invoice #<?php echo h($invoice['invoice_number']); ?></p>
            </div>
            <div class="user-menu">
                 <a href="index.php#invoices" class="btn btn-outline btn-sm">← Back to Dashboard</a>
                <span class="user-name ml-4">User: <?php echo h($username); ?></span>
                <a href="logout.php" class="btn btn-outline btn-sm">Sign Out</a>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                 <?php if (!empty($message)): ?> <div class="alert alert-success"><div class="alert-icon">✓</div><div><?php echo h($message); ?></div></div> <?php endif; ?>
                 <?php if (!empty($error)): ?> <div class="alert alert-danger"><div class="alert-icon">✗</div><div><?php echo h($error); ?></div></div> <?php endif; ?>

                <!-- Updated Form Block for edit_invoice.php -->
<form id="invoice-form" onsubmit="return false;">
    <input type="hidden" name="invoice_id" value="<?php echo h($invoice_id); ?>">

    <!-- Invoice Details Box -->
    <div class="box">
        <h3 class="box-title">Invoice Details</h3>
        <div class="form-row">
            <div class="form-col">
                <label for="invoice_number_display">Invoice Number</label>
                <input type="hidden" name="invoice_number" value="<?php echo h($invoice['invoice_number']); ?>">
                <input type="text" id="invoice_number_display" value="<?php echo h($invoice['invoice_number']); ?>" readonly disabled class="text-muted">
                <small class="text-muted text-xs">Cannot be changed after creation.</small>
            </div>
            <div class="form-col">
                <label for="invoice_date">Invoice Date <span class="text-danger">*</span></label>
                <input type="date" id="invoice_date" name="invoice_date" value="<?php echo h($invoice['invoice_date']); ?>" required>
            </div>
             <div class="form-col">
                <label for="status">Invoice Status <span class="text-danger">*</span></label>
                <select id="status" name="status" required>
                    <?php foreach ($status_options as $value => $text): ?>
                        <option value="<?php echo h($value); ?>" <?php echo ($current_status === $value) ? 'selected' : ''; ?>>
                            <?php echo h($text); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <small class="text-muted text-xs">Set the current status. It will be saved.</small>
            </div>
        </div>
        <div class="form-row">
             <div class="form-col">
                <label for="due_date">Due Date</label>
                <input type="date" id="due_date" name="due_date" value="<?php echo h($invoice['due_date'] ?? ''); ?>">
            </div>
            <div class="form-col">
                <label for="hsn_code">HSN/SAC Code</label>
                <input type="text" id="hsn_code" name="hsn_code" value="<?php echo h($invoice['hsn_code'] ?? ''); ?>">
            </div>
            <div class="form-col">
                <label for="po_number">PO/Order Ref</label>
                <input type="text" id="po_number" name="po_number" value="<?php echo h($invoice['po_number'] ?? ''); ?>">
            </div>
        </div>
    </div>

    <!-- Client & Bank Info Box -->
    <div class="box">
        <h3 class="box-title">Client & Bank Information</h3>
         <div class="form-group">
             <input type="hidden" name="client_id" value="<?php echo h($invoice['client_id']); ?>">
             <label for="client_display_name">Client Name</label>
             <input type="text" id="client_display_name" value="<?php echo h($invoice['client_name']); ?>" disabled class="text-muted">
             <small class="text-muted text-xs">Client cannot be changed after invoice creation.</small>
         </div>
        <div id="client-details" class="mt-2 mb-4">
             <div class="p-3" style="background-color: var(--light); border-radius: var(--radius); border: 1px solid var(--border-color);">
                 <div class="flex justify-between flex-wrap gap-2">
                     <div><div class="font-semibold text-primary-dark text-sm mb-1"><?php echo h($invoice['client_name']); ?></div><div class="text-xs text-muted"><?php echo nl2br(h($invoice['client_address'] ?? 'No address provided')); ?></div></div>
                    <div class="text-right text-xs text-muted"><div>GSTIN: <span class="font-medium text-primary"><?php echo h($invoice['client_gstin'] ?: '-'); ?></span></div><div>State: <span class="font-medium text-primary"><?php echo h($invoice['client_state'] ?: '-'); ?><?php if($invoice['client_state_code']) echo ' (' . h($invoice['client_state_code']) . ')'; ?></span></div></div>
                 </div>
             </div>
        </div>
         <!-- Bank Selection Dropdown (From your previous code) -->
         <div class="form-group">
             <label for="bank_account_id_edit">Select Bank Account (Optional)</label>
             <select id="bank_account_id_edit" name="bank_account_id"> <!-- Keep name="bank_account_id" -->
                 <option value="">-- No Bank Details on Invoice --</option>
                 <!-- Options loaded by JS -->
             </select>
             <div id="bank-loading-edit" style="display: none; /* ... */">Loading banks...</div>
             <small class="text-muted text-xs">Select the bank whose details should appear on this invoice.</small>
         </div>
         <!-- END Bank Selection -->
    </div>

    <!-- Items Box -->
    <div class="box">
        <h3 class="box-title">Invoice Items <span class="text-danger">*</span></h3>
        <div class="table-responsive">
            <table id="items-table">
                 <thead> <tr><th width="45%">Description</th><th width="15%">Quantity</th><th width="15%">Rate (₹)</th><th width="15%">Amount (₹)</th><th width="10%" class="text-center">Action</th></tr> </thead>
                 <tbody id="invoice-items">
                    <?php foreach ($invoice_items as $item): ?>
                     <tr>
                         <td><input type="text" name="description[]" value="<?php echo h($item['description']); ?>" required class="item-description" placeholder="Item or service description"></td>
                         <td><input type="number" name="quantity[]" value="<?php echo format_field_value($item['quantity'], 2); ?>" min="0" step="any" required class="item-quantity"></td>
                         <td><input type="number" name="rate[]" value="<?php echo format_field_value($item['rate'], 2); ?>" min="0" step="0.01" required class="item-rate"></td>
                         <td><input type="text" name="amount[]" value="<?php echo format_field_value($item['amount'] ?? 0, 2); ?>" readonly tabindex="-1" class="item-amount text-right text-muted"></td>
                        <td class="text-center"><button type="button" class="btn btn-danger btn-sm btn-icon-only remove-item" title="Remove Item">×</button></td>
                    </tr>
                    <?php endforeach; ?>
                 </tbody>
            </table>
         </div>
         <button type="button" class="btn btn-outline btn-sm mt-2" onclick="addItem()"> <i class="fas fa-plus btn-icon"></i> Add Item </button>

         <div class="flex justify-end mt-4">
            <div style="width: 100%; max-width: 350px;">
                 <!-- *** UPDATED TOTALS TABLE with DISCOUNT ROW *** -->
                 <table class="w-full text-sm totals-table">
                    <tr><td class="text-muted">Subtotal:</td><td class="text-right">₹ <span id="subtotal" class="amount-display font-semibold">0.00</span></td></tr>
                     <!-- *** NEW DISCOUNT ROW *** -->
                     <tr>
                        <td class="text-muted"><label for="discount_rate">Discount (%):</label><input type="number" id="discount_rate" name="discount_rate" value="<?php echo format_field_value($invoice['discount_rate'] ?? 0, 2); ?>" min="0" max="100" step="0.01"></td>
                        <td class="text-right" style="color:#e67e22; font-weight:500;">- ₹ <span id="discount-amount" class="amount-display">0.00</span></td>
                     </tr>
                     <!-- *** END NEW DISCOUNT ROW *** -->
                    <tr><td><label for="cgst_rate">CGST (%):</label><input type="number" id="cgst_rate" name="cgst_rate" value="<?php echo format_field_value($invoice['cgst_rate'] ?? 0, 2); ?>" min="0" step="0.01"></td><td class="text-right">₹ <span id="cgst-amount" class="amount-display">0.00</span></td></tr>
                    <tr><td><label for="sgst_rate">SGST (%):</label><input type="number" id="sgst_rate" name="sgst_rate" value="<?php echo format_field_value($invoice['sgst_rate'] ?? 0, 2); ?>" min="0" step="0.01"></td><td class="text-right">₹ <span id="sgst-amount" class="amount-display">0.00</span></td></tr>
                    <tr><td><label for="convenience_fee">Conv. Fee:</label></td><td class="text-right"><span class="text-xs mr-1">₹</span><input type="number" id="convenience_fee" name="convenience_fee" value="<?php echo format_field_value($invoice['convenience_fee'] ?? 0, 2); ?>" min="0" step="0.01"></td></tr>
                    <tr class="border-top mt-1 pt-1"><td class="font-semibold">Total:</td><td class="text-right font-semibold">₹ <span id="total-amount" class="amount-display">0.00</span></td></tr>
                    <tr><td><label for="advance_paid">Advance Paid:</label></td><td class="text-right"><span class="text-xs mr-1">₹</span><input type="number" id="advance_paid" name="advance_paid" value="<?php echo format_field_value($invoice['advance_paid'] ?? 0, 2); ?>" min="0" step="0.01"></td></tr>
                    <tr class="grand-total"><td>Amount Due:</td><td class="text-right">₹ <span id="amount-due" class="amount-display">0.00</span></td></tr>
                 </table>
                  <!-- *** END UPDATED TOTALS TABLE *** -->
             </div>
         </div>
     </div>

    <!-- Notes Box -->
    <div class="box">
          <h3 class="box-title">Notes / Terms</h3>
         <div class="form-group mb-0">
             <label for="notes" class="sr-only">Notes / Terms & Conditions</label>
            <textarea id="notes" name="notes" rows="3" placeholder="Notes..."><?php echo h($display_notes); ?></textarea>
            <small class="text-muted text-xs">Uses Company Default if blank.</small>
         </div>
     </div>

    <!-- Action Buttons -->
    <div class="action-buttons">
        <a href="index.php#invoices" class="btn btn-outline"><i class="fas fa-times btn-icon"></i>Cancel</a>
         <button type="button" class="btn btn-secondary" onclick="previewInvoice()"><i class="fas fa-search btn-icon"></i>Preview Changes</button>
         <button type="button" class="btn btn-success" id="update-invoice-btn" onclick="updateInvoice(this)"><i class="fas fa-save btn-icon"></i>Save Updates</button>
     </div>
 </form>
<!-- End Form Block -->
            </div>
        </div>
    </div> <!-- End Container -->

    <!-- Invoice Preview Modal -->
    <div id="invoice-preview-modal" class="modal">
         <div class="modal-content"> <div class="modal-header"> <h2 class="modal-title">Invoice Preview</h2> <button type="button" class="modal-close" onclick="closeInvoicePreviewModal()" aria-label="Close">×</button> </div> <div class="modal-body"><div id="invoice-preview-content"><p class="text-center text-muted p-4">Loading preview...</p></div></div> <div class="modal-footer"> <button type="button" class="btn btn-outline" onclick="printInvoice()"><i class="fas fa-print btn-icon"></i>Print</button> <button type="button" class="btn btn-secondary" onclick="closeInvoicePreviewModal()"><i class="fas fa-times btn-icon"></i>Close</button> </div> </div>
    </div>

    <!-- Toast Container -->
    <div id="toast-container"></div>

    <!-- JavaScript -->
    <script>
        // --- DOM Elements Cache ---
        const invoiceItemsTbody = document.getElementById('invoice-items');
        const previewModal = document.getElementById('invoice-preview-modal');
        const toastContainer = document.getElementById('toast-container');
        const cgstRateInput = document.getElementById('cgst_rate');
        const sgstRateInput = document.getElementById('sgst_rate');
        const convenienceFeeInput = document.getElementById('convenience_fee');
        const advancePaidInput = document.getElementById('advance_paid');
        const subtotalEl = document.getElementById('subtotal');
        const cgstAmountEl = document.getElementById('cgst-amount');
        const sgstAmountEl = document.getElementById('sgst-amount');
        const totalAmountEl = document.getElementById('total-amount');
        const amountDueEl = document.getElementById('amount-due');
        const bankSelectEdit = document.getElementById('bank_account_id_edit'); // Specific ID for bank select

        // --- Utility Functions ---
        function openModal(modalEl) { if(modalEl) modalEl.style.display = 'block'; }
        function closeModal(modalEl) { if(modalEl) modalEl.style.display = 'none'; }
        function closeInvoicePreviewModal() { closeModal(previewModal); }
        function escapeHtml(unsafe) { /* ... copy from index.php ... */ if (typeof unsafe !== 'string') return unsafe ?? ''; const map = { '&': '&', '<': '<', '>': '>', '"': '"', "'": '&#039' }; return unsafe.replace(/[&<>"']/g, m => map[m]); }
        function showToast(title, message, type = 'info') { /* ... copy from index.php ... */ const t=document.createElement('div');t.className=`toast toast-${type}`;let i=type==='success'?'✓':type==='error'?'✗':type==='warning'?'⚠️':'ℹ️';t.innerHTML=`<div class="toast-header"><span class="toast-title">${i} ${escapeHtml(title)}</span><button type="button" class="toast-close" onclick="this.parentElement.parentElement.remove()">×</button></div><div class="toast-body">${escapeHtml(message)}</div>`;if(toastContainer)toastContainer.appendChild(t);document.getElementById('php-flash-message-success')?.remove();document.getElementById('php-flash-message-error')?.remove(); }
        function roundTo(n, digits = 2) { /* ... copy from index.php ... */ if (isNaN(n) || n === null) return 0; const m = Math.pow(10, digits); const v = parseFloat((n * m).toFixed(11)); return Math.round(v) / m; }

        // --- Invoice Item Management ---
        function addItem() { /* ... copy from index.php ... */ if (!invoiceItemsTbody) return; const tr = invoiceItemsTbody.insertRow(); tr.innerHTML = `<td><input type="text" name="description[]" placeholder="Item or service description" required class="item-description"></td><td><input type="number" name="quantity[]" value="1.00" min="0" step="any" required class="item-quantity"></td><td><input type="number" name="rate[]" value="0.00" min="0" step="0.01" required class="item-rate"></td><td><input type="text" name="amount[]" value="0.00" readonly tabindex="-1" class="item-amount text-right text-muted"></td><td class="text-center"><button type="button" class="btn btn-danger btn-sm btn-icon-only remove-item" title="Remove Item">×</button></td>`; tr.querySelector('.item-description')?.focus(); updateTotals(); }
        function removeItem(button) { /* ... copy from index.php ... */ const row = button.closest('tr'); if (!row || !invoiceItemsTbody) return; if (invoiceItemsTbody.rows.length > 1) { row.remove(); } else { showToast('Info', 'Invoice must have at least one item.', 'info'); row.querySelector('input[name="description[]"]').value = ''; row.querySelector('input[name="quantity[]"]').value = '1.00'; row.querySelector('input[name="rate[]"]').value = '0.00'; updateItemAmount(row.querySelector('.item-rate')); } updateTotals(); }
        if (invoiceItemsTbody) { /* Event listeners */ invoiceItemsTbody.addEventListener('input', function(e) { if (e.target?.classList.contains('item-quantity') || e.target?.classList.contains('item-rate')) { updateItemAmount(e.target); } }); invoiceItemsTbody.addEventListener('click', function(e) { if (e.target?.classList.contains('remove-item')) { removeItem(e.target); } }); }
        function updateItemAmount(inputEl) { /* ... copy from index.php ... */ const row = inputEl.closest('tr'); if (!row) return; const qty = parseFloat(row.querySelector('.item-quantity')?.value) || 0; const rate = parseFloat(row.querySelector('.item-rate')?.value) || 0; const amt = roundTo(qty * rate); const amtInput = row.querySelector('.item-amount'); if(amtInput) amtInput.value = amt.toFixed(2); updateTotals(); }

        // --- Total Calculations ---
        // --- updateTotals Function (for edit_invoice.php) - Includes Discount ---
function updateTotals() {
    // --- Get Elements (scoped within function is good) ---
    const invoiceItemsTbody = document.getElementById('invoice-items'); // Needed to read items
    const subtotalEl = document.getElementById('subtotal');
    const discountRateInput = document.getElementById('discount_rate'); // *** NEW: Get discount input ***
    const discountAmountEl = document.getElementById('discount-amount'); // *** NEW: Get discount amount span ***
    const cgstRateInput = document.getElementById('cgst_rate');
    const cgstAmountEl = document.getElementById('cgst-amount');
    const sgstRateInput = document.getElementById('sgst_rate');
    const sgstAmountEl = document.getElementById('sgst-amount');
    const convenienceFeeInput = document.getElementById('convenience_fee');
    const totalAmountEl = document.getElementById('total-amount');
    const advancePaidInput = document.getElementById('advance_paid');
    const amountDueEl = document.getElementById('amount-due');

    // Exit if essential elements are missing
    if (!invoiceItemsTbody || !subtotalEl || !discountAmountEl || !cgstAmountEl || !sgstAmountEl || !totalAmountEl || !amountDueEl) {
        console.error("One or more total display elements not found!");
        return;
    }

    let currentSubtotal = 0;
    invoiceItemsTbody.querySelectorAll('tr').forEach(row => {
        // Use item amount input directly, no need to recalculate items here, just sum their amounts
         const amountInput = row.querySelector('.item-amount');
         if (amountInput) {
            currentSubtotal += parseFloat(amountInput.value) || 0;
         }
     });
    currentSubtotal = roundTo(currentSubtotal); // Use your roundTo helper

    // --- Get Input Values ---
    const discountRate = discountRateInput ? parseFloat(discountRateInput.value) || 0 : 0;
    const cgstRate = cgstRateInput ? parseFloat(cgstRateInput.value) || 0 : 0;
    const sgstRate = sgstRateInput ? parseFloat(sgstRateInput.value) || 0 : 0;
    const convenienceFee = convenienceFeeInput ? Math.max(0, parseFloat(convenienceFeeInput.value) || 0) : 0;
    const advancePaid = advancePaidInput ? Math.max(0, parseFloat(advancePaidInput.value) || 0) : 0;

    // --- Perform Calculations with Discount ---
    const calculatedDiscountAmount = roundTo((currentSubtotal * discountRate) / 100);
    const taxableAmount = roundTo(currentSubtotal - calculatedDiscountAmount);
    const calculatedCgstAmount = roundTo((taxableAmount * cgstRate) / 100);
    const calculatedSgstAmount = roundTo((taxableAmount * sgstRate) / 100);
    const calculatedTotalAmount = roundTo(taxableAmount + calculatedCgstAmount + calculatedSgstAmount + convenienceFee);
    const calculatedAmountDue = roundTo(Math.max(0, calculatedTotalAmount - advancePaid));

    // --- Update Display Elements ---
    subtotalEl.textContent = currentSubtotal.toFixed(2);
    discountAmountEl.textContent = calculatedDiscountAmount.toFixed(2); // Update discount span
    cgstAmountEl.textContent = calculatedCgstAmount.toFixed(2);
    sgstAmountEl.textContent = calculatedSgstAmount.toFixed(2);
    totalAmountEl.textContent = calculatedTotalAmount.toFixed(2);
    amountDueEl.textContent = calculatedAmountDue.toFixed(2);
}
// --- End updateTotals Function ---
        cgstRateInput?.addEventListener('input', updateTotals);
sgstRateInput?.addEventListener('input', updateTotals);
convenienceFeeInput?.addEventListener('input', updateTotals);
advancePaidInput?.addEventListener('input', updateTotals);
document.getElementById('discount_rate')?.addEventListener('input', updateTotals); // <<<--- ADD THIS LINE

        // --- Bank Dropdown Loading (Specific for Edit Page) ---
        function loadBankDropdownEdit(selectElementId, bankToSelect) { /* ... copied/adapted from previous response ... */ const selectEl = document.getElementById(selectElementId); const loadingEl = document.getElementById('bank-loading-edit'); if (!selectEl) return; if(loadingEl) loadingEl.style.display = 'inline-block'; selectEl.disabled = true; selectEl.innerHTML = '<option value="">Loading...</option>';
            fetch('api.php?action=get_banks').then(r => r.json()).then(d => { selectEl.innerHTML = '<option value="">-- No Bank Details on Invoice --</option>'; if (d.success && d.banks?.length > 0) { d.banks.forEach(b => { const accNum = b.account_number || ''; const last4 = accNum.length > 4 ? '...'+accNum.slice(-4) : accNum; const txt = `${escapeHtml(b.bank_name)} (${last4||'No A/C'})`; const opt = new Option(txt, b.id); selectEl.appendChild(opt); }); if (bankToSelect && selectEl.querySelector(`option[value="${bankToSelect}"]`)) { selectEl.value = bankToSelect; } else { selectEl.value = ""; } } else if (!d.success) { selectEl.innerHTML = '<option value="">Error loading banks</option>'; console.error("Bank dropdown error:", d.message); } }).catch(e => { console.error('Bank fetch error:', e); selectEl.innerHTML = '<option value="">Network error</option>'; }).finally(() => { if(loadingEl) loadingEl.style.display = 'none'; selectEl.disabled = false; }); }

        // --- Form Actions ---
        function updateInvoice(button) { /* Uses API, sends full form including bank_account_id */
            const form = document.getElementById('invoice-form'); if (!form || !form.checkValidity()) { showToast('Warning', 'Correct invalid fields.', 'warning'); form?.querySelector(':invalid')?.focus(); form?.reportValidity(); return; } if (!invoiceItemsTbody) { showToast('Error', 'Cannot find items table.', 'error'); return; } let hasValidItem = Array.from(invoiceItemsTbody.querySelectorAll('.item-description')).some(input => input.value.trim() !== ''); if (!hasValidItem) { showToast('Error', 'Must have one item with description.', 'error'); invoiceItemsTbody.querySelector('.item-description')?.focus(); return; }
            const formData = new FormData(form); formData.append('action', 'save_invoice'); const originalButtonText = button.textContent; button.disabled = true; button.textContent = 'Saving...';
            fetch('api.php', { method: 'POST', body: formData }).then(r => { if (!r.ok) { return r.json().then(err => { throw new Error(err.message || `HTTP ${r.status}`); }).catch(() => { throw new Error(`HTTP ${r.status} ${r.statusText}`); }); } return r.json(); }).then(data => { if (data.success) { localStorage.setItem('flashMessage', JSON.stringify({type: 'success', message: data.message || 'Invoice updated.'})); window.location.href = 'index.php#invoices'; } else { showToast('Error', data.message || 'Update failed.', 'error'); button.disabled = false; button.textContent = originalButtonText; } }).catch(error => { console.error('Update Error:', error); showToast('Error', `Error: ${error.message}.`, 'error'); button.disabled = false; button.textContent = originalButtonText; }); }

        function previewInvoice() { /* Uses API, sends full form including selected bank_account_id and status */
            const form = document.getElementById('invoice-form'); if (!form || !form.checkValidity()) { showToast('Warning', 'Correct invalid fields first.', 'warning'); form?.querySelector(':invalid')?.focus(); form?.reportValidity(); return; } if (!invoiceItemsTbody) { showToast('Error', 'No items table.', 'error'); return; } let hasValidItem = Array.from(invoiceItemsTbody.querySelectorAll('.item-description')).some(input => input.value.trim() !== ''); if (!hasValidItem) { showToast('Error', 'Add an item first.', 'error'); return; }
            const formData = new FormData(form); formData.append('action', 'preview_invoice');
             formData.append('subtotal', subtotalEl?.textContent || '0.00'); formData.append('cgst_amount', cgstAmountEl?.textContent || '0.00'); formData.append('sgst_amount', sgstAmountEl?.textContent || '0.00'); formData.append('total_amount', totalAmountEl?.textContent || '0.00'); // Note: status is already in formData from select[name="status"]
             const previewContentDiv = document.getElementById('invoice-preview-content'); if(previewContentDiv) previewContentDiv.innerHTML = '<p class="text-center text-muted p-4">Generating preview...</p>'; openModal(previewModal);
             fetch('api.php', { method: 'POST', body: formData }).then(r => { if (!r.ok) { return r.json().then(err => { throw new Error(err.message || `HTTP ${r.status}`); }).catch(() => { throw new Error(`HTTP error ${r.status}`); }); } return r.json(); }).then(data => { if (data.success) { if(previewContentDiv) previewContentDiv.innerHTML = data.html; } else { showToast('Error', data.message || 'Preview failed.', 'error'); if(previewContentDiv) previewContentDiv.innerHTML = `<p class="text-center text-danger p-4">Error: ${escapeHtml(data.message || 'Could not generate preview.')}</p>`; } }).catch(error => { console.error('Preview Error:', error); showToast('Error', `Preview failed: ${error.message}`, 'error'); if(previewContentDiv) previewContentDiv.innerHTML = '<p class="text-center text-danger p-4">Network error.</p>'; }); }

        function printInvoice() { /* ... full printInvoice function using iframe (same as index.php) ... */
            const previewContentEl = document.getElementById('invoice-preview-content'); if (!previewModal || previewModal.style.display !== 'block' || !previewContentEl || !previewContentEl.querySelector('table')) { showToast('Info', 'Please generate a preview first.', 'info'); return; } const iframe = document.createElement('iframe'); iframe.style.cssText = 'position:fixed;top:-9999px;left:-9999px;width:0;height:0;border:0;'; document.body.appendChild(iframe); const previewContentHTML = previewContentEl.innerHTML; let styles = ''; try { styles = Array.from(document.styleSheets).map(sheet => { try { return Array.from(sheet.cssRules ?? []).map(rule => rule.cssText).join(''); } catch (e) { return ''; } }).join('\n'); } catch (e) { console.warn("Could not gather styles for print:", e); } const printSpecificStyles = `@media print{ body {-webkit-print-color-adjust: exact; print-color-adjust: exact; font-size: 10pt !important; background-color: white !important; color: black !important; } @page{size: A4; margin: 1cm;} html,body{margin:0; padding:0;} .status-badge, [onclick], button {display:none !important;} table, tr, td, th { font-size: 9pt !important; } }`; const doc = iframe.contentWindow.document; doc.open(); doc.write(`<!DOCTYPE html><html><head><title>Invoice Print</title><link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet"><style>${styles} ${printSpecificStyles}</style></head><body>${previewContentHTML}</body></html>`); doc.close(); setTimeout(() => { try { iframe.contentWindow.focus(); iframe.contentWindow.print(); } catch (e) { console.error("Print failed:", e); showToast('Error', 'Printing failed. Use browser print option.', 'error');} setTimeout(() => { document.body.removeChild(iframe); }, 1000); }, 350); }

        // --- Initial Page Load ---
        document.addEventListener('DOMContentLoaded', function() {
            updateTotals(); // Calculate totals on load
            const invoiceCurrentBankId = <?php echo json_encode($selected_bank_id); ?>; // Get bank ID from PHP
            loadBankDropdownEdit('bank_account_id_edit', invoiceCurrentBankId); // Load banks and select current

            window.addEventListener('click', (event) => { if (event.target === previewModal) { closeInvoicePreviewModal(); } }); // Close modal on outside click
            setTimeout(() => { document.querySelector('.alert-success')?.remove(); document.querySelector('.alert-danger')?.remove(); }, 7000); // Clear PHP alerts
        });
    </script>
</body>
</html>