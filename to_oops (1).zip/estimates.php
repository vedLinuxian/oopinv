<?php
// Include database configuration and start session
require_once 'db_config.php';

// Check if the user is logged in, redirect if not
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}

// Get user information
$user_id = $_SESSION["id"];
$username = $_SESSION["username"];

// Fetch User's company details for default notes etc.
$company = [];
$sql_get_company = "SELECT default_notes FROM companies WHERE user_id = :user_id LIMIT 1";
$result_get_company = query($conn, $sql_get_company, ['user_id' => $user_id]);
if ($result_get_company) $company = fetch_one($result_get_company);

// This function is defined safely within this file.
function generateNextEstimateNumber($conn, $user_id) {
    $current_month = (int)date('n'); $current_year = (int)date('Y');
    if ($current_month >= 4) { $start_yy = date('y'); $end_yy = substr((string)($current_year + 1), -2); } 
    else { $start_yy = substr((string)($current_year - 1), -2); $end_yy = date('y'); }
    $fy_prefix = "EST-" . $start_yy . "-" . $end_yy . "-";
    $sql = "SELECT estimate_number FROM estimates WHERE user_id = :user_id AND estimate_number LIKE :prefix ORDER BY estimate_number DESC LIMIT 1";
    $result = query($conn, $sql, ['user_id' => $user_id, 'prefix' => $fy_prefix . '%']);
    $nextNumber = 1;
    if ($result && fetch_count($conn, $result) > 0) {
        $lastEstimate = fetch_one($result);
        if (preg_match('/-(\d{4})$/', $lastEstimate['estimate_number'], $matches)) {
            $nextNumber = (int)$matches[1] + 1;
        } else {
            $sql_count = "SELECT COUNT(*) as count FROM estimates WHERE user_id = :user_id AND estimate_number LIKE :prefix";
            if($res_count = query($conn, $sql_count, ['user_id' => $user_id, 'prefix' => $fy_prefix . '%'])) {
                $count_data = fetch_one($res_count);
                $nextNumber = isset($count_data['count']) ? (int)$count_data['count'] + 1 : 1;
            }
        }
    }
    return $fy_prefix . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);
}
$next_estimate_num_display = generateNextEstimateNumber($conn, $user_id);
function h($text) { return htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estimates - GST Invoice Generator</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- NEW: html2pdf.js library for reliable PDF downloading -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <style>
        :root{--primary:#1e40af;--primary-light:#3b82f6;--primary-dark:#1e3a8a;--secondary:#64748b;--accent:#f59e0b;--danger:#ef4444;--success:#10b981;--warning:#f59e0b;--info:#3b82f6;--light:#f8fafc;--dark:#1e293b;--body-bg:#f1f5f9;--card-bg:#ffffff;--border-color:#e2e8f0;--text-primary:#334155;--text-secondary:#64748b;--text-muted:#94a3b8;--shadow-sm:0 1px 2px 0 rgba(0,0,0,0.05);--shadow:0 1px 3px 0 rgba(0,0,0,0.1),0 1px 2px 0 rgba(0,0,0,0.06);--shadow-md:0 4px 6px -1px rgba(0,0,0,0.1),0 2px 4px -1px rgba(0,0,0,0.06);--shadow-lg:0 10px 15px -3px rgba(0,0,0,0.1),0 4px 6px -2px rgba(0,0,0,0.05);--radius-sm:0.125rem;--radius:0.25rem;--radius-md:0.375rem;--radius-lg:0.5rem;--radius-xl:0.75rem;--status-paid-bg:#d1fae5;--status-paid-text:#065f46;--status-unpaid-bg:#fee2e2;--status-unpaid-text:#991b1b;--status-partial-bg:#fef3c7;--status-partial-text:#92400e;--status-default-bg:#e5e7eb;--status-default-text:#4b5563;}
        *{margin:0;padding:0;box-sizing:border-box}
        body{font-family:'Poppins',sans-serif;background-color:var(--body-bg);color:var(--text-primary);line-height:1.6;font-size:14px}
        .container{max-width:1280px;margin:0 auto;padding:2rem}
        .page-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:2rem;padding-bottom:1rem;border-bottom:1px solid var(--border-color)}
        .page-title h1{font-size:1.75rem;font-weight:700;color:var(--primary);margin-bottom:0.25rem}
        .page-title p{color:var(--text-secondary);font-size:.875rem}
        .user-menu{display:flex;align-items:center;gap:1rem}
        .card{background:var(--card-bg);border-radius:var(--radius-lg);box-shadow:var(--shadow-md);overflow:hidden;margin-bottom:1.5rem}
        .card-body{padding:1.5rem}
        .tabs{display:flex;border-bottom:1px solid var(--border-color);padding:0 1.5rem}
        .tab{padding:.75rem 1.25rem;cursor:pointer;font-weight:500;color:var(--text-secondary);border-bottom:2px solid transparent;transition:all .2s ease;margin-bottom:-1px;white-space:nowrap}
        .tab:hover{color:var(--primary)}
        .tab.active{color:var(--primary);border-bottom-color:var(--primary)}
        .tab-content{display:none}
        .tab-content.active{display:block}
        .form-group{margin-bottom:1rem}
        .form-row{display:flex;flex-wrap:wrap;gap:.75rem;margin-bottom:.75rem}
        .form-col{flex:1;min-width:180px}
        label{display:block;font-weight:500;margin-bottom:.5rem;color:var(--text-primary);font-size:.875rem}
        input,select,textarea{width:100%;padding:.625rem .75rem;border:1px solid var(--border-color);border-radius:var(--radius);font-family:inherit;font-size:.875rem;color:var(--text-primary);background-color:white;transition:border-color .2s ease,box-shadow .2s ease}
        input:focus,select:focus,textarea:focus{outline:none;border-color:var(--primary-light);box-shadow:0 0 0 3px rgba(59,130,246,0.25)}
        input[readonly],input:disabled{background-color:var(--light);cursor:not-allowed;opacity:.7}
        .box{border:1px solid var(--border-color);border-radius:var(--radius-md);padding:1.25rem;margin-bottom:1.5rem}
        .box-title{font-size:1rem;font-weight:600;color:var(--primary);margin-bottom:1rem;padding-bottom:.5rem;border-bottom:1px solid var(--border-color)}
        .table-responsive{overflow-x:auto}
        table{width:100%;border-collapse:collapse;margin-bottom:1rem}
        table th,table td{padding:.75rem;border-bottom:1px solid var(--border-color);vertical-align:middle;font-size:.875rem;line-height:1.4}
        table th{text-align:left;font-weight:600;background-color:var(--light);border-bottom-width:2px;color:var(--text-primary);white-space:nowrap}
        table tr:last-child td{border-bottom:none}
        .empty-table td{text-align:center;padding:2rem;color:var(--text-secondary)}
        .status-badge{display:inline-block;padding:.3em .7em;font-size:.7rem;font-weight:600;text-align:center;white-space:nowrap;border-radius:var(--radius-md);text-transform:uppercase}
        .status-draft{background-color:#e5e7eb;color:#4b5563}
        .status-sent{background-color:#dbeafe;color:#1e40af}
        .status-accepted{background-color:#dcfce7;color:#15803d}
        .status-invoiced{background-color:#ede9fe;color:#5b21b6}
        .status-rejected{background-color:#fee2e2;color:#991b1b}
        .btn{display:inline-flex;align-items:center;justify-content:center;padding:.5rem 1rem;border-radius:var(--radius);font-weight:500;cursor:pointer;transition:all .2s ease;border:1px solid transparent;font-size:.875rem;text-decoration:none;white-space:nowrap}
        .btn:disabled{background-color:var(--secondary) !important;opacity:.7;cursor:not-allowed}
        .btn-primary{background-color:var(--primary);color:white}
        .btn-primary:hover:not(:disabled){background-color:var(--primary-dark)}
        .btn-success{background-color:var(--success);color:white}
        .btn-success:hover:not(:disabled){background-color:#0d9488}
        .btn-danger{background-color:var(--danger);color:white}
        .btn-danger:hover:not(:disabled){background-color:#dc2626}
        .btn-outline{background-color:transparent;border-color:var(--border-color);color:var(--text-primary)}
        .btn-outline:hover:not(:disabled){border-color:var(--primary);color:var(--primary);background-color:rgba(30,64,175,0.05)}
        .btn-sm{padding:.25rem .625rem;font-size:.75rem}
        .btn-icon{margin-right:.5rem}
        .btn-group{display:inline-flex;gap:.25rem}
        .action-buttons{display:flex;justify-content:flex-end;gap:.75rem;margin-top:1.5rem}
        .pagination{display:flex;justify-content:center;align-items:center;gap:.5rem;margin-top:1.5rem;font-size:.875rem}
        .pagination a,.pagination span{padding:.4rem .8rem;border:1px solid var(--border-color);border-radius:var(--radius);color:var(--primary);text-decoration:none;background-color:white}
        .pagination a:hover{background-color:var(--primary-light);color:white}
        .pagination span.current{background-color:var(--primary);color:white;border-color:var(--primary)}
        .pagination span.disabled{color:var(--text-muted);background-color:var(--light);cursor:not-allowed}
        #toast-container{position:fixed;top:1rem;right:1rem;z-index:9999;width:320px}
        .toast{background-color:white;border-radius:var(--radius);box-shadow:var(--shadow-md);margin-bottom:.75rem;overflow:hidden;border-left:4px solid var(--dark);animation:slideInRight .3s ease-out,fadeOut .5s ease-out 4.5s forwards}
        .toast-header{padding:.5rem 1rem;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--border-color)}
        .toast-title{font-weight:600;font-size:.875rem}
        .toast-close{background:transparent;border:none;font-size:1.25rem;cursor:pointer;color:var(--text-secondary)}
        .toast-body{padding:.75rem 1rem}
        .toast-success{border-left-color:var(--success)}
        .toast-error{border-left-color:var(--danger)}
        @keyframes slideInRight{from{transform:translateX(100%);opacity:0}to{transform:translateX(0);opacity:1}}
        @keyframes fadeOut{from{opacity:1}to{opacity:0}}
        .text-right{text-align:right}
        .text-center{text-align:center}
        .font-semibold{font-weight:600}
        .totals-table td{padding:.4rem 0}
        .totals-table label{margin-bottom:0;font-weight:400}
        .totals-table input[type=number]{padding:.3rem .5rem;font-size:.875rem;max-width:80px;display:inline-block;margin-left:5px}
        .totals-table .amount-display{font-weight:500;display:inline-block;min-width:60px;text-align:right}
        .totals-table .grand-total td{font-weight:700;font-size:1.1em;border-top:1px solid var(--border-color);padding-top:.6rem}
        .sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);border-width:0}
        .modal{display:none;position:fixed;z-index:1000;left:0;top:0;width:100%;height:100%;overflow:auto;background-color:rgba(0,0,0,0.6);backdrop-filter:blur(3px)}
        .modal-content{background-color:#fff;margin:5% auto;padding:0;border:1px solid #ccc;width:90%;max-width:900px;border-radius:var(--radius-lg);box-shadow:var(--shadow-lg);animation:fadeInModal .3s ease-out;overflow:hidden}
        .modal-header{padding:1rem 1.5rem;background-color:var(--primary);color:white;display:flex;justify-content:space-between;align-items:center;}
        .modal-title{font-weight:600;font-size:1.25rem;}
        .modal-close{background:transparent;border:none;color:white;font-size:1.8rem;cursor:pointer;}
        .modal-body{padding:1.5rem;max-height:70vh;overflow-y:auto}
        .modal-footer{padding:1rem 1.5rem;background-color:var(--light);border-top:1px solid var(--border-color);display:flex;justify-content:flex-end;gap:.75rem}
        @keyframes fadeInModal{from{opacity:0;transform:translateY(-20px)}to{opacity:1;transform:translateY(0)}}
        @media print{body{background-color:white !important;color:black !important;font-size:10pt !important}.container,.page-header,.action-buttons,.modal:not(#estimate-preview-modal),#toast-container,.tabs,button,.alert{display:none !important}.card,.card-body,.tab-content{all:unset;display:block !important}.status-badge{display:none !important}#estimate-preview-modal{display:block !important;position:absolute !important;left:0;top:0;width:100% !important;height:auto !important;overflow:visible !important;background:none !important;padding:0 !important;z-index:9999}#estimate-preview-modal .modal-content{margin:0 !important;padding:0 !important;border:none !important;box-shadow:none !important;max-width:100% !important;border-radius:0 !important}#estimate-preview-modal .modal-header,#estimate-preview-modal .modal-footer{display:none !important}#estimate-preview-modal .modal-body{padding:0 !important;max-height:none !important;overflow:visible !important}#estimate-preview-content>div{max-width:100% !important;margin:0 !important;padding:0 !important;border:none !important;box-shadow:none !important;font-size:10pt}#estimate-preview-content table th,#estimate-preview-content table td{font-size:9pt !important}@page{size:A4;margin:1cm}}
    </style>
</head>
<body>
    <div class="container">
        <div class="page-header">
            <div class="page-title"><h1>Manage Estimates / Quotations</h1></div>
            <div class="user-menu"><a href="index.php" class="btn btn-outline btn-sm">← Back to Dashboard</a><span class="user-name" style="margin-left: 1rem;">User: <?php echo h($username); ?></span></div>
        </div>
        <div class="card">
            <div class="tabs">
                <div class="tab active" data-tab="estimates-list">Estimates List</div>
                <div class="tab" data-tab="create-estimate">Create New Estimate</div>
            </div>
            <div class="tab-content active" id="estimates-list-tab">
                <div class="card-body"><div class="table-responsive"><table id="estimates-table"><thead><tr><th>Estimate #</th><th>Date</th><th>Client</th><th class="text-right">Total (₹)</th><th class="text-center">Status</th><th class="text-center">Actions</th></tr></thead><tbody id="estimates-table-body"></tbody></table></div><div id="estimate-pagination" class="pagination"></div></div>
            </div>
            <div class="tab-content" id="create-estimate-tab">
                <div class="card-body">
                    <h2 class="text-lg font-semibold mb-4" id="estimate-form-title">Create New Estimate</h2>
                    <form id="estimate-form" onsubmit="return false;">
                        <input type="hidden" name="estimate_id" id="estimate_form_id">
                        <div class="box"><h3 class="box-title">Estimate Details</h3><div class="form-row"><div class="form-col"><label>Estimate Number</label><input type="text" id="estimate_number" name="estimate_number" value="<?php echo h($next_estimate_num_display); ?>" readonly></div><div class="form-col"><label>Estimate Date *</label><input type="date" id="estimate_date" name="estimate_date" value="<?php echo date('Y-m-d'); ?>" required></div><div class="form-col"><label>Expiry Date</label><input type="date" id="expiry_date" name="expiry_date"></div></div></div>
                        <div class="box"><h3 class="box-title">Client Information</h3><div class="form-row"><div class="form-col"><label for="client_search_estimate" class="sr-only">Search Client</label><input type="text" id="client_search_estimate" placeholder="Search Client..." class="mb-2"><label for="client_id_estimate">Select Client *</label><select id="client_id_estimate" name="client_id" required><option value="">-- Select a Client --</option></select><div id="client-loading-estimate" style="display: none; color: var(--text-muted); font-size: 0.8rem;">Loading...</div></div></div><div id="client-details-estimate" style="display: none;" class="mt-2"><div style="background-color: var(--light); border: 1px solid var(--border-color); border-radius: var(--radius); padding: 0.75rem;"><div class="font-semibold text-primary-dark" id="show-client-name-estimate"></div></div></div></div>
                        <div class="box"><h3 class="box-title">Items *</h3><div class="table-responsive"><table id="estimate-items-table"><thead><tr><th width="50%">Description</th><th>Qty</th><th>Rate (₹)</th><th>Amount (₹)</th><th>Action</th></tr></thead><tbody id="estimate-items-body"></tbody></table></div><button type="button" class="btn btn-outline btn-sm mt-2" onclick="addEstimateItem()">+ Add Item</button><div class="flex justify-end mt-4"><div style="width: 100%; max-width: 350px;"><table class="w-full text-sm totals-table"><tr><td class="text-muted">Subtotal:</td><td class="text-right">₹ <span id="estimate-subtotal" class="amount-display">0.00</span></td></tr><tr><td><label>Discount (%):</label> <input type="number" id="estimate-discount-rate" name="discount_rate" value="0.00" min="0" step="0.01"></td><td class="text-right">- ₹ <span id="estimate-discount-amount" class="amount-display">0.00</span></td></tr><tr><td><label>CGST (%):</label> <input type="number" id="estimate_cgst_rate" name="cgst_rate" value="9.00" min="0" step="0.01"></td><td class="text-right">₹ <span id="estimate-cgst-amount" class="amount-display">0.00</span></td></tr><tr><td><label>SGST (%):</label> <input type="number" id="estimate_sgst_rate" name="sgst_rate" value="9.00" min="0" step="0.01"></td><td class="text-right">₹ <span id="estimate-sgst-amount" class="amount-display">0.00</span></td></tr><tr class="grand-total"><td>Total Amount:</td><td class="text-right">₹ <span id="estimate-total-amount" class="amount-display">0.00</span></td></tr></table></div></div></div>
                        <div class="box"><h3 class="box-title">Notes / Terms</h3><textarea id="estimate_notes" name="notes" rows="3"><?php echo h($company['default_notes'] ?? ''); ?></textarea></div>
                        <div class="action-buttons"><button type="button" class="btn btn-outline" onclick="resetEstimateForm()">Cancel / New</button><button type="button" class="btn btn-primary" id="save-estimate-btn" onclick="saveEstimate(this)">Save Estimate</button></div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div id="estimate-preview-modal" class="modal"><div class="modal-content"><div class="modal-header"><h2 class="modal-title">Estimate Preview</h2><button type="button" class="modal-close" onclick="closeEstimatePreviewModal()">×</button></div><div class="modal-body" id="estimate-preview-content"><p class="text-center">Loading preview...</p></div><div class="modal-footer"><button type="button" class="btn btn-outline" onclick="printEstimate()"><i class="fas fa-print btn-icon"></i>Print</button><button type="button" class="btn btn-success" onclick="downloadEstimatePDF()"><i class="fas fa-file-pdf btn-icon"></i>Download PDF</button><button type="button" class="btn btn-secondary" onclick="closeEstimatePreviewModal()">Close</button></div></div></div>
    <div id="estimate-status-modal" class="modal"><div class="modal-content" style="max-width: 400px;"><div class="modal-header"><h2 class="modal-title">Change Estimate Status</h2><button type="button" class="modal-close" onclick="closeStatusModal()">×</button></div><div class="modal-body"><form id="status-update-form" onsubmit="return false;"><input type="hidden" id="status_estimate_id" name="estimate_id"><div class="form-group"><label for="new_status">Select New Status</label><select id="new_status" name="new_status" class="form-control"><option value="draft">Draft</option><option value="sent">Sent</option><option value="accepted">Accepted</option><option value="rejected">Rejected</option></select></div></form></div><div class="modal-footer"><button type="button" class="btn btn-outline" onclick="closeStatusModal()">Cancel</button><button type="button" class="btn btn-primary" id="save-status-btn" onclick="saveEstimateStatus(this)">Save Status</button></div></div></div>
    <div id="toast-container"></div>
    <script>
        (function() {
            const tabs=document.querySelectorAll('.tab');
            const tabContents=document.querySelectorAll('.tab-content');
            const estimatesTableBody=document.getElementById('estimates-table-body');
            const paginationDiv=document.getElementById('estimate-pagination');
            const estimateItemsBody=document.getElementById('estimate-items-body');
            const formTitle=document.getElementById('estimate-form-title');
            const clientSearchInput=document.getElementById('client_search_estimate');
            const clientSelect=document.getElementById('client_id_estimate');
            const clientLoadingDiv=document.getElementById('client-loading-estimate');
            const clientDetailsDiv=document.getElementById('client-details-estimate');
            const previewModal=document.getElementById('estimate-preview-modal');
            const statusModal=document.getElementById('estimate-status-modal');
            const toastContainer = document.getElementById('toast-container');
            let clientSearchTimeout;

            function showToast(title,message,type='info'){if(!toastContainer)return;const t=document.createElement('div');t.className=`toast toast-${type}`;let i=type==='success'?'✓':(type==='error'?'✗':'ℹ️');t.innerHTML=`<div class="toast-header"><span class="toast-title">${escapeHtml(title)}</span><button class="toast-close" type="button" onclick="this.parentElement.parentElement.remove()">×</button></div><div class="toast-body">${escapeHtml(message)}</div>`;toastContainer.appendChild(t);}
            function escapeHtml(unsafe){if(typeof unsafe!=='string')return unsafe??'';return unsafe.replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'})[m]);}
            function roundTo(n,digits=2){const m=Math.pow(10,digits);return Math.round(parseFloat((n*m).toFixed(11)))/m;}
            function openModal(modalEl){if(modalEl)modalEl.style.display='block';}
            function closeModal(modalEl){if(modalEl)modalEl.style.display='none';}

            window.closeEstimatePreviewModal=function(){closeModal(previewModal);}
            window.closeStatusModal=function(){closeModal(statusModal);}
            window.addEventListener('click',event=>{if(event.target===previewModal){closeEstimatePreviewModal();}if(event.target===statusModal){closeStatusModal();}});
            
            function showTab(tabName){tabs.forEach(t=>t.classList.remove('active'));tabContents.forEach(c=>c.classList.remove('active'));document.querySelector(`.tab[data-tab="${tabName}"]`).classList.add('active');document.getElementById(`${tabName}-tab`).classList.add('active');if(tabName==='estimates-list'){window.loadEstimates(1);}}
            tabs.forEach(tab=>tab.addEventListener('click',()=>showTab(tab.dataset.tab)));
            
            function loadClientsForDropdown(searchTerm='',selectedClientId=null){clientLoadingDiv.style.display='block';clientSelect.disabled=true;const currentVal=selectedClientId?selectedClientId.toString():(clientSelect.value||null);fetch(`api.php?action=get_clients&search=${encodeURIComponent(searchTerm)}&limit=100`).then(res=>res.json()).then(data=>{clientSelect.innerHTML='<option value="">-- Select a Client --</option>';if(data.success&&data.clients.length>0){data.clients.forEach(c=>{const opt=new Option(`${escapeHtml(c.name)} ${c.gstin?`(${escapeHtml(c.gstin)})`:''}`,c.id);opt.dataset.name=c.name;clientSelect.appendChild(opt);});if(currentVal&&clientSelect.querySelector(`option[value="${currentVal}"]`)){clientSelect.value=currentVal;}}
            updateClientDetailsDisplay();}).finally(()=>{clientLoadingDiv.style.display='none';clientSelect.disabled=false;});}
            
            function updateClientDetailsDisplay(){const opt=clientSelect.options[clientSelect.selectedIndex];const nameEl=document.getElementById('show-client-name-estimate');if(clientSelect.value&&opt?.dataset?.name){nameEl.textContent=opt.dataset.name;clientDetailsDiv.style.display='block';}else{clientDetailsDiv.style.display='none';}}
            clientSearchInput.addEventListener('input',function(){clearTimeout(clientSearchTimeout);clientSearchTimeout=setTimeout(()=>{loadClientsForDropdown(this.value.trim());},350);});
            clientSelect.addEventListener('change',updateClientDetailsDisplay);
            
            window.loadEstimates=function(page=1){estimatesTableBody.innerHTML='<tr><td colspan="6" class="empty-table">Loading...</td></tr>';fetch(`api_estimates.php?action=get_estimates&page=${page}`).then(res=>res.json()).then(data=>{estimatesTableBody.innerHTML='';paginationDiv.innerHTML='';if(data.success&&data.estimates.length>0){data.estimates.forEach(est=>{const status=escapeHtml(est.status);const row=estimatesTableBody.insertRow();const date=new Date(est.estimate_date+'T00:00:00');const formattedDate=date.toLocaleDateString('en-GB',{day:'2-digit',month:'2-digit',year:'numeric'});row.innerHTML=`
            <td>${escapeHtml(est.estimate_number)}</td>
            <td>${formattedDate}</td>
            <td>${escapeHtml(est.client_name)}</td>
            <td class="text-right">${parseFloat(est.total_amount).toFixed(2)}</td>
            <td class="text-center"><span class="status-badge status-${status.replace('_','-')}">${status.replace('_',' ')}</span></td>
            <td class="text-center"><div class="btn-group">
            <button class="btn btn-outline btn-sm" title="Change Status" onclick="openStatusModal(${est.id}, '${status}')" ${status === 'invoiced' ? 'disabled' : ''}><i class="fas fa-tags"></i></button>
            <button class="btn btn-outline btn-sm" title="View" onclick="viewEstimate(${est.id})"><i class="fas fa-eye"></i></button>
            <button class="btn btn-outline btn-sm" title="Edit" onclick="editEstimate(${est.id})"><i class="fas fa-edit"></i></button>
            <button class="btn btn-success btn-sm" title="Convert to Invoice" onclick="convertToInvoice(${est.id}, this)" ${status==='invoiced'?'disabled':''}><i class="fas fa-file-invoice"></i></button>
            <button class="btn btn-danger btn-sm" title="Delete" onclick="deleteEstimate(${est.id}, this)" ${status==='invoiced'?'disabled':''}><i class="fas fa-trash"></i></button>
            </div></td>`;});renderPagination(data.page,data.total_estimates,data.limit);}else{estimatesTableBody.innerHTML='<tr><td colspan="6" class="empty-table">No estimates found. Create one now!</td></tr>';}}).catch(()=>showToast('Error','Failed to load estimates.','error'));}
            
            window.openStatusModal = function(id, currentStatus){document.getElementById('status_estimate_id').value = id; document.getElementById('new_status').value = currentStatus; openModal(statusModal);}
            window.saveEstimateStatus = function(button){const form=document.getElementById('status-update-form');const formData=new FormData(form);formData.append('action','update_estimate_status');button.disabled=true;button.textContent='Saving...';fetch('api_estimates.php',{method:'POST',body:formData}).then(res=>res.json()).then(data=>{if(data.success){showToast('Success',data.message,'success');closeStatusModal();loadEstimates(document.querySelector('.pagination .current')?.textContent||1);}else{showToast('Error',data.message||'Failed to update status.','error');}}).finally(()=>{button.disabled=false;button.textContent='Save Status';});}
            
            window.viewEstimate=function(id){const previewContentEl=document.getElementById('estimate-preview-content');const printBtn=document.querySelector('#estimate-preview-modal .btn-outline');const downloadBtn=document.querySelector('#estimate-preview-modal .btn-success');previewContentEl.innerHTML='<p class="text-center">Loading...</p>';if(printBtn)printBtn.setAttribute('onclick','');if(downloadBtn)downloadBtn.setAttribute('onclick','');openModal(previewModal);fetch(`api_estimates.php?action=preview_estimate&id=${id}`).then(res=>res.json()).then(data=>{if(data.success&&data.html&&data.fileNameData){previewContentEl.innerHTML=data.html;const estData=data.fileNameData;let clientName=estData.client||'Client';clientName=clientName.replace(/\s+/g,'_').replace(/[\\/:*?"<>|]/g,'');const date=new Date(estData.date+'T00:00:00');const formattedDate=String(date.getDate()).padStart(2,'0')+'-'+String(date.getMonth()+1).padStart(2,'0')+'-'+date.getFullYear();const fileName=`Estimate_${estData.number}_${clientName}_${formattedDate}.pdf`;if(printBtn){printBtn.setAttribute('onclick',`printEstimate()`)}
            if(downloadBtn){downloadBtn.setAttribute('onclick',`downloadEstimatePDF('${escapeHtml(fileName)}')`);}}else{showToast('Error',data.message||'Could not load preview','error');closeModal(previewModal);}});}
            
            window.printEstimate=function(){const contentEl=document.getElementById('estimate-preview-content');if(!contentEl||!contentEl.querySelector('table')){showToast('Info','Preview content is missing.','info');return;}
            const iframe=document.createElement('iframe');iframe.style.cssText='position:fixed;top:-9999px;left:-9999px;width:0;height:0;';document.body.appendChild(iframe);const doc=iframe.contentWindow.document;const styles=Array.from(document.styleSheets).map(s=>{try{return Array.from(s.cssRules||[]).map(r=>r.cssText).join('');}catch(e){return'';}}).join('\n');const printStyles='@media print{ body {-webkit-print-color-adjust: exact; print-color-adjust: exact; font-size: 10pt !important; } @page{size: A4; margin: 1cm;} }';doc.open();doc.write(`<!DOCTYPE html><html><head><title>Estimate</title><link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet"><style>${styles} ${printStyles}</style></head><body>${contentEl.innerHTML}</body></html>`);doc.close();setTimeout(()=>{try{iframe.contentWindow.focus();iframe.contentWindow.print();}
            catch(e){showToast('Error','Printing failed.','error');}
            setTimeout(()=>{document.body.removeChild(iframe);},1000);},350);}

            window.downloadEstimatePDF=function(fileName){const contentEl=document.getElementById('estimate-preview-content');if(!contentEl||!contentEl.querySelector('table')){showToast('Info','Preview content is missing.','info');return;}
            const opt={margin:0.5,filename:fileName,image:{type:'jpeg',quality:0.98},html2canvas:{scale:2,logging:false},jsPDF:{unit:'in',format:'a4',orientation:'portrait'}};html2pdf().set(opt).from(contentEl.firstElementChild).save();}
            
            window.saveEstimate=function(button){const form=document.getElementById('estimate-form');if(!form.checkValidity()){form.reportValidity();return;}
            const formData=new FormData(form);formData.append('action','save_estimate');button.disabled=true;button.textContent='Saving...';fetch('api_estimates.php',{method:'POST',body:formData}).then(res=>res.json()).then(data=>{if(data.success){showToast('Success',data.message,'success');resetEstimateForm();showTab('estimates-list');}else{showToast('Error',data.message||'Save failed','error');}}).finally(()=>{button.disabled=false;button.textContent='Save Estimate';});}
            window.editEstimate=function(id){fetch(`api_estimates.php?action=get_estimate&id=${id}`).then(res=>res.json()).then(data=>{if(data.success){const est=data.estimate;resetEstimateForm();formTitle.textContent=`Edit Estimate #${est.estimate_number}`;document.getElementById('estimate_form_id').value=est.id;document.getElementById('estimate_number').value=est.estimate_number;document.getElementById('estimate_date').value=est.estimate_date;document.getElementById('expiry_date').value=est.expiry_date||'';loadClientsForDropdown('',est.client_id);document.getElementById('estimate-discount-rate').value=est.discount_rate;document.getElementById('estimate_cgst_rate').value=est.cgst_rate;document.getElementById('estimate_sgst_rate').value=est.sgst_rate;document.getElementById('estimate_notes').value=est.notes||'';estimateItemsBody.innerHTML='';data.items.forEach(item=>addEstimateItem(item));updateEstimateTotals();showTab('create-estimate');}});}
            window.deleteEstimate=function(id,button){if(!confirm('Are you sure? This cannot be undone.'))return;button.disabled=true;fetch('api_estimates.php',{method:'POST',body:new URLSearchParams({action:'delete_estimate',id:id})}).then(res=>res.json()).then(data=>{if(data.success){showToast('Success',data.message,'success');loadEstimates();}else{showToast('Error',data.message,'error');button.disabled=false;}});}
            window.convertToInvoice=function(id,button){if(!confirm('This will create a new invoice from this estimate. Proceed?'))return;button.disabled=true;button.textContent='...';fetch('api_estimates.php',{method:'POST',body:new URLSearchParams({action:'convert_to_invoice',estimate_id:id})}).then(res=>res.json()).then(data=>{if(data.success){localStorage.setItem('flashMessage',JSON.stringify({type:'success',message:data.message}));window.location.href=`index.php?invoice_page=1#invoices`;}else{showToast('Error',data.message||'Conversion failed.','error');button.disabled=false;button.textContent='Invoice';}});}
            window.addEstimateItem=function(item=null){const tr=estimateItemsBody.insertRow();tr.innerHTML=`<td><input type="text" name="description[]" required></td><td><input type="number" name="quantity[]" value="1.00" step="any" required></td><td><input type="number" name="rate[]" value="0.00" step="0.01" required></td><td><input type="text" name="amount[]" readonly class="text-right"></td><td class="text-center"><button type="button" class="btn btn-danger btn-sm">×</button></td>`;if(item){tr.querySelector('[name="description[]"]').value=item.description;tr.querySelector('[name="quantity[]"]').value=item.quantity;tr.querySelector('[name="rate[]"]').value=item.rate;}
            tr.querySelector('button').onclick=()=>{if(estimateItemsBody.rows.length>1){tr.remove();}updateEstimateTotals();};tr.querySelectorAll('input[type=number]').forEach(inp=>inp.oninput=()=>updateEstimateTotals());tr.querySelector('input[name="description[]"]').oninput=()=>updateEstimateTotals();}
            window.updateEstimateTotals=function(){let subtotal=0;estimateItemsBody.querySelectorAll('tr').forEach(row=>{const qty=parseFloat(row.querySelector('[name="quantity[]"]').value)||0;const rate=parseFloat(row.querySelector('[name="rate[]"]').value)||0;const amount=roundTo(qty*rate);row.querySelector('[name="amount[]"]').value=amount.toFixed(2);subtotal+=amount;});const discRate=parseFloat(document.getElementById('estimate-discount-rate').value)||0;const cgstRate=parseFloat(document.getElementById('estimate_cgst_rate').value)||0;const sgstRate=parseFloat(document.getElementById('estimate_sgst_rate').value)||0;const discAmount=roundTo(subtotal*(discRate/100));const taxableAmount=subtotal-discAmount;const cgstAmount=roundTo(taxableAmount*(cgstRate/100));const sgstAmount=roundTo(taxableAmount*(sgstRate/100));const totalAmount=roundTo(taxableAmount+cgstAmount+sgstAmount);document.getElementById('estimate-subtotal').textContent=subtotal.toFixed(2);document.getElementById('estimate-discount-amount').textContent=discAmount.toFixed(2);document.getElementById('estimate-cgst-amount').textContent=cgstAmount.toFixed(2);document.getElementById('estimate-sgst-amount').textContent=sgstAmount.toFixed(2);document.getElementById('estimate-total-amount').textContent=totalAmount.toFixed(2);}
            window.resetEstimateForm=function(){document.getElementById('estimate-form').reset();document.getElementById('estimate_form_id').value='';document.getElementById('estimate_number').value='<?php echo h($next_estimate_num_display); ?>';formTitle.textContent='Create New Estimate';estimateItemsBody.innerHTML='';addEstimateItem();updateEstimateTotals();loadClientsForDropdown();updateClientDetailsDisplay();showTab('create-estimate');}
            function renderPagination(currentPage,totalItems,limit){paginationDiv.innerHTML='';const totalPages=Math.ceil(totalItems/limit);if(totalPages<=1)return;const createLink=(page,text,isDisabled,isCurrent)=>{const el=isDisabled||isCurrent?'span':'a';const e=document.createElement(el);e.innerHTML=text;e.className=isDisabled?'disabled':(isCurrent?'current':'');if(!isDisabled&&!isCurrent){e.href='#';e.onclick=(ev)=>{ev.preventDefault();window.loadEstimates(page);}}
            paginationDiv.appendChild(e);};createLink(currentPage-1,'«',currentPage===1);for(let i=1;i<=totalPages;i++){if(i==1||i==totalPages||(i>=currentPage-1&&i<=currentPage+1)){createLink(i,i,false,i===currentPage);}else if(i==currentPage-2||i==currentPage+3){const s=document.createElement('span');s.textContent='...';paginationDiv.appendChild(s);}}
            createLink(currentPage+1,'»',currentPage===totalPages);}
            
            document.addEventListener('DOMContentLoaded',()=>{
                loadEstimates(1);
                loadClientsForDropdown();
                addEstimateItem();
                updateEstimateTotals();
                ['estimate-discount-rate','estimate_cgst_rate','estimate_sgst_rate'].forEach(id=>document.getElementById(id).oninput=updateEstimateTotals);
            });
        })();
    </script>
</body>
</html>