<?php
// Include database configuration and start session
require_once 'db_config.php';

// Check if the user is logged in, redirect if not
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}

// Get user information
$user_id = $_SESSION["id"];
$username = $_SESSION["username"];

// --- Date Range Filtering & Validation ---
function validate_date($date, $format = 'Y-m-d') {
    $d = DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) === $date;
}

// Default: Last 90 days
$default_end_date = date('Y-m-d'); // Today
$default_start_date = date('Y-m-d', strtotime('-89 days', strtotime($default_end_date))); // 90 days total inclusive

$start_date_str = $_GET['start_date'] ?? $default_start_date;
$end_date_str = $_GET['end_date'] ?? $default_end_date;

$start_date = validate_date($start_date_str) ? $start_date_str : $default_start_date;
$end_date = validate_date($end_date_str) ? $end_date_str : $default_end_date;

if ($start_date > $end_date) { // Ensure logical order
    list($start_date, $end_date) = [$end_date, $start_date];
}
// --- End Date Filtering ---

// --- Helper Functions ---
function h($text) { return htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8'); }
function format_currency($amount, $decimals = 2) { return number_format(round((float)$amount, $decimals), $decimals); }
function calculate_date_diff_days($date1, $date2) {
    $d1 = new DateTime($date1);
    $d2 = new DateTime($date2);
    $interval = $d1->diff($d2);
    return $interval->days;
}
// --- End Helper Functions ---

// --- Initialize Reporting Variables ---
$kpis = [
    'total_invoiced' => 0.00, 'total_collected_in_period' => 0.00, // Note: approximation without payment dates
    'outstanding_receivables' => 0.00, 'paid_invoice_count' => 0,
    'unpaid_invoice_count' => 0, 'partial_invoice_count' => 0, 'total_invoice_count' => 0,
    'avg_invoice_value' => 0.00, 'overdue_amount' => 0.00, 'overdue_count' => 0
];
$client_kpis = ['total_active_clients' => 0];
$aging_summary = ['current' => 0.00, '1-30' => 0.00, '31-60' => 0.00, '61-90' => 0.00, '90+' => 0.00];
$monthly_revenue = [];
$top_clients = [];
$recent_invoices_table = [];
$overdue_invoices_table = [];
$report_error = null;
$today_date_str = date('Y-m-d');


// --- Database Queries (Encapsulated in Try/Catch) ---
try {
    $db_params = ['user_id' => $user_id, 'start_date' => $start_date, 'end_date' => $end_date];
    $db_params_overdue = $db_params + ['today_date' => $today_date_str];

    // 1. KPI Aggregations (within date range based on invoice_date)
    $sql_kpi = "SELECT
                    COUNT(*) as total_invoice_count,
                    SUM(CASE WHEN LOWER(status) = 'paid' THEN 1 ELSE 0 END) as paid_invoice_count,
                    SUM(CASE WHEN LOWER(status) = 'unpaid' THEN 1 ELSE 0 END) as unpaid_invoice_count,
                    SUM(CASE WHEN LOWER(status) = 'partially_paid' THEN 1 ELSE 0 END) as partial_invoice_count,
                    COALESCE(SUM(total_amount), 0.00) as total_invoiced,
                    COALESCE(SUM(advance_paid), 0.00) as total_collected_in_period, /* Approximation */
                    COALESCE(SUM(CASE WHEN LOWER(status) != 'paid' THEN total_amount - advance_paid ELSE 0 END), 0.00) as outstanding_receivables,
                    COALESCE(SUM(CASE WHEN LOWER(status) != 'paid' AND due_date IS NOT NULL AND due_date < :today_date THEN total_amount - advance_paid ELSE 0 END), 0.00) as overdue_amount,
                    SUM(CASE WHEN LOWER(status) != 'paid' AND due_date IS NOT NULL AND due_date < :today_date THEN 1 ELSE 0 END) as overdue_count
                FROM invoices
                WHERE user_id = :user_id AND invoice_date BETWEEN :start_date AND :end_date";
    $result_kpi = query($conn, $sql_kpi, $db_params_overdue); // Need today_date here
    if ($result_kpi) { $kpis = array_merge($kpis, fetch_one($result_kpi)); }
    else { throw new Exception("KPI query failed: ".mysqli_error($conn)); }

    // Calculate derived KPI
    $kpis['avg_invoice_value'] = ($kpis['total_invoice_count'] > 0) ? round($kpis['total_invoiced'] / $kpis['total_invoice_count'], 2) : 0.00;
    $kpis['outstanding_receivables'] = round($kpis['outstanding_receivables'], 2);
    $kpis['overdue_amount'] = round($kpis['overdue_amount'], 2);

    // 2. Client Count (Overall - Not date filtered)
    $sql_clients = "SELECT COUNT(*) as total_active_clients FROM clients WHERE user_id = :user_id";
    $result_clients = query($conn, $sql_clients, ['user_id' => $user_id]);
    if($result_clients) { $client_kpis = array_merge($client_kpis, fetch_one($result_clients)); }
    else { error_log("Non-critical error: Client count query failed: ".mysqli_error($conn)); }

    // 3. Receivable Aging Summary (for *all* outstanding invoices, not just period)
    $sql_aging = "SELECT
                     COALESCE(SUM(CASE WHEN due_date IS NULL OR due_date >= :today_date THEN amount_due ELSE 0 END), 0.00) as current_due,
                     COALESCE(SUM(CASE WHEN due_date < :today_date AND due_date >= DATE_SUB(:today_date, INTERVAL 30 DAY) THEN amount_due ELSE 0 END), 0.00) as 'due_1_30',
                     COALESCE(SUM(CASE WHEN due_date < DATE_SUB(:today_date, INTERVAL 30 DAY) AND due_date >= DATE_SUB(:today_date, INTERVAL 60 DAY) THEN amount_due ELSE 0 END), 0.00) as 'due_31_60',
                     COALESCE(SUM(CASE WHEN due_date < DATE_SUB(:today_date, INTERVAL 60 DAY) AND due_date >= DATE_SUB(:today_date, INTERVAL 90 DAY) THEN amount_due ELSE 0 END), 0.00) as 'due_61_90',
                     COALESCE(SUM(CASE WHEN due_date < DATE_SUB(:today_date, INTERVAL 90 DAY) THEN amount_due ELSE 0 END), 0.00) as 'due_90_plus'
                  FROM (
                      SELECT due_date, GREATEST(0, total_amount - advance_paid) as amount_due
                      FROM invoices
                      WHERE user_id = :user_id AND LOWER(status) != 'paid'
                  ) as outstanding";
    $result_aging = query($conn, $sql_aging, ['user_id' => $user_id, 'today_date' => $today_date_str]);
     if ($result_aging) {
        $aging_data = fetch_one($result_aging);
         $aging_summary['current'] = round((float)$aging_data['current_due'], 2);
         $aging_summary['1-30'] = round((float)$aging_data['due_1_30'], 2);
         $aging_summary['31-60'] = round((float)$aging_data['due_31_60'], 2);
         $aging_summary['61-90'] = round((float)$aging_data['due_61_90'], 2);
         $aging_summary['90+'] = round((float)$aging_data['due_90_plus'], 2);
    } else { throw new Exception("Aging summary query failed: ".mysqli_error($conn)); }

    // 4. Monthly Revenue Data (within date range)
     $sql_monthly = "SELECT DATE_FORMAT(invoice_date, '%Y-%m') as month_year, SUM(total_amount) as monthly_revenue
                    FROM invoices
                    WHERE user_id = :user_id AND invoice_date BETWEEN :start_date AND :end_date
                    GROUP BY month_year ORDER BY month_year ASC";
    $result_monthly = query($conn, $sql_monthly, $db_params);
     if ($result_monthly) { $monthly_data_raw = fetch_all($result_monthly); }
     else { throw new Exception("Monthly revenue query failed: ".mysqli_error($conn)); }

     // 5. Top Clients (by Revenue in date range)
    $sql_top_clients = "SELECT c.name as client_name, SUM(i.total_amount) as total_billed
                       FROM invoices i JOIN clients c ON i.client_id = c.id
                       WHERE i.user_id = :user_id AND i.invoice_date BETWEEN :start_date AND :end_date
                       GROUP BY i.client_id, c.name ORDER BY total_billed DESC LIMIT 7"; // Top 7 for chart
    $result_top_clients = query($conn, $sql_top_clients, $db_params);
     if ($result_top_clients) { $top_clients_raw = fetch_all($result_top_clients); }
     else { throw new Exception("Top clients query failed: ".mysqli_error($conn)); }

     // 6. Recent Invoices Table (within date range)
    $sql_recent = "SELECT i.id, i.invoice_number, i.invoice_date, c.name as client_name, i.total_amount, i.status
                   FROM invoices i LEFT JOIN clients c ON i.client_id = c.id
                   WHERE i.user_id = :user_id AND i.invoice_date BETWEEN :start_date AND :end_date
                   ORDER BY i.invoice_date DESC, i.id DESC LIMIT 10";
    $result_recent = query($conn, $sql_recent, $db_params);
     if ($result_recent) { $recent_invoices_table = fetch_all($result_recent); }
     else { throw new Exception("Recent invoices query failed: ".mysqli_error($conn)); }

      // 7. Overdue Invoices Table (within date range based on INVOICE date)
    $sql_overdue = "SELECT i.id, i.invoice_number, i.invoice_date, i.due_date, c.name as client_name, i.total_amount, i.advance_paid,
                           DATEDIFF(:today_date, i.due_date) as days_overdue,
                           GREATEST(0, i.total_amount - i.advance_paid) as amount_due
                    FROM invoices i LEFT JOIN clients c ON i.client_id = c.id
                    WHERE i.user_id = :user_id
                      AND LOWER(i.status) IN ('unpaid', 'partially_paid')
                      AND i.due_date IS NOT NULL AND i.due_date < :today_date
                      AND i.invoice_date BETWEEN :start_date AND :end_date /* Filter which invoices to CONSIDER by their invoice date */
                    ORDER BY days_overdue DESC, i.due_date ASC";
    $result_overdue = query($conn, $sql_overdue, $db_params_overdue);
    if ($result_overdue) { $overdue_invoices_table = fetch_all($result_overdue); }
    else { throw new Exception("Overdue invoices query failed: ".mysqli_error($conn)); }

} catch (Exception $e) {
    $report_error = "An error occurred generating report data: " . h($e->getMessage());
    // Log the detailed error for debugging
    error_log("REPORTING ERROR User $user_id: " . $e->getMessage() . "\nTrace: " . $e->getTraceAsString());
}


// --- Prepare Chart Data (Post-Query) ---
function generate_months_range($start, $end) { /* ... unchanged ... */
    $months = []; $current = strtotime(date('Y-m-01', strtotime($start))); $end_ts = strtotime(date('Y-m-t', strtotime($end)));
    while ($current <= $end_ts) { $months[date('Y-m', $current)] = 0.00; $current = strtotime('+1 month', $current); } return $months; }

// Monthly Revenue
$monthly_revenue_filled = generate_months_range($start_date, $end_date);
foreach ($monthly_data_raw as $row) { if (isset($monthly_revenue_filled[$row['month_year']])) { $monthly_revenue_filled[$row['month_year']] = round((float)$row['monthly_revenue'], 2); } }
$monthly_chart_labels = array_map(function($mk) { return date('M Y', strtotime($mk . '-01')); }, array_keys($monthly_revenue_filled));
$monthly_chart_data = array_values($monthly_revenue_filled);

// Status Breakdown
$status_chart_labels = ['Paid', 'Unpaid', 'Partially Paid'];
$status_chart_data = [(int)$kpis['paid_invoice_count'], (int)$kpis['unpaid_invoice_count'], (int)$kpis['partial_invoice_count']];

// Top Clients
$top_clients_labels = []; $top_clients_data = [];
foreach ($top_clients_raw as $client) { $top_clients_labels[] = $client['client_name'] ?? 'N/A'; $top_clients_data[] = round((float)$client['total_billed'], 2); }

// Aging Summary for Chart
$aging_chart_labels = ['Current', '1-30 Days', '31-60 Days', '61-90 Days', '90+ Days'];
$aging_chart_data = [
    $aging_summary['current'], $aging_summary['1-30'], $aging_summary['31-60'],
    $aging_summary['61-90'], $aging_summary['90+']
];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Advanced Reports - GST Invoice Generator</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns/dist/chartjs-adapter-date-fns.bundle.min.js"></script> <!-- For Time Scale -->
    <style>
        :root { /* Basic Colors */
            --primary: #1e40af; --primary-dark: #1e3a8a; --success: #16a34a; --warning: #f59e0b; --danger: #dc2626; --info: #2563eb; --secondary: #64748b;
            --body-bg: #f1f5f9; --card-bg: #ffffff; --border-color: #e2e8f0;
            --text-primary: #1f2937; --text-secondary: #4b5563; --text-muted: #6b7280;
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06); --radius-lg: 0.5rem;
             /* Chart Specific Palettes */
            --color-paid: #22c55e; --color-partial: #f59e0b; --color-unpaid: #ef4444;
            --color-aging-current: #3b82f6; --color-aging-30: #a3e635; --color-aging-60: #facc15; --color-aging-90: #fb923c; --color-aging-90plus: #f87171;
        }
        /* Base & Layout Styles (similar to previous) */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Poppins', sans-serif; background-color: var(--body-bg); color: var(--text-primary); line-height: 1.6; font-size: 14px; }
        .container { max-width: 1600px; margin: 0 auto; padding: 1.5rem; } /* Wider */
        .page-header { display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; padding-bottom: 1rem; border-bottom: 1px solid var(--border-color); gap: 1rem; }
        .page-title h1 { font-size: 1.75rem; font-weight: 700; color: var(--primary); margin-bottom: 0.1rem; }
        .page-title p { color: var(--text-secondary); font-size: 0.875rem; margin: 0; }
        .user-menu { display: flex; align-items: center; gap: 0.75rem; flex-shrink: 0; }
        .user-name { font-weight: 500; white-space: nowrap; }
        .btn { /* Basic Button styles */ display: inline-flex; align-items: center; padding: 0.5rem 1rem; border-radius: 0.375rem; font-weight: 500; cursor: pointer; transition: background-color 0.2s ease, border-color 0.2s ease, box-shadow 0.2s ease; border: 1px solid transparent; font-size: 0.875rem; text-decoration: none; white-space: nowrap; }
        .btn-sm { padding: 0.3rem 0.7rem; font-size: 0.75rem; }
        .btn-outline { background-color: transparent; border-color: var(--border-color); color: var(--text-primary); } .btn-outline:hover { border-color: var(--primary); color: var(--primary); background-color: rgba(30, 64, 175, 0.05); }
        .btn-primary { background-color: var(--primary); color: white; border-color: var(--primary); } .btn-primary:hover { background-color: var(--primary-dark); border-color: var(--primary-dark);}
        .ml-auto { margin-left: auto; } .ml-2 { margin-left: 0.5rem; }

        /* Filter Section */
        .filter-section { background: var(--card-bg); padding: 1rem 1.5rem; border-radius: var(--radius-lg); box-shadow: var(--shadow-md); margin-bottom: 1.5rem; }
        .filter-form { display: flex; flex-wrap: wrap; align-items: flex-end; gap: 1rem; }
        .filter-form label { margin-bottom: 0.25rem; font-size: 0.8rem; color: var(--text-secondary); font-weight: 500;}
        .filter-form input[type="date"] { padding: 0.4rem 0.6rem; font-size: 0.875rem; border: 1px solid var(--border-color); border-radius: 0.375rem;}
        .filter-form input[type="date"]:focus { border-color: var(--primary); box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.25); outline: none;}
        .filter-form button { padding: 0.45rem 1.2rem; font-size: 0.875rem; margin-bottom: 0; }

        /* KPIs / Stat Cards Grid */
        .kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.25rem; margin-bottom: 2rem; }
        .kpi-card { background-color: var(--card-bg); border-radius: var(--radius-lg); padding: 1.25rem; box-shadow: var(--shadow-md); position: relative; overflow: hidden; transition: transform 0.2s ease-out; border-top: 4px solid var(--secondary); /* Default border */ }
        .kpi-card:hover { transform: translateY(-4px); box-shadow: 0 8px 15px rgba(0,0,0,0.1); }
        .kpi-label { display: block; font-size: 0.8rem; font-weight: 500; color: var(--text-secondary); margin-bottom: 0.5rem; text-transform: uppercase; letter-spacing: 0.5px;}
        .kpi-value { display: block; font-size: 1.85rem; font-weight: 700; color: var(--text-primary); line-height: 1.2; margin-bottom: 0.25rem; }
        .kpi-subtext { display: block; font-size: 0.75rem; color: var(--text-muted); }
        .kpi-value.currency { font-size: 1.6rem; }
        /* KPI Border Colors */
        .kpi-total-revenue { border-top-color: var(--primary); }
        .kpi-outstanding { border-top-color: var(--warning); }
        .kpi-overdue { border-top-color: var(--danger); }
        .kpi-paid { border-top-color: var(--success); }
        .kpi-average { border-top-color: var(--info); }
        .kpi-clients { border-top-color: var(--secondary); }

        /* Charts & Tables Layout */
        .main-layout-grid { display: grid; grid-template-columns: repeat(3, 1fr); /* 3 columns */ gap: 1.5rem; margin-bottom: 1.5rem; }
        .content-block { background-color: var(--card-bg); border-radius: var(--radius-lg); padding: 1.5rem; box-shadow: var(--shadow-md); }
        .content-block.col-span-1 { grid-column: span 1; }
        .content-block.col-span-2 { grid-column: span 2; }
        .content-block.col-span-3 { grid-column: span 3; }
        .content-title { font-size: 1.2rem; font-weight: 600; margin-bottom: 1.5rem; color: var(--text-primary); padding-bottom: 0.75rem; border-bottom: 1px solid var(--border-color); }
        .chart-wrapper { position: relative; height: 320px; width: 100%; /* Control aspect ratio via height */ }
        .chart-wrapper.doughnut { height: 280px; max-width: 280px; margin: 0 auto; /* Center doughnut */ }

        /* Data Tables Styling */
        .table-responsive { width: 100%; overflow-x: auto; /* Always allow horizontal scroll */ max-height: 450px; /* Limit height with vertical scroll */ }
        .data-table { width: 100%; border-collapse: collapse; }
        .data-table thead th { position: sticky; top: 0; background-color: var(--light); /* Header sticks */ z-index: 10; font-size: 0.8rem; padding: 0.6rem 0.8rem; text-align: left; font-weight: 600; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 2px solid var(--border-color);}
        .data-table tbody tr:nth-child(even) { background-color: #f9fafb; /* Subtle striping */ }
        .data-table tbody tr:hover { background-color: #f0f9ff; /* Light blue hover */ }
        .data-table td { padding: 0.6rem 0.8rem; border-bottom: 1px solid var(--border-color); font-size: 0.85rem; vertical-align: middle; color: var(--text-primary);}
        .data-table td.currency, .data-table th.currency { text-align: right; white-space: nowrap; }
        .data-table td.centered, .data-table th.centered { text-align: center; }
        .data-table a { color: var(--primary); text-decoration: none; } .data-table a:hover { text-decoration: underline; }
        .data-table .days-overdue { font-weight: 600; color: var(--danger); }
        /* Badge Styles (copied/adapted from index.php CSS if needed) */
        .status-badge { display: inline-block; padding: 0.25em 0.6em; font-size: 0.7rem; font-weight: 600; line-height: 1; text-align: center; white-space: nowrap; vertical-align: middle; border-radius: 0.25rem; text-transform: uppercase; }
        .status-paid { background-color: var(--color-paid); color: white; }
        .status-unpaid { background-color: var(--color-unpaid); color: white; }
        .status-partially_paid { background-color: var(--color-partial); color: #422006;}
        .no-data { padding: 2rem; text-align: center; color: var(--text-muted); }

        /* Responsive Adjustments */
         @media (max-width: 1200px) { .main-layout-grid { grid-template-columns: repeat(2, 1fr); } .content-block.col-span-3 { grid-column: span 2; } }
         @media (max-width: 768px) {
            .container { padding: 1rem; }
            .kpi-grid { grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); }
            .kpi-value { font-size: 1.5rem; } .kpi-value.currency { font-size: 1.3rem;}
            .main-layout-grid { grid-template-columns: 1fr; } /* Stack all blocks */
            .content-block.col-span-1, .content-block.col-span-2, .content-block.col-span-3 { grid-column: span 1; }
            .chart-wrapper { height: 250px; } .chart-wrapper.doughnut { height: 220px; max-width: 220px; }
         }
        /* Print Styles (similar to previous, ensure it covers new elements) */
         @media print { /* Basic print styles */
            body { background: white !important; color: black !important; font-size: 9pt; }
            .container { max-width: 100%; padding: 0.5cm; }
            .page-header, .filter-section, .btn { display: none !important; }
             .kpi-grid, .main-layout-grid, .content-block { display: block !important; box-shadow: none !important; border: 1px solid #eee !important; padding: 0.5cm !important; margin-bottom: 1cm !important; page-break-inside: avoid; }
             .kpi-card { border-top: 2px solid black !important; text-align: left; }
             .chart-wrapper { height: auto !important; max-height: 7cm; }
             canvas { max-width: 100%; max-height: 7cm; }
             .table-responsive { max-height: none; overflow: visible;}
             .data-table thead th { position: static; }
             @page { size: A4 portrait; margin: 1cm; }
         }

    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="page-header">
            <div class="page-title">
                <h1>Advanced Reporting Dashboard</h1>
                <p>Insights from <?php echo h($start_date); ?> to <?php echo h($end_date); ?></p>
            </div>
            <div class="user-menu">
                 <a href="index.php" class="btn btn-outline btn-sm">← Dashboard</a>
                <span class="user-name ml-2">User: <?php echo h($username); ?></span>
                <a href="logout.php" class="btn btn-outline btn-sm">Sign Out</a>
            </div>
        </div>

        <!-- Date Filter Form -->
        <div class="filter-section">
            <form method="GET" action="reports.php" class="filter-form">
                 <div>
                    <label for="start_date">Report Start Date:</label>
                    <input type="date" id="start_date" name="start_date" value="<?php echo h($start_date); ?>" required>
                </div>
                <div>
                    <label for="end_date">Report End Date:</label>
                    <input type="date" id="end_date" name="end_date" value="<?php echo h($end_date); ?>" required>
                </div>
                <button type="submit" class="btn btn-primary btn-sm ml-auto">Update Report</button>
            </form>
        </div>

        <!-- Error Display -->
        <?php if ($report_error): ?>
             <div class="alert alert-danger" style="background: #fee2e2; border-left: 4px solid var(--danger); color: #991b1b; padding: 1rem; margin-bottom:1.5rem; border-radius: var(--radius-lg);"><?php echo h($report_error); ?></div>
        <?php endif; ?>

        <!-- KPI Cards Grid -->
        <div class="kpi-grid">
            <div class="kpi-card kpi-total-revenue">
                <span class="kpi-label">Total Invoiced</span>
                <span class="kpi-value currency">₹<?php echo format_currency($kpis['total_invoiced']); ?></span>
                <span class="kpi-subtext"><?php echo h($kpis['total_invoice_count']); ?> invoices</span>
            </div>
            <div class="kpi-card kpi-outstanding">
                <span class="kpi-label">Outstanding Receivables</span>
                <span class="kpi-value currency">₹<?php echo format_currency($kpis['outstanding_receivables']); ?></span>
                <span class="kpi-subtext"><?php echo h($kpis['unpaid_invoice_count'] + $kpis['partial_invoice_count']); ?> invoices</span>
            </div>
            <div class="kpi-card kpi-overdue">
                 <span class="kpi-label">Total Overdue</span>
                 <span class="kpi-value currency">₹<?php echo format_currency($kpis['overdue_amount']); ?></span>
                 <span class="kpi-subtext"><?php echo h($kpis['overdue_count']); ?> invoices</span>
            </div>
             <div class="kpi-card kpi-paid">
                <span class="kpi-label">Invoices Paid in Period</span>
                <span class="kpi-value"><?php echo h($kpis['paid_invoice_count']); ?></span>
                <span class="kpi-subtext">Rate: <?php echo $kpis['total_invoice_count'] > 0 ? round(($kpis['paid_invoice_count'] / $kpis['total_invoice_count']) * 100).'%' : 'N/A'; ?></span>
             </div>
              <div class="kpi-card kpi-average">
                 <span class="kpi-label">Avg. Invoice Value</span>
                 <span class="kpi-value currency">₹<?php echo format_currency($kpis['avg_invoice_value']); ?></span>
                  <span class="kpi-subtext">Period average</span>
             </div>
            <div class="kpi-card kpi-clients">
                <span class="kpi-label">Total Clients</span>
                <span class="kpi-value"><?php echo h($client_kpis['total_active_clients']); ?></span>
                <span class="kpi-subtext">All time</span>
             </div>
        </div>

        <!-- Main Content Grid (Charts & Tables) -->
        <div class="main-layout-grid">

            <!-- Aging Summary -->
             <div class="content-block col-span-1">
                <h3 class="content-title">Receivable Aging</h3>
                 <div class="chart-wrapper">
                     <canvas id="agingChart"></canvas>
                 </div>
            </div>

            <!-- Invoice Status Breakdown -->
            <div class="content-block col-span-1">
                 <h3 class="content-title">Invoice Status (Period)</h3>
                 <div class="chart-wrapper doughnut">
                     <canvas id="statusChart"></canvas>
                </div>
             </div>

             <!-- Top Clients -->
             <div class="content-block col-span-1">
                <h3 class="content-title">Top Clients (Revenue)</h3>
                 <div class="chart-wrapper">
                    <canvas id="topClientsChart"></canvas>
                </div>
             </div>

             <!-- Monthly Revenue Trend -->
            <div class="content-block col-span-3">
                 <h3 class="content-title">Monthly Revenue Trend</h3>
                 <div class="chart-wrapper">
                     <canvas id="monthlyRevenueChart"></canvas>
                </div>
             </div>

            <!-- Recent Invoices Table -->
            <div class="content-block col-span-3">
                 <h3 class="content-title">Recent Invoices in Period</h3>
                 <div class="table-responsive">
                    <?php if (!empty($recent_invoices_table)): ?>
                         <table class="data-table">
                             <thead>
                                <tr>
                                    <th>Invoice #</th> <th>Date</th> <th>Client</th>
                                    <th class="currency">Amount (₹)</th> <th class="centered">Status</th>
                                 </tr>
                             </thead>
                            <tbody>
                                 <?php foreach ($recent_invoices_table as $inv):
                                     $status_val = strtolower(trim($inv['status'] ?? ''));
                                     $status_class = 'status-default'; $status_text = 'Unknown';
                                      if ($status_val === 'paid') { $status_class = 'status-paid'; $status_text = 'Paid'; }
                                      elseif ($status_val === 'unpaid') { $status_class = 'status-unpaid'; $status_text = 'Unpaid'; }
                                      elseif ($status_val === 'partially_paid') { $status_class = 'status-partially_paid'; $status_text = 'Partially Paid'; }
                                 ?>
                                 <tr>
                                     <td><a href="edit_invoice.php?id=<?php echo $inv['id']; ?>" title="Edit Invoice"><?php echo h($inv['invoice_number']); ?></a></td>
                                     <td><?php echo h(date('d M, Y', strtotime($inv['invoice_date']))); ?></td>
                                     <td><?php echo h($inv['client_name'] ?? 'N/A'); ?></td>
                                     <td class="currency"><?php echo format_currency($inv['total_amount']); ?></td>
                                     <td class="centered"><span class="status-badge <?php echo $status_class; ?>"><?php echo $status_text; ?></span></td>
                                 </tr>
                                 <?php endforeach; ?>
                            </tbody>
                         </table>
                    <?php else: ?> <p class="no-data">No invoices found in the selected period.</p> <?php endif; ?>
                 </div>
             </div>

              <!-- Overdue Invoices Table -->
             <div class="content-block col-span-3">
                <h3 class="content-title">Overdue Invoices</h3>
                 <div class="table-responsive">
                     <?php if (!empty($overdue_invoices_table)): ?>
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Invoice #</th> <th>Client</th> <th>Due Date</th>
                                     <th class="centered">Days Overdue</th> <th class="currency">Amount Due (₹)</th>
                                </tr>
                            </thead>
                             <tbody>
                                <?php foreach ($overdue_invoices_table as $inv): ?>
                                 <tr>
                                     <td><a href="edit_invoice.php?id=<?php echo $inv['id']; ?>" title="Edit Invoice"><?php echo h($inv['invoice_number']); ?></a></td>
                                     <td><?php echo h($inv['client_name'] ?? 'N/A'); ?></td>
                                     <td><?php echo h(date('d M, Y', strtotime($inv['due_date']))); ?></td>
                                     <td class="centered days-overdue"><?php echo h($inv['days_overdue']); ?></td>
                                     <td class="currency"><?php echo format_currency($inv['amount_due']); ?></td>
                                </tr>
                                 <?php endforeach; ?>
                            </tbody>
                        </table>
                     <?php else: ?> <p class="no-data">No overdue invoices found matching criteria.</p> <?php endif; ?>
                </div>
             </div>

        </div> <!-- End Main Content Grid -->

    </div><!-- End Container -->

    <script>
        // Helper function to format currency in JS (can customize locale)
         const currencyFormatter = new Intl.NumberFormat('en-IN', {
             style: 'currency', currency: 'INR', minimumFractionDigits: 2, maximumFractionDigits: 2,
         });
        function formatJsCurrency(value) { return currencyFormatter.format(value); }

        // Shared Chart.js Configuration Options
        const chartDefaultOptions = {
             responsive: true, maintainAspectRatio: false,
            plugins: {
                 legend: { display: false }, // Usually customize per chart if needed
                 tooltip: {
                     backgroundColor: 'rgba(0, 0, 0, 0.8)', titleFont: { size: 13 }, bodyFont: { size: 12 },
                     padding: 10, cornerRadius: 3, displayColors: false, // Simpler tooltip
                    callbacks: { // Default label callback (can be overridden)
                        label: (context) => `${context.dataset.label || ''}: ${context.formattedValue}`
                     }
                 }
             },
            scales: { // Default scale options (can be overridden)
                y: { beginAtZero: true, grid: { color: '#e5e7eb' }, ticks: { font: {size: 11} } },
                 x: { grid: { display: false }, ticks: { font: {size: 11} } }
             },
             // interaction: { mode: 'index', intersect: false }, // Useful for multi-line/bar charts
            animation: { duration: 800, easing: 'easeInOutQuart' } // Add subtle animation
        };

        // Deep merge function for Chart options (simplified)
        function mergeOptions(...options) {
            let result = {};
            options.forEach(opt => {
                for (let key in opt) {
                    if (typeof opt[key] === 'object' && opt[key] !== null && !Array.isArray(opt[key]) && typeof result[key] === 'object') {
                         result[key] = mergeOptions(result[key], opt[key]); // Recursive merge for nested objects like plugins/scales
                    } else { result[key] = opt[key]; } // Otherwise, just assign
                 }
             });
             return result;
        }


        document.addEventListener('DOMContentLoaded', () => {
             // Chart Colors (defined in PHP CSS but useful here)
             const chartColors = {
                paid: '#22c55e', unpaid: '#ef4444', partial: '#f59e0b', primary: '#1e40af', secondary: '#64748b', info: '#2563eb', warning: '#f59e0b',
                aging: ['#3b82f6', '#a3e635', '#facc15', '#fb923c', '#f87171'] // current, 1-30, 31-60, 61-90, 90+
            };

            // --- Aging Summary Chart (Bar) ---
             const agingCtx = document.getElementById('agingChart')?.getContext('2d');
             if (agingCtx) {
                const agingData = <?php echo json_encode(array_values($aging_summary)); ?>; // Use array values
                const agingLabels = <?php echo json_encode(array_keys($aging_summary)); ?>; // Use array keys for labels
                const hasAgingData = agingData.some(v => v > 0);

                 if(hasAgingData){
                    new Chart(agingCtx, {
                        type: 'bar',
                        data: {
                             labels: ['Current', '1-30d', '31-60d', '61-90d', '90d +'], // Simplified labels
                             datasets: [{
                                 label: 'Amount Due (₹)', data: agingData,
                                backgroundColor: chartColors.aging, // Use palette
                                borderWidth: 0
                            }]
                         },
                         options: mergeOptions(chartDefaultOptions, {
                             plugins: { tooltip: { callbacks: { label: (ctx) => `Amount Due: ${formatJsCurrency(ctx.parsed.y)}` } } },
                            scales: { y: { ticks: { callback: (v) => formatJsCurrency(v) } } } // Format Y axis as currency
                         })
                    });
                } else { agingCtx.canvas.parentNode.innerHTML = '<p class="no-data">No outstanding receivables.</p>'; }
             }

             // --- Status Doughnut Chart ---
             const statusCtx = document.getElementById('statusChart')?.getContext('2d');
             if (statusCtx) {
                const statusData = <?php echo json_encode($status_chart_data, JSON_NUMERIC_CHECK); ?>;
                const statusLabels = <?php echo json_encode($status_chart_labels); ?>;
                 const totalStatus = statusData.reduce((a, b) => a + b, 0);

                if (totalStatus > 0) {
                     new Chart(statusCtx, {
                         type: 'doughnut',
                        data: { labels: statusLabels, datasets: [{ data: statusData, backgroundColor: [chartColors.paid, chartColors.unpaid, chartColors.partial], borderWidth: 1, borderColor: '#fff' }] },
                        options: mergeOptions(chartDefaultOptions, {
                            cutout: '65%',
                             plugins: {
                                 legend: { position: 'bottom', labels: { padding: 15, boxWidth: 12, font: { size: 11 } } },
                                 tooltip: { callbacks: { label: (ctx) => `${ctx.label}: ${ctx.parsed} (${totalStatus > 0 ? ((ctx.parsed / totalStatus) * 100).toFixed(1) + '%' : '0%'})` } }
                             }
                        })
                    });
                } else { statusCtx.canvas.parentNode.innerHTML = '<p class="no-data">No invoice data for this period.</p>'; }
             }

            // --- Top Clients Bar Chart ---
            const topClientsCtx = document.getElementById('topClientsChart')?.getContext('2d');
            if (topClientsCtx) {
                 const topClientsData = <?php echo json_encode($top_clients_data, JSON_NUMERIC_CHECK); ?>;
                 const topClientsLabels = <?php echo json_encode($top_clients_labels); ?>;

                if (topClientsData.length > 0) {
                     new Chart(topClientsCtx, {
                         type: 'bar',
                         data: { labels: topClientsLabels, datasets: [{ label: 'Total Billed (₹)', data: topClientsData, backgroundColor: chartColors.info, borderWidth: 0 }] },
                         options: mergeOptions(chartDefaultOptions, {
                             indexAxis: 'y', // Horizontal bars are good for client names
                            scales: { x: { ticks: { callback: (v) => formatJsCurrency(v) } } },
                             plugins: { tooltip: { callbacks: { label: (ctx) => `${ctx.dataset.label}: ${formatJsCurrency(ctx.parsed.x)}` } } }
                        })
                     });
                } else { topClientsCtx.canvas.parentNode.innerHTML = '<p class="no-data">No client revenue data found.</p>'; }
            }


             // --- Monthly Revenue Line Chart ---
             const monthlyCtx = document.getElementById('monthlyRevenueChart')?.getContext('2d');
             if (monthlyCtx) {
                 const monthlyData = <?php echo json_encode($monthly_chart_data, JSON_NUMERIC_CHECK); ?>;
                 const monthlyLabels = <?php echo json_encode($monthly_chart_labels); ?>;
                const hasRevenueData = monthlyData.some(v => v > 0);

                if (hasRevenueData) {
                     new Chart(monthlyCtx, {
                         type: 'line', // Changed to line chart for trend
                         data: {
                             labels: monthlyLabels,
                             datasets: [{
                                label: 'Total Revenue (₹)', data: monthlyData,
                                backgroundColor: 'rgba(30, 64, 175, 0.1)', // Light fill under line
                                borderColor: chartColors.primary,
                                 pointBackgroundColor: chartColors.primary, pointBorderColor: '#fff', pointHoverRadius: 6,
                                pointRadius: 4, pointHitRadius: 10,
                                borderWidth: 2, tension: 0.2 // Smooth curve
                            }]
                         },
                         options: mergeOptions(chartDefaultOptions, {
                             scales: { y: { ticks: { callback: (v) => formatJsCurrency(v) } } }, // Format Y axis
                            plugins: {
                                legend: { display: false },
                                tooltip: { callbacks: { label: (ctx) => `${ctx.dataset.label}: ${formatJsCurrency(ctx.parsed.y)}` } } // Format tooltips
                             },
                             interaction: { mode: 'index', intersect: false }, // Show tooltip on index hover
                        })
                     });
                 } else { monthlyCtx.canvas.parentNode.innerHTML = '<p class="no-data">No revenue data found for this period.</p>'; }
             }
        });
    </script>

</body>
</html>