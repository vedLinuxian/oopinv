<?php
// Include database configuration and start session
require_once 'db_config.php';

// Check if the user is logged in, redirect if not
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}

// Get user information
$user_id = $_SESSION["id"];
$username = $_SESSION["username"];

// Helper function
function h($text) { return htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8'); }

// Define available fields, operators, etc. for the builder
// (This should ideally be more dynamic, maybe fetched based on selected report type)
$available_invoice_fields = [
    'invoice_number' => 'Invoice Number',
    'invoice_date' => 'Invoice Date',
    'due_date' => 'Due Date',
    'client_id' => 'Client ID', // Might join to get name
    'client_name' => 'Client Name (Joined)', // Example of joined field
    'total_amount' => 'Total Amount',
    'advance_paid' => 'Advance Paid',
    'amount_due' => 'Amount Due (Calculated)', // Requires calculation in SQL
    'status' => 'Status',
    'hsn_code' => 'HSN/SAC',
    'po_number' => 'PO Number',
    'cgst_amount' => 'CGST Amount',
    'sgst_amount' => 'SGST Amount',
    'created_at' => 'Creation Date',
];
$available_client_fields = [
    'name' => 'Client Name',
    'gstin' => 'GSTIN',
    'state' => 'State',
    'state_code' => 'State Code',
    'email' => 'Email',
    'phone' => 'Phone',
    'created_at' => 'Creation Date',
    // Could add calculated fields like 'total_invoiced_amount', 'invoice_count'
];
// Define others for Banks if needed

$operators = [
    '=' => 'Equals (=)',
    '!=' => 'Not Equals (!=)',
    '<' => 'Less Than (<)',
    '<=' => 'Less Than or Equal (<=)',
    '>' => 'Greater Than (>)',
    '>=' => 'Greater Than or Equal (>=)',
    'LIKE' => 'Contains (LIKE %...%)',
    'NOT LIKE' => 'Does Not Contain (NOT LIKE %...%)',
    'STARTS WITH' => 'Starts With (LIKE ...%)',
    'ENDS WITH' => 'Ends With (LIKE %...)',
    'IS NULL' => 'Is Empty (IS NULL)',
    'IS NOT NULL' => 'Is Not Empty (IS NOT NULL)',
    'BETWEEN' => 'Is Between (Requires 2 values)',
    'NOT BETWEEN' => 'Is Not Between (Requires 2 values)',
    'IN' => 'Is One Of (Comma-separated list)',
    'NOT IN' => 'Is Not One Of (Comma-separated list)',
];

$aggregations = [
    'SUM' => 'Sum',
    'COUNT' => 'Count',
    'COUNT_DISTINCT' => 'Count Distinct',
    'AVG' => 'Average',
    'MIN' => 'Minimum',
    'MAX' => 'Maximum',
];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Query Builder - GST Invoice Generator</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <style>
        /* Reuse common styles from other files */
        :root {
            --primary: #1e40af; --primary-light: #3b82f6; --primary-dark: #1e3a8a;
            --secondary: #64748b; --accent: #f59e0b; --danger: #ef4444; --success: #10b981;
            --warning: #f59e0b; --info: #3b82f6; --light: #f8fafc; --dark: #1e293b;
            --body-bg: #f1f5f9; --card-bg: #ffffff; --border-color: #e2e8f0;
            --text-primary: #334155; --text-secondary: #64748b; --text-muted: #94a3b8;
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --radius: 0.25rem; --radius-md: 0.375rem; --radius-lg: 0.5rem;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Poppins', sans-serif; background-color: var(--body-bg); color: var(--text-primary); line-height: 1.6; font-size: 14px; }
        .container { max-width: 1400px; margin: 0 auto; padding: 2rem; } /* Wider */
        .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; padding-bottom: 1rem; border-bottom: 1px solid var(--border-color); }
        .page-title h1 { font-size: 1.75rem; font-weight: 700; color: var(--primary); margin-bottom: 0.25rem; }
        .user-menu { display: flex; align-items: center; gap: 1rem; }
        .user-name { font-weight: 500; }
        .card { background: var(--card-bg); border-radius: var(--radius-lg); box-shadow: var(--shadow-md); overflow: hidden; margin-bottom: 1.5rem; }
        .card-body { padding: 1.5rem; }
        .builder-section { margin-bottom: 2rem; padding-bottom: 1.5rem; border-bottom: 1px dashed var(--border-color); }
        .builder-section-title { font-size: 1.1rem; font-weight: 600; margin-bottom: 1rem; color: var(--primary-dark); }
        .form-group { margin-bottom: 1rem; }
        .form-row { display: flex; flex-wrap: wrap; gap: 1rem; align-items: flex-start; /* Align items to top */ }
        .form-col { flex: 1; min-width: 180px; }
        label { display: block; font-weight: 500; margin-bottom: 0.5rem; font-size: 0.875rem; }
        select, input[type="text"], input[type="date"], input[type="number"] { width: 100%; padding: 0.625rem 0.75rem; border: 1px solid var(--border-color); border-radius: var(--radius); font-family: inherit; font-size: 0.875rem; transition: border-color 0.2s ease, box-shadow 0.2s ease; }
        select:focus, input:focus { outline: none; border-color: var(--primary-light); box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.25); }
        select[multiple] { min-height: 100px; }
        .checkbox-group label { display: inline-block; margin-right: 1rem; font-weight: 400; }
        .checkbox-group input[type="checkbox"] { margin-right: 0.3rem; vertical-align: middle; }
        .btn { /* Copied from bank.php */ display: inline-flex; align-items: center; justify-content: center; padding: 0.5rem 1rem; border-radius: var(--radius); font-weight: 500; cursor: pointer; transition: all 0.2s ease; border: 1px solid transparent; font-size: 0.875rem; text-decoration: none; white-space: nowrap; }
        .btn-primary { background-color: var(--primary); color: white; } .btn-primary:hover:not(:disabled) { background-color: var(--primary-dark); }
        .btn-danger { background-color: var(--danger); color: white; } .btn-danger:hover:not(:disabled) { background-color: #dc2626; }
        .btn-sm { padding: 0.25rem 0.625rem; font-size: 0.75rem; }
        .filter-row { display: flex; gap: 0.75rem; margin-bottom: 0.75rem; padding: 0.75rem; background-color: var(--light); border: 1px solid var(--border-color); border-radius: var(--radius-md); align-items: center; }
        .filter-row select, .filter-row input { margin-bottom: 0; }
        .filter-row .form-col { flex-grow: 1; }
        .filter-row .value-col { flex-grow: 2; } /* Make value input wider */
        .filter-row .remove-btn-col { flex-grow: 0; flex-shrink: 0; }
        #report-results { margin-top: 2rem; }
        #results-table-container { max-height: 600px; overflow: auto; }
        #results-table { width: 100%; border-collapse: collapse; }
        #results-table th, #results-table td { padding: 0.6rem 0.8rem; border: 1px solid var(--border-color); text-align: left; font-size: 0.85rem; }
        #results-table th { background-color: var(--light); font-weight: 600; position: sticky; top: 0; }
        #results-chart-container { display: none; /* Initially hidden */ min-height: 300px; }
        .loading-overlay { display: none; position: absolute; inset: 0; background: rgba(255,255,255,0.7); align-items: center; justify-content: center; font-weight: 600; color: var(--primary); z-index: 10; }
        #results-container { position: relative; } /* Needed for overlay */
         /* Toast styles - copy from bank.php if needed */
         #toast-container { position: fixed; top: 1rem; right: 1rem; z-index: 9999; width: 320px; }
         .toast { background-color: white; border-radius: var(--radius); box-shadow: var(--shadow-md); margin-bottom: 0.75rem; overflow: hidden; border-left: 4px solid var(--dark); animation: slideInRight 0.3s ease-out, fadeOut 0.5s ease-out 4.5s forwards; }
         .toast-header { padding: 0.5rem 1rem; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--border-color); } .toast-title { font-weight: 600; font-size: 0.875rem; } .toast-close { background: transparent; border: none; font-size: 1.25rem; line-height: 1; cursor: pointer; color: var(--text-secondary); opacity: 0.7;} .toast-close:hover { opacity: 1; } .toast-body { padding: 0.75rem 1rem; font-size: 0.875rem;}
         .toast-success { border-left-color: var(--success); } .toast-error { border-left-color: var(--danger); } .toast-warning { border-left-color: var(--warning); }
         @keyframes slideInRight { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
         @keyframes fadeOut { from { opacity: 1; } to { opacity: 0; } }
    </style>
</head>
<body>
    <div class="container">
        <div class="page-header">
            <div class="page-title">
                <h1>Advanced Report Builder</h1>
            </div>
            <div class="user-menu">
                <a href="index.php" class="btn btn-outline btn-sm">← Dashboard</a>
                <span class="user-name">User: <?php echo h($username); ?></span>
                <a href="logout.php" class="btn btn-outline btn-sm">Sign Out</a>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <form id="query-builder-form" onsubmit="generateReport(event)">

                    <!-- 1. Report Type / Main Subject -->
                    <div class="builder-section">
                        <h3 class="builder-section-title">1. Select Report Subject</h3>
                        <div class="form-group">
                            <label for="report_subject">Show data about:</label>
                            <select id="report_subject" name="report_subject" onchange="updateAvailableFields()">
                                <option value="invoices" selected>Invoices</option>
                                <option value="clients">Clients</option>
                                <!-- <option value="company_banks">Bank Accounts</option> -->
                                <!-- Add other primary tables here -->
                            </select>
                        </div>
                    </div>

                    <!-- 2. Columns to Display -->
                    <div class="builder-section">
                        <h3 class="builder-section-title">2. Choose Columns to Display</h3>
                        <div class="form-group">
                            <label for="select_columns">Select Fields:</label>
                            <select id="select_columns" name="select_columns[]" multiple size="8">
                                <!-- Options will be populated by JS based on report_subject -->
                            </select>
                            <small class="text-muted">Hold Ctrl/Cmd to select multiple fields.</small>
                        </div>
                    </div>

                    <!-- 3. Filters / Conditions -->
                    <div class="builder-section">
                        <h3 class="builder-section-title">3. Filter Data (Optional)</h3>
                        <div id="filter-container">
                            <!-- Filter rows will be added here by JS -->
                        </div>
                        <button type="button" class="btn btn-sm btn-outline" onclick="addFilterRow()">+ Add Filter Condition</button>
                    </div>

                    <!-- 4. Grouping & Aggregation -->
                    <div class="builder-section">
                        <h3 class="builder-section-title">4. Group & Summarize (Optional)</h3>
                        <div class="form-row">
                            <div class="form-col">
                                <label for="group_by">Group By Field:</label>
                                <select id="group_by" name="group_by">
                                    <option value="">-- No Grouping --</option>
                                    <!-- Options populated by JS -->
                                </select>
                            </div>
                            <div class="form-col">
                                 <label for="aggregate_function">Summarize using:</label>
                                 <select id="aggregate_function" name="aggregate_function" disabled>
                                     <option value="">-- Select Function --</option>
                                     <?php foreach ($aggregations as $key => $label): ?>
                                         <option value="<?php echo h($key); ?>"><?php echo h($label); ?></option>
                                     <?php endforeach; ?>
                                 </select>
                             </div>
                            <div class="form-col">
                                <label for="aggregate_field">Summarize Field:</label>
                                <select id="aggregate_field" name="aggregate_field" disabled>
                                     <option value="">-- Select Field --</option>
                                    <!-- Options populated by JS -->
                                </select>
                                <small class="text-muted">Required if grouping/summarizing.</small>
                             </div>
                        </div>
                         <small class="text-muted">Note: If grouping, you should typically select the 'Group By' field and the 'Summarize Field' in step 2 (Columns).</small>
                    </div>

                    <!-- 5. Sorting -->
                    <div class="builder-section">
                         <h3 class="builder-section-title">5. Sort Results (Optional)</h3>
                         <div class="form-row">
                             <div class="form-col">
                                <label for="sort_by">Sort By Field:</label>
                                <select id="sort_by" name="sort_by">
                                     <option value="">-- Default Order --</option>
                                     <!-- Options populated by JS -->
                                </select>
                            </div>
                            <div class="form-col">
                                 <label for="sort_direction">Sort Direction:</label>
                                 <select id="sort_direction" name="sort_direction">
                                     <option value="ASC">Ascending (A-Z, 1-9)</option>
                                     <option value="DESC">Descending (Z-A, 9-1)</option>
                                </select>
                             </div>
                         </div>
                    </div>

                    <!-- 6. Output Format -->
                    <div class="builder-section">
                         <h3 class="builder-section-title">6. Output Format</h3>
                         <div class="form-group checkbox-group">
                             <label><input type="radio" name="output_format" value="table" checked> Table</label>
                             <label><input type="radio" name="output_format" value="chart_bar"> Bar Chart</label>
                             <label><input type="radio" name="output_format" value="chart_line"> Line Chart</label>
                             <!-- Add more chart types if needed -->
                             <small class="text-muted d-block">Note: Charts work best with grouped/summarized data with one category (group by) and one numeric value (summarize field).</small>
                         </div>
                    </div>


                    <!-- Submit Button -->
                    <div class="action-buttons" style="border-top: 1px solid var(--border-color); padding-top: 1.5rem; margin-top: 1rem;">
                        <button type="submit" class="btn btn-primary" id="generate-report-btn">Generate Report</button>
                    </div>

                </form>
            </div>
        </div>

        <!-- Results Area -->
        <div id="report-results" class="card" style="display: none;">
            <div class="card-body">
                <h2 class="builder-section-title">Report Results</h2>
                <div id="results-container">
                    <div class="loading-overlay" id="loading-indicator">Generating...</div>
                    <div id="results-table-container">
                         <table id="results-table">
                             <thead id="results-table-head"></thead>
                             <tbody id="results-table-body"></tbody>
                         </table>
                    </div>
                    <div id="results-chart-container">
                        <canvas id="results-chart"></canvas>
                    </div>
                    <div id="no-results" style="display: none; padding: 2rem; text-align: center;" class="text-muted">No data found matching your criteria.</div>
                </div>
            </div>
        </div>

    </div> <!-- End Container -->

    <!-- Toast Container -->
    <div id="toast-container"></div>

    <script>
        // --- Global Variables & Config ---
        const availableFields = {
            invoices: <?php echo json_encode($available_invoice_fields); ?>,
            clients: <?php echo json_encode($available_client_fields); ?>,
            // company_banks: { ... } // Add bank fields if needed
        };
        const operators = <?php echo json_encode($operators); ?>;
        let currentReportChart = null; // To hold the Chart.js instance

        // --- DOM Elements ---
        const reportSubjectSelect = document.getElementById('report_subject');
        const selectColumnsSelect = document.getElementById('select_columns');
        const filterContainer = document.getElementById('filter-container');
        const groupBySelect = document.getElementById('group_by');
        const aggregateFunctionSelect = document.getElementById('aggregate_function');
        const aggregateFieldSelect = document.getElementById('aggregate_field');
        const sortBySelect = document.getElementById('sort_by');
        const reportResultsDiv = document.getElementById('report-results');
        const resultsTableContainer = document.getElementById('results-table-container');
        const resultsTableHead = document.getElementById('results-table-head');
        const resultsTableBody = document.getElementById('results-table-body');
        const resultsChartContainer = document.getElementById('results-chart-container');
        const resultsChartCanvas = document.getElementById('results-chart');
        const noResultsDiv = document.getElementById('no-results');
        const loadingIndicator = document.getElementById('loading-indicator');
        const toastContainer = document.getElementById('toast-container'); // Added

        // --- Utility Functions ---
        function escapeHtml(unsafe) { /* ... copy from bank.php ... */
             if (typeof unsafe !== 'string') return unsafe;
             const map = { '&': '&', '<': '<', '>': '>', '"': '"', "'": '&#039' };
             return unsafe.replace(/[&<>"']/g, m => map[m]);
        }
        function showToast(title, message, type = 'info') { /* ... copy from bank.php ... */
             const toast = document.createElement('div');
             toast.className = `toast toast-${type}`;
             let icon = type === 'success' ? '✓' : (type === 'error' ? '✗' : (type === 'warning' ? '⚠️' : 'ℹ️'));
             toast.innerHTML = `<div class="toast-header"><span class="toast-title">${icon} ${escapeHtml(title)}</span><button type="button" class="toast-close" onclick="this.parentElement.parentElement.remove()">×</button></div><div class="toast-body">${escapeHtml(message)}</div>`;
             if(toastContainer) toastContainer.appendChild(toast);
        }

        // --- Builder UI Logic ---

        function updateAvailableFields() {
            const subject = reportSubjectSelect.value;
            const fields = availableFields[subject] || {};
            populateSelectWithOptions(selectColumnsSelect, fields, false); // Allow multiple selection
            populateSelectWithOptions(groupBySelect, fields, true, '-- No Grouping --');
             populateSelectWithOptions(aggregateFieldSelect, fields, true, '-- Select Field --'); // Initially disabled, enabled if grouping
            populateSelectWithOptions(sortBySelect, fields, true, '-- Default Order --');
            // Reset filters when subject changes
            filterContainer.innerHTML = '';
            // Reset aggregation selects
             aggregateFunctionSelect.value = '';
             aggregateFunctionSelect.disabled = true;
             aggregateFieldSelect.value = '';
             aggregateFieldSelect.disabled = true;
        }

        function populateSelectWithOptions(selectElement, options, includeBlank = true, blankText = '-- Select --') {
            if (!selectElement) return;
            const currentVal = selectElement.value; // Preserve single selection if possible
            selectElement.innerHTML = ''; // Clear existing options

            if (includeBlank) {
                const blankOpt = document.createElement('option');
                blankOpt.value = '';
                blankOpt.textContent = blankText;
                selectElement.appendChild(blankOpt);
            }

            for (const key in options) {
                const option = document.createElement('option');
                option.value = key;
                option.textContent = options[key];
                selectElement.appendChild(option);
            }
             // Try to restore previous single selection
             if(!selectElement.multiple && selectElement.querySelector(`option[value="${currentVal}"]`)) {
                selectElement.value = currentVal;
             }
        }

        function addFilterRow() {
            const subject = reportSubjectSelect.value;
            const fields = availableFields[subject] || {};
            const filterId = Date.now(); // Unique ID for the row elements

            const row = document.createElement('div');
            row.className = 'filter-row';
            row.id = `filter-row-${filterId}`;

            // Field Select
            const fieldCol = document.createElement('div');
            fieldCol.className = 'form-col';
            const fieldSelect = document.createElement('select');
            fieldSelect.name = `filters[${filterId}][field]`;
            fieldSelect.className = 'filter-field';
            populateSelectWithOptions(fieldSelect, fields, false); // No blank option needed here
            fieldCol.appendChild(fieldSelect);

            // Operator Select
            const opCol = document.createElement('div');
            opCol.className = 'form-col';
            const opSelect = document.createElement('select');
            opSelect.name = `filters[${filterId}][operator]`;
            opSelect.className = 'filter-operator';
            populateSelectWithOptions(opSelect, operators, false); // No blank option
             opSelect.onchange = () => handleOperatorChange(opSelect); // Add onchange handler
            opCol.appendChild(opSelect);

             // Value Input(s) - Initially single input
             const valCol = document.createElement('div');
             valCol.className = 'form-col value-col';
             valCol.id = `filter-value-container-${filterId}`; // Container for inputs
             const valInput = document.createElement('input');
             valInput.type = 'text'; // Default to text, change based on field/op later maybe
             valInput.name = `filters[${filterId}][value][]`; // Use array for potential multiple values
             valInput.className = 'filter-value';
             valCol.appendChild(valInput);

            // Remove Button
            const remCol = document.createElement('div');
            remCol.className = 'remove-btn-col';
            const remButton = document.createElement('button');
            remButton.type = 'button';
            remButton.className = 'btn btn-danger btn-sm';
            remButton.textContent = '×';
            remButton.title = 'Remove Filter';
            remButton.onclick = () => row.remove();
            remCol.appendChild(remButton);

            row.appendChild(fieldCol);
            row.appendChild(opCol);
            row.appendChild(valCol);
            row.appendChild(remCol);
            filterContainer.appendChild(row);

             handleOperatorChange(opSelect); // Call initially to set correct input state
        }

         function handleOperatorChange(operatorSelect) {
            const selectedOperator = operatorSelect.value;
            const filterRow = operatorSelect.closest('.filter-row');
            const valueContainer = filterRow.querySelector('.value-col');
            const currentInput = valueContainer.querySelector('input, select'); // Find existing input
             const inputName = currentInput.name; // Get name like filters[TIMESTAMP][value][]

            const needsNoValue = ['IS NULL', 'IS NOT NULL'];
            const needsTwoValues = ['BETWEEN', 'NOT BETWEEN'];

            if (needsNoValue.includes(selectedOperator)) {
                 valueContainer.innerHTML = '<span class="text-muted" style="padding: 0.625rem 0;">(No value needed)</span>';
            } else if (needsTwoValues.includes(selectedOperator)) {
                // Keep array name, create two inputs
                valueContainer.innerHTML = `
                    <input type="text" name="${inputName}" class="filter-value" placeholder="Value 1" style="width: 48%; display: inline-block; margin-right: 4%;">
                    <input type="text" name="${inputName}" class="filter-value" placeholder="Value 2" style="width: 48%; display: inline-block;">
                 `;
             } else {
                 // Single value needed, ensure it's a single input
                 // Check if we need to recreate the input (e.g., if it was previously hidden/changed)
                 if (!currentInput || currentInput.tagName !== 'INPUT' || valueContainer.children.length > 1) {
                    valueContainer.innerHTML = `<input type="text" name="${inputName}" class="filter-value">`;
                 }
                 // If it's already a single input, just ensure placeholder/type are correct (optional enhancement)
            }
            // Future enhancement: Change input type based on selected field (date, number)
         }


        // Enable/disable aggregation fields based on grouping
        groupBySelect.addEventListener('change', function() {
            const requiresAggregation = !!this.value;
            aggregateFunctionSelect.disabled = !requiresAggregation;
             aggregateFieldSelect.disabled = !requiresAggregation;
             if (!requiresAggregation) {
                 aggregateFunctionSelect.value = '';
                 aggregateFieldSelect.value = '';
             }
        });

        // --- Report Generation & Display ---

        function generateReport(event) {
            event.preventDefault(); // Prevent actual form submission
            const form = document.getElementById('query-builder-form');
            const formData = new FormData(form);

            // Basic Validation (can be enhanced)
            const selectedColumns = formData.getAll('select_columns[]');
             if (!selectedColumns || selectedColumns.length === 0) {
                 showToast('Warning', 'Please select at least one column to display.', 'warning');
                 selectColumnsSelect.focus();
                 return;
             }
             if (formData.get('group_by') && (!formData.get('aggregate_function') || !formData.get('aggregate_field'))) {
                 showToast('Warning', 'Please select an aggregation function and field when grouping.', 'warning');
                 aggregateFunctionSelect.focus();
                 return;
             }
             // Validation for filter values based on operator can be added here

             // Structure data for API (easier for backend to parse than raw FormData)
             const reportRequest = {
                action: 'build_report', // The new API action
                subject: formData.get('report_subject'),
                columns: selectedColumns,
                filters: [],
                group_by: formData.get('group_by') || null,
                aggregate_function: formData.get('aggregate_function') || null,
                aggregate_field: formData.get('aggregate_field') || null,
                sort_by: formData.get('sort_by') || null,
                sort_direction: formData.get('sort_direction') || 'ASC',
                output_format: formData.get('output_format') || 'table'
            };

            // Collect filters correctly
            const filterRows = filterContainer.querySelectorAll('.filter-row');
            filterRows.forEach(row => {
                const fieldSelect = row.querySelector('.filter-field');
                const operatorSelect = row.querySelector('.filter-operator');
                 const valueInputs = row.querySelectorAll('.filter-value'); // Get all value inputs

                if (fieldSelect && operatorSelect) {
                     const filter = {
                        field: fieldSelect.value,
                        operator: operatorSelect.value,
                        value: []
                     };
                     // Collect value(s) - handles single, multiple, or none
                     if (!needsNoValue.includes(filter.operator)) { // Use needsNoValue from handleOperatorChange scope or redefine here
                         valueInputs.forEach(input => filter.value.push(input.value));
                     }
                     reportRequest.filters.push(filter);
                }
            });
            // Helper check - copied needsNoValue logic scope
            const needsNoValue = ['IS NULL', 'IS NOT NULL'];

            console.log("Sending Request:", reportRequest); // Debug: Check payload

            // Show loading indicator and hide previous results
             reportResultsDiv.style.display = 'block';
             loadingIndicator.style.display = 'flex';
             resultsTableContainer.style.display = 'none';
             resultsChartContainer.style.display = 'none';
             noResultsDiv.style.display = 'none';
             if (currentReportChart) {
                 currentReportChart.destroy(); // Destroy previous chart instance
                 currentReportChart = null;
             }


            // Send request to API
             fetch('api.php', {
                 method: 'POST',
                 headers: { 'Content-Type': 'application/json' }, // Send as JSON
                 body: JSON.stringify(reportRequest)
            })
            .then(response => {
                 if (!response.ok) {
                      // Try to get error message from JSON response body
                      return response.json().then(errData => {
                         throw new Error(errData.message || `Request failed with status ${response.status}`);
                     }).catch(() => {
                         // If JSON parsing fails, throw generic HTTP error
                         throw new Error(`Request failed with status ${response.status} ${response.statusText}`);
                     });
                 }
                 return response.json();
             })
            .then(data => {
                loadingIndicator.style.display = 'none';
                 if (data.success && data.results && data.results.length > 0) {
                     displayReportResults(data.results, data.headers, reportRequest.output_format);
                 } else if (data.success) {
                     noResultsDiv.style.display = 'block';
                     resultsTableContainer.style.display = 'none';
                     resultsChartContainer.style.display = 'none';
                 } else {
                     showToast('Error', data.message || 'Failed to generate report.', 'error');
                     noResultsDiv.textContent = `Error: ${escapeHtml(data.message || 'Could not generate report.')}`;
                      noResultsDiv.style.display = 'block';
                 }
            })
            .catch(error => {
                console.error('Error generating report:', error);
                 showToast('Error', `Report generation failed: ${error.message}`, 'error');
                 loadingIndicator.style.display = 'none';
                 noResultsDiv.textContent = `Error: ${escapeHtml(error.message)}`;
                 noResultsDiv.style.display = 'block';
                 resultsTableContainer.style.display = 'none';
                 resultsChartContainer.style.display = 'none';
             });
        }

        function displayReportResults(results, headers, format) {
            noResultsDiv.style.display = 'none';

            if (format === 'table') {
                resultsTableContainer.style.display = 'block';
                resultsChartContainer.style.display = 'none';
                resultsTableHead.innerHTML = '';
                resultsTableBody.innerHTML = '';

                // Create headers
                const headerRow = resultsTableHead.insertRow();
                headers.forEach(header => {
                    const th = document.createElement('th');
                    th.textContent = header; // Assuming header is just the field name/alias from SQL
                    headerRow.appendChild(th);
                });

                // Create rows
                results.forEach(rowData => {
                    const row = resultsTableBody.insertRow();
                    headers.forEach(headerKey => {
                        const cell = row.insertCell();
                        // Check if data exists for the header key, handle null/undefined
                        const cellValue = rowData[headerKey] !== null && rowData[headerKey] !== undefined ? rowData[headerKey] : '-';
                        cell.textContent = escapeHtml(cellValue);
                         // Basic number formatting (can be enhanced)
                         if (!isNaN(parseFloat(cellValue)) && isFinite(cellValue) && typeof cellValue !== 'boolean') {
                             // Check if it looks like a currency/large number
                             if (Math.abs(cellValue) > 1 && headerKey.toLowerCase().includes('amount')) {
                                 cell.textContent = parseFloat(cellValue).toFixed(2);
                                 cell.style.textAlign = 'right';
                            } else if (Number.isInteger(parseFloat(cellValue))) {
                                cell.textContent = parseInt(cellValue, 10);
                            } else {
                                cell.textContent = parseFloat(cellValue).toFixed(2); // Default float format
                            }
                        }
                    });
                });

            } else if (format === 'chart_bar' || format === 'chart_line') {
                resultsTableContainer.style.display = 'none';
                resultsChartContainer.style.display = 'block';
                renderChart(results, headers, format);
            }
        }

        function renderChart(results, headers, chartType = 'chart_bar') {
             if (currentReportChart) { currentReportChart.destroy(); } // Clear previous chart

             // Basic chart data preparation (assumes first column is label, second is value)
             // This needs significant improvement for more complex chart scenarios
             if (headers.length < 2) {
                 resultsChartContainer.innerHTML = '<p class="text-muted">Chart requires at least two columns (Label and Value).</p>';
                 return;
             }
             const labels = results.map(row => row[headers[0]] !== null ? row[headers[0]] : 'N/A');
             const dataValues = results.map(row => parseFloat(row[headers[1]]) || 0); // Assume second column is value

            const ctx = resultsChartCanvas.getContext('2d');
            currentReportChart = new Chart(ctx, {
                 type: chartType === 'chart_line' ? 'line' : 'bar', // 'bar' or 'line'
                 data: {
                     labels: labels,
                     datasets: [{
                         label: headers[1], // Use second column header as label
                         data: dataValues,
                          backgroundColor: chartType === 'chart_line' ? 'rgba(30, 64, 175, 0.1)' : 'rgba(30, 64, 175, 0.6)', // Example colors
                          borderColor: '#1e40af',
                          borderWidth: chartType === 'chart_line' ? 2 : 1,
                          tension: chartType === 'chart_line' ? 0.1 : 0, // Slight curve for line
                          fill: chartType === 'chart_line', // Fill only for line charts
                     }]
                 },
                 options: {
                     responsive: true,
                     maintainAspectRatio: false,
                     plugins: {
                         legend: { display: dataValues.length > 1 }, // Show legend only if multiple datasets (or just one here)
                         tooltip: {
                             callbacks: {
                                label: function(context) {
                                    let label = context.dataset.label || '';
                                    if (label) { label += ': '; }
                                     // Basic number formatting for tooltip
                                     let value = context.parsed.y;
                                     if (chartType === 'bar' && context.chart.options.indexAxis === 'y') value = context.parsed.x; // For horizontal bar
                                     if (value !== null) {
                                         label += !isNaN(value) ? parseFloat(value).toLocaleString(undefined, {minimumFractionDigits: 0, maximumFractionDigits: 2}) : 'N/A';
                                    }
                                     return label;
                                }
                            }
                         }
                     },
                     scales: {
                         y: { beginAtZero: true },
                         x: {}
                     }
                 }
             });
         }


        // --- Initial Setup ---
        document.addEventListener('DOMContentLoaded', () => {
            updateAvailableFields(); // Populate selects on load
        });
    </script>

</body>
</html>