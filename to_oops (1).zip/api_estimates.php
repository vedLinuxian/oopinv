<?php
// Include database configuration
require_once 'db_config.php';

// Check if the user is logged in
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header('Content-Type: application/json');
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized access.']);
    exit;
}

$user_id = $_SESSION["id"];

// ======================= START: HELPER FUNCTIONS =======================
function generateNextInvoiceNumber_local($conn, $user_id) {
    $current_month = (int)date('n');
    $current_year = (int)date('Y');
    if ($current_month >= 4) {
        $start_yy = date('y');
        $end_yy = substr((string)($current_year + 1), -2);
    } else {
        $start_yy = substr((string)($current_year - 1), -2);
        $end_yy = date('y');
    }
    $fy_prefix = $start_yy . "-" . $end_yy . "-";
    $sql = "SELECT invoice_number FROM invoices WHERE user_id = :user_id AND invoice_number LIKE :prefix ORDER BY invoice_number DESC LIMIT 1";
    $result = query($conn, $sql, ['user_id' => $user_id, 'prefix' => $fy_prefix . '%']);
    $nextNumber = 1;
    if ($result && fetch_count($conn, $result) > 0) {
        $lastInvoice = fetch_one($result);
        if (preg_match('/-(\d{4})$/', $lastInvoice['invoice_number'], $matches)) {
            $nextNumber = (int)$matches[1] + 1;
        } else {
            $sql_count = "SELECT COUNT(*) as count FROM invoices WHERE user_id = :user_id AND invoice_number LIKE :prefix";
            if ($res_count = query($conn, $sql_count, ['user_id' => $user_id, 'prefix' => $fy_prefix . '%'])) {
                $count_data = fetch_one($res_count);
                $nextNumber = isset($count_data['count']) ? (int)$count_data['count'] + 1 : 1;
            }
        }
    }
    return $fy_prefix . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);
}

function generateNextEstimateNumber($conn, $user_id) {
    $current_month = (int)date('n');
    $current_year = (int)date('Y');
    if ($current_month >= 4) {
        $start_yy = date('y');
        $end_yy = substr((string)($current_year + 1), -2);
    } else {
        $start_yy = substr((string)($current_year - 1), -2);
        $end_yy = date('y');
    }
    $fy_prefix = "EST-" . $start_yy . "-" . $end_yy . "-";
    $sql = "SELECT estimate_number FROM estimates WHERE user_id = :user_id AND estimate_number LIKE :prefix ORDER BY estimate_number DESC LIMIT 1";
    $result = query($conn, $sql, ['user_id' => $user_id, 'prefix' => $fy_prefix . '%']);
    $nextNumber = 1;
    if ($result && fetch_count($conn, $result) > 0) {
        $lastEstimate = fetch_one($result);
        if (preg_match('/-(\d{4})$/', $lastEstimate['estimate_number'], $matches)) {
            $nextNumber = (int)$matches[1] + 1;
        } else {
            $sql_count = "SELECT COUNT(*) as count FROM estimates WHERE user_id = :user_id AND estimate_number LIKE :prefix";
            if ($res_count = query($conn, $sql_count, ['user_id' => $user_id, 'prefix' => $fy_prefix . '%'])) {
                $count_data = fetch_one($res_count);
                $nextNumber = isset($count_data['count']) ? (int)$count_data['count'] + 1 : 1;
            }
        }
    }
    return $fy_prefix . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);
}

function getCompanyDetails_local($conn, $user_id) {
    $sql = "SELECT * FROM companies WHERE user_id = :user_id LIMIT 1";
    $result = query($conn, $sql, ['user_id' => $user_id]);
    return $result ? fetch_one($result) : null;
}
// ======================= END: HELPER FUNCTIONS =======================


// --- Main Request Handling ---
$action = $_REQUEST['action'] ?? null;
if (!$action) {
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'No estimate action specified']);
    exit;
}

header('Content-Type: application/json');
switch ($action) {
    case 'save_estimate':
        saveEstimate();
        break;
    case 'get_estimates':
        getEstimates();
        break;
    case 'get_estimate':
        getEstimate();
        break;
    case 'delete_estimate':
        deleteEstimate();
        break;
    case 'convert_to_invoice':
        convertToInvoice();
        break;
    case 'preview_estimate':
        previewEstimate();
        break;
    case 'revert_estimate_from_invoice':
        revertEstimateFromInvoice();
        break;
    case 'update_estimate_status':
        updateEstimateStatus();
        break;
    default:
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid estimate action specified']);
        break;
}
exit;


// ======================= START: ACTION FUNCTIONS =======================

function revertEstimateFromInvoice() {
    global $conn, $user_id;
    $invoice_id = isset($_POST['invoice_id']) ? (int)$_POST['invoice_id'] : 0;
    if (!$invoice_id) {
        // Don't output an error, just exit gracefully
        exit;
    }
    $sql = "UPDATE estimates SET status = 'accepted', invoice_id = NULL WHERE invoice_id = :invoice_id AND user_id = :user_id";
    query($conn, $sql, ['invoice_id' => $invoice_id, 'user_id' => $user_id]);
    echo json_encode(['success' => true]);
}

function updateEstimateStatus() {
    global $conn, $user_id;
    $estimate_id = isset($_POST['estimate_id']) ? (int)$_POST['estimate_id'] : 0;
    $new_status = isset($_POST['new_status']) ? sanitize($conn, $_POST['new_status']) : '';

    if (!$estimate_id || empty($new_status)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Estimate ID and new status are required.']);
        return;
    }

    $allowed_statuses = ['draft', 'sent', 'accepted', 'rejected'];
    if (!in_array($new_status, $allowed_statuses)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid status provided.']);
        return;
    }

    $sql = "UPDATE estimates SET status = :new_status WHERE id = :id AND user_id = :user_id";
    $result = query($conn, $sql, ['new_status' => $new_status, 'id' => $estimate_id, 'user_id' => $user_id]);

    if ($result && mysqli_affected_rows($conn) > 0) {
        echo json_encode(['success' => true, 'message' => 'Estimate status updated successfully.']);
    } elseif ($result) {
        echo json_encode(['success' => true, 'message' => 'Status is already set to the selected value.']);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Database error while updating status.']);
    }
}

function saveEstimate() {
    global $conn, $user_id;
    $estimate_id_from_post = isset($_POST['estimate_id']) && ctype_digit((string)$_POST['estimate_id']) && (int)$_POST['estimate_id'] > 0 ? (int)$_POST['estimate_id'] : null;
    $is_update = !is_null($estimate_id_from_post);

    if (empty($_POST['estimate_date']) || empty($_POST['client_id']) || !isset($_POST['description']) || !is_array($_POST['description'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Missing required estimate data.']);
        return;
    }

    begin_transaction($conn);
    try {
        $client_id = (int)$_POST['client_id'];
        $estimate_date = sanitize($conn, $_POST['estimate_date']);
        $expiry_date = !empty($_POST['expiry_date']) ? sanitize($conn, $_POST['expiry_date']) : null;
        $hsn_code = !empty(trim($_POST['hsn_code'] ?? '')) ? sanitize($conn, trim($_POST['hsn_code'])) : null;
        $po_number = !empty(trim($_POST['po_number'] ?? '')) ? sanitize($conn, trim($_POST['po_number'])) : null;
        $notes = !empty(trim($_POST['notes'] ?? '')) ? sanitize($conn, $_POST['notes']) : null;
        $discount_rate = isset($_POST['discount_rate']) && is_numeric($_POST['discount_rate']) ? (float)$_POST['discount_rate'] : 0.0;
        $cgst_rate = isset($_POST['cgst_rate']) && is_numeric($_POST['cgst_rate']) ? (float)$_POST['cgst_rate'] : 0.0;
        $sgst_rate = isset($_POST['sgst_rate']) && is_numeric($_POST['sgst_rate']) ? (float)$_POST['sgst_rate'] : 0.0;
        $convenience_fee = isset($_POST['convenience_fee']) && is_numeric($_POST['convenience_fee']) ? (float)$_POST['convenience_fee'] : 0.0;

        $calculated_subtotal = 0;
        $items_data = [];
        for ($i = 0; $i < count($_POST['description']); $i++) {
            if (!empty(trim($_POST['description'][$i]))) {
                $qty = is_numeric($_POST['quantity'][$i]) ? (float)$_POST['quantity'][$i] : 0;
                $rate = is_numeric($_POST['rate'][$i]) ? (float)$_POST['rate'][$i] : 0;
                $amount = round($qty * $rate, 2);
                $calculated_subtotal += $amount;
                $items_data[] = [
                    'description' => sanitize($conn, trim($_POST['description'][$i])),
                    'quantity' => $qty,
                    'rate' => $rate,
                    'amount' => $amount
                ];
            }
        }
        if (empty($items_data)) {
            throw new Exception("At least one item with a description is required.");
        }

        $calculated_subtotal = round($calculated_subtotal, 2);
        $calculated_discount_amount = round(($calculated_subtotal * $discount_rate) / 100, 2);
        $taxable_amount = $calculated_subtotal - $calculated_discount_amount;
        $calculated_cgst_amount = round(($taxable_amount * $cgst_rate) / 100, 2);
        $calculated_sgst_amount = round(($taxable_amount * $sgst_rate) / 100, 2);
        $calculated_total_amount = round($taxable_amount + $calculated_cgst_amount + $calculated_sgst_amount + $convenience_fee, 2);

        $sql_check_client = "SELECT id FROM clients WHERE id = :client_id AND user_id = :user_id";
        if (fetch_count($conn, query($conn, $sql_check_client, ['client_id' => $client_id, 'user_id' => $user_id])) === 0) {
            throw new Exception("Selected client not found or access denied.");
        }

        $estimate_number = null;
        if ($is_update) {
            $sql_check_owner = "SELECT id, estimate_number FROM estimates WHERE id = :id AND user_id = :user_id";
            $res_check = query($conn, $sql_check_owner, ['id' => $estimate_id_from_post, 'user_id' => $user_id]);
            if (!$res_check || fetch_count($conn, $res_check) === 0) {
                throw new Exception("Estimate not found or access denied.");
            }
            $existing_data = fetch_one($res_check);
            $estimate_number = $existing_data['estimate_number'];

            $sql = "UPDATE estimates SET client_id=:c, estimate_date=:ed, expiry_date=:exd, hsn_code=:h, po_number=:p, discount_rate=:dr, discount_amount=:da, cgst_rate=:cr, sgst_rate=:sr, convenience_fee=:cf, subtotal=:sub, cgst_amount=:ca, sgst_amount=:sa, total_amount=:tot, notes=:n WHERE id=:id AND user_id=:uid";
            $params = [
                'c' => $client_id, 'ed' => $estimate_date, 'exd' => $expiry_date, 'h' => $hsn_code, 'p' => $po_number, 'dr' => $discount_rate,
                'da' => $calculated_discount_amount, 'cr' => $cgst_rate, 'sr' => $sgst_rate, 'cf' => $convenience_fee, 'sub' => $calculated_subtotal,
                'ca' => $calculated_cgst_amount, 'sa' => $calculated_sgst_amount, 'tot' => $calculated_total_amount, 'n' => $notes, 'id' => $estimate_id_from_post, 'uid' => $user_id
            ];
            $action_type = 'updated';
        } else {
            $estimate_number = generateNextEstimateNumber($conn, $user_id);
            $sql = "INSERT INTO estimates (user_id, client_id, estimate_number, estimate_date, expiry_date, hsn_code, po_number, discount_rate, discount_amount, cgst_rate, sgst_rate, convenience_fee, subtotal, cgst_amount, sgst_amount, total_amount, notes) VALUES (:uid, :c, :en, :ed, :exd, :h, :p, :dr, :da, :cr, :sr, :cf, :sub, :ca, :sa, :tot, :n)";
            $params = [
                'uid' => $user_id, 'c' => $client_id, 'en' => $estimate_number, 'ed' => $estimate_date, 'exd' => $expiry_date, 'h' => $hsn_code, 'p' => $po_number, 'dr' => $discount_rate,
                'da' => $calculated_discount_amount, 'cr' => $cgst_rate, 'sr' => $sgst_rate, 'cf' => $convenience_fee, 'sub' => $calculated_subtotal, 'ca' => $calculated_cgst_amount,
                'sa' => $calculated_sgst_amount, 'tot' => $calculated_total_amount, 'n' => $notes
            ];
            $action_type = 'created';
        }

        if (!query($conn, $sql, $params)) {
            throw new Exception("Database error saving estimate details.");
        }

        $current_estimate_id = $is_update ? $estimate_id_from_post : last_id($conn);
        if (!$current_estimate_id) {
            throw new Exception("Failed to get estimate ID after save.");
        }

        if ($is_update) {
            $sql_delete_items = "DELETE FROM estimate_items WHERE estimate_id = :estimate_id";
            if (!query($conn, $sql_delete_items, ['estimate_id' => $current_estimate_id])) {
                throw new Exception("Failed to clear old estimate items.");
            }
        }

        $sql_item = "INSERT INTO estimate_items (estimate_id, description, quantity, rate, amount) VALUES (:eid, :d, :q, :r, :a)";
        foreach ($items_data as $item) {
            $params_item = ['eid' => $current_estimate_id, 'd' => $item['description'], 'q' => $item['quantity'], 'r' => $item['rate'], 'a' => $item['amount']];
            if (!query($conn, $sql_item, $params_item)) {
                throw new Exception("Failed to save an estimate item: " . $item['description']);
            }
        }
        
        commit_transaction($conn);
        echo json_encode(['success' => true, 'message' => "Estimate {$action_type} successfully.", 'estimate_id' => $current_estimate_id, 'estimate_number' => $estimate_number]);
    } catch (Exception $e) {
        rollback_transaction($conn);
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}

function getEstimates() {
    global $conn, $user_id;
    $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
    $limit = isset($_GET['limit']) ? max(1, (int)$_GET['limit']) : 15;
    $offset = ($page - 1) * $limit;

    $sql_count = "SELECT COUNT(*) as total FROM estimates WHERE user_id = :user_id";
    $result_count = query($conn, $sql_count, ['user_id' => $user_id]);
    $total_estimates = fetch_one($result_count)['total'] ?? 0;

    $sql = "SELECT e.id, e.estimate_number, e.estimate_date, e.total_amount, e.status, c.name as client_name FROM estimates e LEFT JOIN clients c ON e.client_id = c.id WHERE e.user_id = :user_id ORDER BY e.estimate_date DESC, e.id DESC LIMIT :limit OFFSET :offset";
    $params = ['user_id' => $user_id, 'limit' => $limit, 'offset' => $offset];
    $result_data = query($conn, $sql, $params);
    $estimates = $result_data ? fetch_all($result_data) : [];

    echo json_encode(['success' => true, 'estimates' => $estimates, 'total_estimates' => (int)$total_estimates, 'page' => $page, 'limit' => $limit]);
}

function getEstimate() {
    global $conn, $user_id;
    $estimate_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if (!$estimate_id) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid estimate ID.']);
        return;
    }
    $sql_estimate = "SELECT e.*, c.name as client_name, c.address as client_address, c.gstin as client_gstin, c.state as client_state, c.state_code as client_state_code FROM estimates e LEFT JOIN clients c ON e.client_id = c.id WHERE e.id = :id AND e.user_id = :user_id";
    $result_estimate = query($conn, $sql_estimate, ['id' => $estimate_id, 'user_id' => $user_id]);
    if (!$result_estimate || fetch_count($conn, $result_estimate) === 0) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Estimate not found or access denied.']);
        return;
    }
    $estimate = fetch_one($result_estimate);
    $sql_items = "SELECT * FROM estimate_items WHERE estimate_id = :estimate_id ORDER BY id ASC";
    $result_items = query($conn, $sql_items, ['estimate_id' => $estimate_id]);
    $items = $result_items ? fetch_all($result_items) : [];
    echo json_encode(['success' => true, 'estimate' => $estimate, 'items' => $items]);
}

function deleteEstimate() {
    global $conn, $user_id;
    $estimate_id = isset($_REQUEST['id']) ? (int)$_REQUEST['id'] : 0;
    if (!$estimate_id) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid estimate ID.']);
        return;
    }
    begin_transaction($conn);
    try {
        $sql_check = "SELECT id, invoice_id FROM estimates WHERE id = :id AND user_id = :user_id";
        $res_check = query($conn, $sql_check, ['id' => $estimate_id, 'user_id' => $user_id]);
        if (!$res_check || fetch_count($conn, $res_check) === 0) {
            throw new Exception("Estimate not found or access denied.");
        }
        $estimate = fetch_one($res_check);
        if (!is_null($estimate['invoice_id'])) {
            throw new Exception("Cannot delete an estimate that has been invoiced. Delete the invoice first.");
        }
        query($conn, "DELETE FROM estimate_items WHERE estimate_id = :eid", ['eid' => $estimate_id]);
        query($conn, "DELETE FROM estimates WHERE id = :eid", ['eid' => $estimate_id]);
        commit_transaction($conn);
        echo json_encode(['success' => true, 'message' => 'Estimate deleted successfully.']);
    } catch (Exception $e) {
        rollback_transaction($conn);
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}

function convertToInvoice() {
    global $conn, $user_id;
    $estimate_id = isset($_POST['estimate_id']) ? (int)$_POST['estimate_id'] : 0;
    if (!$estimate_id) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid estimate ID provided.']);
        return;
    }
    begin_transaction($conn);
    try {
        $sql_estimate = "SELECT * FROM estimates WHERE id = :eid AND user_id = :uid AND invoice_id IS NULL";
        $result_estimate = query($conn, $sql_estimate, ['eid' => $estimate_id, 'uid' => $user_id]);
        if (!$result_estimate || fetch_count($conn, $result_estimate) === 0) {
            throw new Exception("Estimate not found, access denied, or already invoiced.");
        }
        $estimate = fetch_one($result_estimate);
        $sql_items = "SELECT * FROM estimate_items WHERE estimate_id = :eid";
        $items = fetch_all(query($conn, $sql_items, ['eid' => $estimate_id]));
        if (empty($items)) {
            throw new Exception("Cannot convert an empty estimate.");
        }
        $new_invoice_number = generateNextInvoiceNumber_local($conn, $user_id);
        $sql_insert_invoice = "INSERT INTO invoices (user_id, client_id, invoice_number, invoice_date, due_date, hsn_code, po_number, discount_rate, discount_amount, cgst_rate, sgst_rate, convenience_fee, subtotal, cgst_amount, sgst_amount, total_amount, notes, status, bank_account_id) VALUES (:uid, :cid, :in, :idate, :idue, :hsn, :po, :dr, :da, :cr, :sr, :cf, :sub, :ca, :sa, :tot, :n, 'unpaid', NULL)";
        $invoice_date = date('Y-m-d');
        $params_invoice = [
            'uid' => $user_id, 'cid' => $estimate['client_id'], 'in' => $new_invoice_number, 'idate' => $invoice_date, 'idue' => null, 'hsn' => $estimate['hsn_code'], 'po' => $estimate['po_number'], 'dr' => $estimate['discount_rate'], 'da' => $estimate['discount_amount'],
            'cr' => $estimate['cgst_rate'], 'sr' => $estimate['sgst_rate'], 'cf' => $estimate['convenience_fee'], 'sub' => $estimate['subtotal'], 'ca' => $estimate['cgst_amount'], 'sa' => $estimate['sgst_amount'], 'tot' => $estimate['total_amount'], 'n' => $estimate['notes']
        ];
        if (!query($conn, $sql_insert_invoice, $params_invoice)) {
            throw new Exception("Failed to create new invoice record.");
        }
        $new_invoice_id = last_id($conn);
        if (!$new_invoice_id) {
            throw new Exception("Failed to retrieve new invoice ID.");
        }
        $sql_insert_item = "INSERT INTO invoice_items (invoice_id, description, quantity, rate, amount) VALUES (:invid, :d, :q, :r, :a)";
        foreach ($items as $item) {
            $params_item = ['invid' => $new_invoice_id, 'd' => $item['description'], 'q' => $item['quantity'], 'r' => $item['rate'], 'a' => $item['amount']];
            if (!query($conn, $sql_insert_item, $params_item)) {
                throw new Exception("Failed to copy item: " . $item['description']);
            }
        }
        $sql_update_estimate = "UPDATE estimates SET status = 'invoiced', invoice_id = :invid WHERE id = :eid";
        if (!query($conn, $sql_update_estimate, ['invid' => $new_invoice_id, 'eid' => $estimate_id])) {
            throw new Exception("Failed to update original estimate status.");
        }
        commit_transaction($conn);
        echo json_encode(['success' => true, 'message' => "Converted to Invoice #{$new_invoice_number}", 'new_invoice_id' => $new_invoice_id]);
    } catch (Exception $e) {
        rollback_transaction($conn);
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Conversion failed: ' . $e->getMessage()]);
    }
}

function previewEstimate() {
    global $conn, $user_id;
    $estimate_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if (!$estimate_id) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid estimate ID for preview.']);
        return;
    }

    $company = getCompanyDetails_local($conn, $user_id);

    $sql_estimate = "SELECT e.*, c.name as client_name, c.address as client_address FROM estimates e LEFT JOIN clients c ON e.client_id = c.id WHERE e.id = :id AND e.user_id = :user_id";
    $result_estimate = query($conn, $sql_estimate, ['id' => $estimate_id, 'user_id' => $user_id]);
    if (!$result_estimate || fetch_count($conn, $result_estimate) === 0) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Estimate not found.']);
        return;
    }
    $estimate = fetch_one($result_estimate);

    $sql_items = "SELECT * FROM estimate_items WHERE estimate_id = :id";
    $items = fetch_all(query($conn, $sql_items, ['id' => $estimate_id]));

    $html = generateEstimateHTML($estimate, $items, $company);

    $fileNameData = [
        'number' => $estimate['estimate_number'],
        'client' => $estimate['client_name'],
        'date' => $estimate['estimate_date']
    ];

    echo json_encode(['success' => true, 'html' => $html, 'fileNameData' => $fileNameData]);
}

function generateEstimateHTML($estimate, $items, $company) {
    ob_start();
    $h = function ($str) {
        return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
    };
    $format_date = function ($date) {
        return $date ? date('d-m-Y', strtotime($date)) : '';
    };
    $company_name = $h($company['name'] ?? 'Your Company');
    $subtotal = (float)($estimate['subtotal'] ?? 0);
    $discount_amount = (float)($estimate['discount_amount'] ?? 0);
    $taxable_amount_display = round($subtotal - $discount_amount, 2);
    $stamp_data_uri = null;
    if (!empty($company['stamp_path']) && file_exists($company['stamp_path'])) {
        $stamp_mime = @mime_content_type($company['stamp_path']);
        if ($stamp_mime) {
            $stamp_data_uri = 'data:' . $stamp_mime . ';base64,' . base64_encode(file_get_contents($company['stamp_path']));
        }
    }
?>
    <div style="font-family: 'Poppins', sans-serif; color: #333; max-width: 800px; margin: 20px auto; padding: 25px; background-color: white; border: 1px solid #e2e8f0; border-radius: 8px;">
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 25px;">
            <tr>
                <td style="width: 60%; vertical-align: top;">
                    <div style="font-size: 24px; font-weight: 700; color: #1e40af; margin-bottom: 8px;"><?php echo $company_name; ?></div>
                    <div style="font-size: 13px; color: #475569; line-height: 1.6;"><?php echo nl2br($h($company['address'] ?? '')); ?><?php if ($company['phone'] ?? null) : ?><br>Phone: <?php echo $h($company['phone']); ?><?php endif; ?><?php if ($company['email'] ?? null) : ?><br>Email: <?php echo $h($company['email']); ?><?php endif; ?><?php if ($company['gstin'] ?? null) : ?><br>GSTIN: <?php echo $h($company['gstin']); ?><?php endif; ?></div>
                </td>
                <td style="width: 40%; text-align: right; vertical-align: top;">
                    <div style="font-size: 28px; font-weight: 800; color: #1e3a8a; text-transform: uppercase;">ESTIMATE</div>
                </td>
            </tr>
        </table>
        <table style="width: 100%; border-collapse: separate; border-spacing: 0; margin-bottom: 25px;">
            <tr>
                <td style="width: 50%; border: 1px solid #e2e8f0; padding: 12px 15px; border-radius: 6px 0 0 6px; background-color: #f8fafc;">
                    <div style="font-size: 11px;">PREPARED FOR:</div>
                    <div style="font-weight: 600; color: #334155; margin-bottom: 4px;"><?php echo $h($estimate['client_name']); ?></div>
                    <div style='font-size: 13px; color: #475569;'><?php echo nl2br($h($estimate['client_address'] ?? '')); ?></div>
                </td>
                <td style="width: 50%; border: 1px solid #e2e8f0; padding: 12px 15px; border-left: none; border-radius: 0 6px 6px 0;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px;"><strong>Estimate #:</strong> <span><?php echo $h($estimate['estimate_number']); ?></span></div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px;"><strong>Estimate Date:</strong> <span><?php echo $format_date($estimate['estimate_date']); ?></span></div>
                    <?php if (!empty($estimate['expiry_date'])) : ?><div style="display: flex; justify-content: space-between; margin-bottom: 5px;"><strong>Expiry Date:</strong> <span><?php echo $format_date($estimate['expiry_date']); ?></span></div><?php endif; ?>
                </td>
            </tr>
        </table>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 13px;">
            <thead style="background-color: #f8fafc;">
                <tr>
                    <th style="padding: 8px; text-align:left; border-bottom: 2px solid #e2e8f0;">#</th>
                    <th style="padding: 8px; text-align:left; border-bottom: 2px solid #e2e8f0;">Description</th>
                    <th style="padding: 8px; text-align:right; border-bottom: 2px solid #e2e8f0;">Quantity</th>
                    <th style="padding: 8px; text-align:right; border-bottom: 2px solid #e2e8f0;">Rate (₹)</th>
                    <th style="padding: 8px; text-align:right; border-bottom: 2px solid #e2e8f0;">Amount (₹)</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1;
                foreach ($items as $item) : ?>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #f1f5f9;"><?php echo $i++; ?></td>
                        <td style="padding: 8px; border-bottom: 1px solid #f1f5f9;"><?php echo $h($item['description']); ?></td>
                        <td style="padding: 8px; border-bottom: 1px solid #f1f5f9; text-align:right;"><?php echo number_format((float)$item['quantity'], 2); ?></td>
                        <td style="padding: 8px; border-bottom: 1px solid #f1f5f9; text-align:right;"><?php echo number_format((float)$item['rate'], 2); ?></td>
                        <td style="padding: 8px; border-bottom: 1px solid #f1f5f9; text-align:right;"><?php echo number_format((float)$item['amount'], 2); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <table style="width: 100%;">
            <tr>
                <td style="width: 60%; vertical-align: top;"><?php if (!empty($estimate['notes'])) : ?><div style="font-weight: 600; font-size: 12px;">Notes:</div>
                        <div style="font-size: 11px; color: #64748b;"><?php echo nl2br($h($estimate['notes'])); ?></div><?php endif; ?></td>
                <td style="width: 40%; vertical-align: top;">
                    <table style="width: 100%;">
                        <tr>
                            <td>Subtotal:</td>
                            <td style="text-align:right;">₹ <?php echo number_format($subtotal, 2); ?></td>
                        </tr>
                        <?php if ($discount_amount > 0) : ?>
                            <tr>
                                <td>Discount (<?php echo $h($estimate['discount_rate']); ?>%):</td>
                                <td style="text-align:right; color: #e67e22;">- ₹ <?php echo number_format($discount_amount, 2); ?></td>
                            </tr>
                            <tr style="font-weight: bold;">
                                <td>Taxable Amount:</td>
                                <td style="text-align:right;">₹ <?php echo number_format($taxable_amount_display, 2); ?></td>
                            </tr>
                        <?php endif; ?>
                        <tr>
                            <td>CGST (<?php echo $h($estimate['cgst_rate']); ?>%):</td>
                            <td style="text-align:right;">₹ <?php echo number_format((float)$estimate['cgst_amount'], 2); ?></td>
                        </tr>
                        <tr>
                            <td>SGST (<?php echo $h($estimate['sgst_rate']); ?>%):</td>
                            <td style="text-align:right;">₹ <?php echo number_format((float)$estimate['sgst_amount'], 2); ?></td>
                        </tr>
                        <tr style="font-weight: 700; font-size: 1.2em; border-top: 2px solid #e2e8f0;">
                            <td style="padding-top: 8px;">Grand Total:</td>
                            <td style="text-align:right; padding-top: 8px;">₹ <?php echo number_format((float)$estimate['total_amount'], 2); ?></td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
        <div style="margin-top: 50px; text-align: right;"><?php if ($stamp_data_uri) : ?><img src="<?php echo $stamp_data_uri; ?>" alt="Stamp" style="max-width: 90px; max-height: 90px; mix-blend-mode: multiply; margin-bottom: -40px; margin-right: 50px;"><?php endif; ?><div>For <?php echo $company_name; ?></div>
            <div style="width: 170px; border-top: 1px solid #64748b; margin-top: 50px; padding-top: 5px; float: right;">Authorised Signatory</div>
        </div>
    </div>
<?php
    return ob_get_clean();
}
?>