<?php
// --- PHP Top Block ---
// Include database configuration & Start Session
require_once 'db_config.php'; // Must provide $conn and query(), fetch_all(), sanitize()

// Check if the user is logged in, redirect if not
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}

// Get user information
$user_id = $_SESSION["id"];
$username = $_SESSION["username"];

// Helper function (ensure it's available from db_config.php or define it here)
if (!function_exists('h')) {
    function h($text) { return htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8'); }
}
if (!function_exists('validate_date')) {
    function validate_date($date, $format = 'Y-m-d') { $d = DateTime::createFromFormat($format, $date); return $d && $d->format($format) === $date; }
}

// --- Filter Processing ---
// Defaults
$default_start_date = date('Y-m-01'); // Start of current month
$default_end_date = date('Y-m-d'); // Today

// Get values from GET, sanitize, and validate
$filter_start_date = isset($_GET['start_date']) && validate_date($_GET['start_date']) ? sanitize($conn, $_GET['start_date']) : $default_start_date;
$filter_end_date = isset($_GET['end_date']) && validate_date($_GET['end_date']) ? sanitize($conn, $_GET['end_date']) : $default_end_date;

// Handle potential array for client_ids from multi-select
$filter_client_ids_raw = isset($_GET['client_ids']) ? $_GET['client_ids'] : [];
if (!is_array($filter_client_ids_raw)) { // Handle non-array case (e.g., single value)
    $filter_client_ids_raw = !empty($filter_client_ids_raw) ? [$filter_client_ids_raw] : [];
}

// Ensure filter dates are logical
if ($filter_start_date > $filter_end_date) {
    list($filter_start_date, $filter_end_date) = [$filter_end_date, $filter_start_date];
}

// --- Client Dropdown Data Fetch (needed for the filter form) ---
$client_options = [];
try {
    $sql_clients = "SELECT id, name FROM clients WHERE user_id = :user_id ORDER BY name ASC";
    $result_clients = query($conn, $sql_clients, ['user_id' => $user_id]);
    if ($result_clients) {
        $client_options = fetch_all($result_clients);
    } else {
         // Non-fatal error, dropdown will be empty
         error_log("list.php: Failed to fetch client options for user $user_id: " . mysqli_error($conn));
    }
} catch (Exception $e) {
    error_log("list.php: Exception fetching client options for user $user_id: " . $e->getMessage());
}

// --- Validate selected client IDs against the user's actual clients ---
$valid_filter_client_ids = [];
$client_id_list_sql_part = '';
if (!empty($filter_client_ids_raw)) {
    $all_client_ids_for_user = array_column($client_options, 'id'); // IDs user owns
    foreach ($filter_client_ids_raw as $cid) {
        if (ctype_digit((string)$cid) && in_array((int)$cid, $all_client_ids_for_user)) {
            $valid_filter_client_ids[] = (int)$cid; // Keep only valid, owned IDs
        }
    }
    if (!empty($valid_filter_client_ids)) {
        $client_id_list_sql_part = implode(',', $valid_filter_client_ids); // Safe: Only contains integers verified against ownership
    }
}


// --- Dynamic SQL Query Construction ---
$where_clauses = ["i.user_id = :user_id", "i.invoice_date BETWEEN :start_date AND :end_date"];
$params = ['user_id' => $user_id, 'start_date' => $filter_start_date, 'end_date' => $filter_end_date];

// Add client filter if valid IDs were selected
if (!empty($client_id_list_sql_part)) {
    $where_clauses[] = "i.client_id IN ($client_id_list_sql_part)"; // Directly embedding validated IDs
    // Note: $client_id_list_sql_part is NOT added to $params, as the wrapper likely doesn't handle IN() lists
}

$where_sql = implode(" AND ", $where_clauses);

// Main SQL to fetch invoice list
$sql_data = "SELECT
                 i.id, i.invoice_number, i.invoice_date, i.due_date, i.status,
                 i.total_amount, i.advance_paid, GREATEST(0, i.total_amount - i.advance_paid) as amount_due,
                 c.name as client_name
             FROM invoices i
             LEFT JOIN clients c ON i.client_id = c.id
             WHERE $where_sql
             ORDER BY i.invoice_date DESC, i.id DESC";

// Summary SQL to get totals based on same filters
$sql_summary = "SELECT
                   COUNT(i.id) as total_count,
                   COALESCE(SUM(i.total_amount), 0.00) as total_billed_amount,
                   COALESCE(SUM(CASE WHEN LOWER(i.status) = 'paid' THEN i.total_amount ELSE i.advance_paid END), 0.00) as total_collected_amount, /* Simplified 'collected' based on status */
                   COALESCE(SUM(CASE WHEN LOWER(i.status) != 'paid' THEN GREATEST(0, i.total_amount - i.advance_paid) ELSE 0 END), 0.00) as total_due_amount
                FROM invoices i
                WHERE $where_sql"; // Use the same WHERE clause and parameters

// --- Data Fetching & Export Handling ---
$report_data = [];
$report_summary = [
    'total_count' => 0, 'total_billed_amount' => 0.00, 'total_collected_amount' => 0.00, 'total_due_amount' => 0.00
];
$error_message = '';
$export_requested = isset($_GET['export']) && $_GET['export'] === 'csv';

try {
    // Only fetch summary if not exporting, fetch data always (for display or export)
    if (!$export_requested) {
        $result_summary = query($conn, $sql_summary, $params);
        if ($result_summary) {
            $summary_row = fetch_one($result_summary);
            if ($summary_row) {
                 $report_summary['total_count'] = (int)$summary_row['total_count'];
                 $report_summary['total_billed_amount'] = round((float)$summary_row['total_billed_amount'], 2);
                 $report_summary['total_collected_amount'] = round((float)$summary_row['total_collected_amount'], 2);
                 $report_summary['total_due_amount'] = round((float)$summary_row['total_due_amount'], 2);
            }
        } else {
            throw new Exception("Summary query failed: " . mysqli_error($conn));
        }
    }

    // Fetch the detailed data for display or export
    $result_data = query($conn, $sql_data, $params);
    if ($result_data) {
        $report_data = fetch_all($result_data);
    } else {
        throw new Exception("Data query failed: " . mysqli_error($conn));
    }

    // --- Handle CSV Export ---
    if ($export_requested) {
        $filename = "Invoice_Status_Report_" . $filter_start_date . "_to_" . $filter_end_date . ".csv";
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        $output = fopen('php://output', 'w');

        // Header Row
        fputcsv($output, [
            'Invoice #', 'Client Name', 'Invoice Date', 'Due Date',
            'Total Amount', 'Amount Paid', 'Amount Due', 'Status'
        ]);

        // Data Rows
        foreach ($report_data as $invoice) {
             // Format data for CSV
             $status_text = ucwords(str_replace('_', ' ', $invoice['status'] ?? 'Unknown'));
             fputcsv($output, [
                 $invoice['invoice_number'],
                 $invoice['client_name'] ?? 'N/A',
                 date('Y-m-d', strtotime($invoice['invoice_date'])), // Consistent date format
                 !empty($invoice['due_date']) ? date('Y-m-d', strtotime($invoice['due_date'])) : '',
                 round((float)($invoice['total_amount'] ?? 0), 2),
                 round((float)($invoice['advance_paid'] ?? 0), 2),
                 round((float)($invoice['amount_due'] ?? 0), 2),
                 $status_text
             ]);
         }
         fclose($output);
         exit; // Stop script after CSV output
    }

} catch (Exception $e) {
    $error_message = "Error generating report: " . h($e->getMessage());
    error_log("list.php: Error for user $user_id - " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Libraries -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <title>Invoice List Report - GST Invoice System</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* --- PASTE ALL REQUIRED CSS RULES from index.php / bank.php HERE --- */
        /* Make sure styles for :root, body, .container, .card, .btn, forms, */
        /* tables, pagination, Select2 overrides, status badges, etc., are included */
        :root { /* Base colors */
            --primary: #1e40af; --primary-light: #3b82f6; --primary-dark: #1e3a8a;
            --secondary: #64748b; --danger: #ef4444; --success: #10b981;
            --warning: #f59e0b; --info: #3b82f6; --light: #f8fafc;
            --body-bg: #f1f5f9; --card-bg: #ffffff; --border-color: #e2e8f0;
            --text-primary: #334155; --text-secondary: #64748b; --text-muted: #94a3b8;
            --shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
            --radius: 0.25rem; --radius-md: 0.375rem; --radius-lg: 0.5rem;
            --status-paid-bg: #d1fae5; --status-paid-text: #065f46;
            --status-unpaid-bg: #fee2e2; --status-unpaid-text: #991b1b;
            --status-partial-bg: #fef3c7; --status-partial-text: #92400e;
            --status-default-bg: #e5e7eb; --status-default-text: #4b5563;
        }
        body { font-family: 'Poppins', sans-serif; background-color: var(--body-bg); color: var(--text-primary); font-size: 14px; line-height: 1.6; }
        .container { max-width: 1300px; margin: 1.5rem auto; padding: 0 1rem; }
        .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; padding-bottom: 1rem; border-bottom: 1px solid var(--border-color); }
        .page-title h1 { font-size: 1.5rem; font-weight: 600; color: var(--primary); }
        .user-menu { display: flex; align-items: center; gap: 0.75rem; }
        .card { background: var(--card-bg); border-radius: var(--radius-lg); box-shadow: var(--shadow); margin-bottom: 1.5rem; }
        .card-header { padding: 0.8rem 1.25rem; border-bottom: 1px solid var(--border-color); background-color: var(--light); }
        .card-title { font-size: 1rem; font-weight: 600; }
        .card-body { padding: 1.25rem; }
        .form-row { display: flex; flex-wrap: wrap; gap: 1rem; align-items: flex-end; } /* Align bottom */
        .form-col { flex: 1; min-width: 180px; }
        label { display: block; font-weight: 500; margin-bottom: 0.3rem; font-size: 0.8rem; }
        input[type="date"], select { width: 100%; padding: 0.6rem 0.75rem; border: 1px solid var(--border-color); border-radius: var(--radius); font-size: 0.875rem; }
        /* Select2 minimal overrides */
        .select2-container--default .select2-selection--multiple { border-color: var(--border-color) !important; border-radius: var(--radius) !important; min-height: 39px; padding-top: 3px; }
        .select2-container--default .select2-selection--multiple .select2-selection__choice { background-color: var(--primary); color: white; border: none; margin-top: 2px !important; }
        /* Buttons */
        .btn { display: inline-flex; align-items: center; justify-content: center; padding: 0.6rem 1rem; border-radius: var(--radius); font-weight: 500; cursor: pointer; border: 1px solid transparent; font-size: 0.875rem; text-decoration: none; white-space: nowrap; line-height: 1.2;}
        .btn-primary { background-color: var(--primary); color: white; } .btn-primary:hover { background-color: var(--primary-dark); }
        .btn-outline { background-color: transparent; border-color: var(--border-color); color: var(--text-primary); } .btn-outline:hover { border-color: var(--primary); color: var(--primary); background-color: rgba(30, 64, 175, 0.05); }
        .btn-sm { padding: 0.3rem 0.7rem; font-size: 0.75rem; }
        .btn-icon { margin-right: 0.4rem; }
        /* Table */
        .table-responsive { overflow-x: auto; max-height: 70vh; border: 1px solid var(--border-color); border-radius: var(--radius-md);}
        .data-table { width: 100%; border-collapse: collapse; }
        .data-table th { background-color: var(--light); font-weight: 600; padding: 0.7rem 0.8rem; border-bottom: 2px solid var(--border-color); text-align: left; white-space: nowrap; position:sticky; top: 0; z-index: 1;}
        .data-table td { padding: 0.6rem 0.8rem; border-bottom: 1px solid var(--border-color); font-size: 0.85rem; }
        .data-table tbody tr:hover { background-color: #f0f9ff; }
        .numeric, .currency { text-align: right; white-space: nowrap; }
        /* Status Badge Copy */
        .status-badge { display: inline-block; padding: 0.3em 0.7em; font-size: 0.7rem; font-weight: 600; line-height: 1; text-align: center; white-space: nowrap; vertical-align: middle; border-radius: var(--radius-md); text-transform: uppercase; }
        .status-paid { background-color: var(--status-paid-bg); color: var(--status-paid-text); border: 1px solid #6ee7b7; }
        .status-unpaid { background-color: var(--status-unpaid-bg); color: var(--status-unpaid-text); border: 1px solid #fca5a5; }
        .status-partially_paid { background-color: var(--status-partial-bg); color: var(--status-partial-text); border: 1px solid #fcd34d; }
        .status-default { background-color: var(--status-default-bg); color: var(--status-default-text); border: 1px solid #d1d5db; }
         /* Summary Row */
        .summary-row { display: flex; justify-content: space-around; background-color: var(--light); padding: 0.8rem; border: 1px solid var(--border-color); border-radius: var(--radius-md); margin-bottom: 1rem; font-size: 0.9rem;}
        .summary-item { text-align: center; }
        .summary-value { font-weight: 600; display: block; }
         .summary-label { font-size: 0.75rem; color: var(--text-secondary); text-transform: uppercase; }
        /* Empty Table State */
        .empty-table td { text-align: center; padding: 2rem; color: var(--text-secondary); font-style: italic;}
    </style>
</head>
<body class="bg-gray-100">
    <div class="container">
        <div class="page-header">
            <div class="page-title"><h1>Invoice List Report</h1></div>
            <div class="user-menu">
                <a href="index.php" class="btn btn-outline btn-sm"><i class="fas fa-arrow-left btn-icon"></i>Dashboard</a>
                <span class="user-name"><?php echo h($username); ?></span>
                <a href="logout.php" class="btn btn-outline btn-sm">Sign Out</a>
            </div>
        </div>

        <!-- Filter Card -->
        <div class="card">
            <div class="card-header"><h2 class="card-title">Filters</h2></div>
            <div class="card-body">
                <!-- Use GET method for bookmarkable URLs -->
                <form id="filter-form" method="GET" action="list.php">
                    <div class="form-row">
                        <div class="form-col">
                            <label for="start_date">Start Date</label>
                            <input type="date" id="start_date" name="start_date" value="<?php echo h($filter_start_date); ?>">
                        </div>
                        <div class="form-col">
                            <label for="end_date">End Date</label>
                            <input type="date" id="end_date" name="end_date" value="<?php echo h($filter_end_date); ?>">
                        </div>
                        <div class="form-col">
                            <label for="filter_client_ids">Clients (Optional)</label>
                            <select id="filter_client_ids" name="client_ids[]" multiple="multiple" style="width: 100%;">
                                <?php foreach ($client_options as $client): ?>
                                    <option value="<?php echo h($client['id']); ?>" <?php echo in_array($client['id'], $valid_filter_client_ids) ? 'selected' : ''; ?>>
                                        <?php echo h($client['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                         <div class="form-col" style="flex: 0 0 auto;"> <!-- Prevent button from stretching -->
                            <button type="submit" class="btn btn-primary">Apply Filters</button>
                        </div>
                    </div>
                    <!-- Hidden field for export flag, controlled by JS -->
                    <input type="hidden" name="export" id="export_flag" value="">
                </form>
            </div>
        </div>

         <!-- Report Summary -->
        <?php if (!$export_requested && !$error_message): // Only show summary on HTML view ?>
        <div class="summary-row card-body">
             <div class="summary-item">
                 <span class="summary-value"><?php echo $report_summary['total_count']; ?></span>
                 <span class="summary-label">Total Invoices</span>
             </div>
             <div class="summary-item">
                 <span class="summary-value"><?php echo number_format($report_summary['total_billed_amount'], 2); ?></span>
                 <span class="summary-label">Total Billed (₹)</span>
             </div>
            <div class="summary-item">
                <span class="summary-value" style="color: var(--success);"><?php echo number_format($report_summary['total_collected_amount'], 2); ?></span>
                <span class="summary-label">Total Collected (₹)</span>
            </div>
             <div class="summary-item">
                <span class="summary-value" style="color: var(--danger);"><?php echo number_format($report_summary['total_due_amount'], 2); ?></span>
                <span class="summary-label">Total Due (₹)</span>
            </div>
         </div>
        <?php endif; ?>

        <!-- Results Card -->
        <div class="card">
            <div class="card-header">
                 <h2 class="card-title">Invoice Details</h2>
                <button type="button" id="export-csv-button" class="btn btn-outline btn-sm">
                    <i class="fas fa-file-csv btn-icon"></i>Export CSV
                 </button>
            </div>
            <div class="card-body" style="padding: 0;"> <!-- Remove body padding for full-width table -->
                 <?php if ($error_message): ?>
                    <p style="color: var(--danger); padding: 1rem;"><?php echo $error_message; ?></p>
                 <?php else: ?>
                     <div class="table-responsive">
                         <table class="data-table" id="invoice-list-table">
                            <thead>
                                <tr>
                                    <th>Inv #</th>
                                     <th>Client Name</th>
                                     <th>Inv Date</th>
                                     <th>Due Date</th>
                                     <th class="currency">Total (₹)</th>
                                     <th class="currency">Paid (₹)</th>
                                     <th class="currency">Due (₹)</th>
                                     <th style="text-align:center;">Status</th>
                                    <th>Actions</th>
                                 </tr>
                             </thead>
                            <tbody>
                                <?php if (empty($report_data)): ?>
                                     <tr><td colspan="9" class="empty-table">No invoices found matching the selected criteria.</td></tr>
                                 <?php else: ?>
                                    <?php foreach ($report_data as $invoice): ?>
                                        <?php
                                            $status_val = strtolower(trim($invoice['status'] ?? 'unknown'));
                                             $status_class = 'status-default';
                                             $status_text = 'Unknown';
                                            if ($status_val === 'paid') { $status_class = 'status-paid'; $status_text = 'Paid'; }
                                            elseif ($status_val === 'unpaid') { $status_class = 'status-unpaid'; $status_text = 'Unpaid'; }
                                             elseif ($status_val === 'partially_paid') { $status_class = 'status-partially_paid'; $status_text = 'Partial'; }
                                         ?>
                                        <tr>
                                             <td><?php echo h($invoice['invoice_number']); ?></td>
                                            <td><?php echo h($invoice['client_name'] ?? 'N/A'); ?></td>
                                            <td><?php echo date('d-M-Y', strtotime($invoice['invoice_date'])); ?></td>
                                             <td><?php echo !empty($invoice['due_date']) ? date('d-M-Y', strtotime($invoice['due_date'])) : '-'; ?></td>
                                             <td class="currency"><?php echo number_format((float)$invoice['total_amount'], 2); ?></td>
                                             <td class="currency"><?php echo number_format((float)$invoice['advance_paid'], 2); ?></td>
                                             <td class="currency" style="font-weight:500; <?php if($invoice['amount_due'] > 0) echo 'color:var(--danger);'; ?>"><?php echo number_format((float)$invoice['amount_due'], 2); ?></td>
                                             <td style="text-align:center;"><span class="status-badge <?php echo $status_class; ?>"><?php echo $status_text; ?></span></td>
                                            <td>
                                                 <a href="edit_invoice.php?id=<?php echo $invoice['id']; ?>" class="btn btn-outline btn-sm" title="View/Edit Invoice">
                                                     <i class="fas fa-eye"></i>
                                                 </a>
                                            </td>
                                         </tr>
                                     <?php endforeach; ?>
                                 <?php endif; ?>
                            </tbody>
                         </table>
                    </div>
                 <?php endif; ?>
            </div>
        </div>

    </div> <!-- End Container -->
    <!-- Toast Container - Include if needed/styled -->
    <!-- <div id="toast-container"></div> -->

    <script>
        $(document).ready(function() {
            // Initialize Select2
            $('#filter_client_ids').select2({
                placeholder: "All Clients (Optional)",
                allowClear: true,
                 width: '100%'
            });

             // Export Button Logic
             $('#export-csv-button').on('click', function() {
                // Set the hidden export flag
                $('#export_flag').val('csv');
                // Submit the form normally using GET
                 $('#filter-form').submit();
                // Clear the flag immediately after submission preparation
                $('#export_flag').val('');
             });

            // Reset export flag if regular submit happens
             $('#filter-form').on('submit', function(){
                 // Ensure export flag is clear unless export button was just clicked
                 if ($('#export_flag').val() !== 'csv') {
                     $('#export_flag').val('');
                 }
             });
         });
    </script>
</body>
</html>