<?php
// Include database configuration and start session
require_once 'db_config.php';

// Check if the user is logged in, redirect if not
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}

// Get user information
$user_id = $_SESSION["id"];
$username = $_SESSION["username"];

// Helper function
function h($text) { return htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8'); }

// Retrieve session messages (optional, if needed on this page)
$message = $_SESSION['message'] ?? ''; unset($_SESSION['message']);
$error = $_SESSION['error_message'] ?? ''; unset($_SESSION['error_message']);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Bank Accounts - GST Invoice Generator</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
     <!-- Link FontAwesome if using icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* --- PASTE ALL CSS from index.php / previous bank.php --- */
         :root {
            --primary: #1e40af; --primary-light: #3b82f6; --primary-dark: #1e3a8a;
            --secondary: #64748b; --accent: #f59e0b; --danger: #ef4444; --success: #10b981;
            --warning: #f59e0b; --info: #3b82f6; --light: #f8fafc; --dark: #1e293b;
            --body-bg: #f1f5f9; --card-bg: #ffffff; --border-color: #e2e8f0;
            --text-primary: #334155; --text-secondary: #64748b; --text-muted: #94a3b8;
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            --radius-sm: 0.125rem; --radius: 0.25rem; --radius-md: 0.375rem; --radius-lg: 0.5rem; --radius-xl: 0.75rem;
            --status-paid-bg: #d1fae5; --status-paid-text: #065f46;
            --status-unpaid-bg: #fee2e2; --status-unpaid-text: #991b1b;
            --status-partial-bg: #fef3c7; --status-partial-text: #92400e;
            --status-default-bg: #e5e7eb; --status-default-text: #4b5563;
            --gold: #FFD700; /* Keep gold if used elsewhere, but not needed for default bank star */
         }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Poppins', sans-serif; background-color: var(--body-bg); color: var(--text-primary); line-height: 1.6; font-size: 14px; }
        /* Layout */
        .container { max-width: 1280px; margin: 0 auto; padding: 2rem; }
        .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; padding-bottom: 1rem; border-bottom: 1px solid var(--border-color); }
        .page-title h1 { font-size: 1.75rem; font-weight: 700; color: var(--primary); margin-bottom: 0.25rem; }
        .page-title p { color: var(--text-secondary); font-size: 0.875rem; }
        .user-menu { display: flex; align-items: center; gap: 1rem; }
        .user-name { font-weight: 500; }
        .card { background: var(--card-bg); border-radius: var(--radius-lg); box-shadow: var(--shadow-md); overflow: hidden; margin-bottom: 1.5rem; }
        .card-header { padding: 1rem 1.5rem; border-bottom: 1px solid var(--border-color); background-color: var(--light); display: flex; justify-content: space-between; align-items: center; }
        .card-title { font-size: 1.125rem; font-weight: 600; color: var(--text-primary); }
        .card-body { padding: 1.5rem; }
        /* Forms */
        .form-group { margin-bottom: 1rem; }
        .form-row { display: flex; flex-wrap: wrap; gap: 0.75rem; margin-bottom: 0.75rem; }
        .form-col { flex: 1; min-width: 180px; }
        label { display: block; font-weight: 500; margin-bottom: 0.5rem; color: var(--text-primary); font-size: 0.875rem; }
        input, select, textarea { width: 100%; padding: 0.625rem 0.75rem; border: 1px solid var(--border-color); border-radius: var(--radius); font-family: inherit; font-size: 0.875rem; color: var(--text-primary); background-color: white; transition: border-color 0.2s ease, box-shadow 0.2s ease; }
        input:focus, select:focus, textarea:focus { outline: none; border-color: var(--primary-light); box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.25); }
        input[readonly], input:disabled, select:disabled, textarea:disabled { background-color: var(--light); cursor: not-allowed; color: var(--text-muted); opacity: 0.8;}
        textarea { resize: vertical; min-height: 60px; }
        /* Tables */
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 1rem; }
        table th, table td { padding: 0.75rem; border-bottom: 1px solid var(--border-color); vertical-align: middle; font-size: 0.875rem; line-height: 1.4; }
        table th { text-align: left; font-weight: 600; background-color: var(--light); border-bottom-width: 2px; color: var(--text-primary); white-space: nowrap; }
        table tr:last-child td { border-bottom: none; }
        .empty-table td { text-align: center; padding: 2rem; color: var(--text-secondary); }
        /* Buttons */
        .btn { display: inline-flex; align-items: center; justify-content: center; padding: 0.5rem 1rem; border-radius: var(--radius); font-weight: 500; cursor: pointer; transition: all 0.2s ease; border: 1px solid transparent; font-size: 0.875rem; text-decoration: none; white-space: nowrap; }
        .btn:disabled { background-color: var(--secondary) !important; opacity: 0.7; cursor: not-allowed; color: white !important; }
        .btn-primary { background-color: var(--primary); color: white; } .btn-primary:hover:not(:disabled) { background-color: var(--primary-dark); }
        .btn-success { background-color: var(--success); color: white; } .btn-success:hover:not(:disabled) { background-color: #0d9488; }
        .btn-danger { background-color: var(--danger); color: white; } .btn-danger:hover:not(:disabled) { background-color: #dc2626; }
        .btn-secondary { background-color: var(--secondary); color: white; } .btn-secondary:hover:not(:disabled) { background-color: #475569; }
        .btn-warning { background-color: var(--accent); color: #422006; } .btn-warning:hover:not(:disabled) { background-color: #d97706; } /* Darker Yellow */
        .btn-outline { background-color: transparent; border-color: var(--border-color); color: var(--text-primary); } .btn-outline:hover:not(:disabled) { border-color: var(--primary); color: var(--primary); background-color: rgba(30, 64, 175, 0.05); }
        .btn-sm { padding: 0.25rem 0.625rem; font-size: 0.75rem; }
        .btn-icon { display: inline-block; margin-right: 0.5rem; width: 1em; height: 1em; line-height: 1; }
        .btn-icon-only { padding: 0.375rem; font-size: 1rem; } .btn-icon-only .btn-icon { margin-right: 0; }
        .btn-group { display: inline-flex; gap: 0.25rem; }
        /* Alerts & Modals */
        .alert { padding: 0.75rem 1rem; border-radius: var(--radius); margin-bottom: 1.5rem; display: flex; align-items: center; font-size: 0.875rem; border-left-width: 4px; border-left-style: solid;} .alert-icon { margin-right: 0.75rem; font-size: 1.25rem; line-height: 1;}
        .alert-success { background-color: #f0fdf4; color: #15803d; border-color: var(--success); } .alert-danger { background-color: #fef2f2; color: #b91c1c; border-color: var(--danger); } .alert-warning { background-color: #fffbeb; color: #b45309; border-color: var(--warning); } .alert-info { background-color: #eff6ff; color: #1d4ed8; border-color: var(--info); }
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0, 0, 0, 0.6); backdrop-filter: blur(3px); }
        .modal-content { background-color: #fff; margin: 5% auto; padding: 0; border: 1px solid #ccc; width: 90%; max-width: 700px; border-radius: var(--radius-lg); box-shadow: var(--shadow-lg); animation: fadeInModal 0.3s ease-out; overflow: hidden; }
        .modal-header { padding: 1rem 1.5rem; background-color: var(--primary); color: white; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--border-color); }
        .modal-title { font-weight: 600; font-size: 1.25rem; line-height: 1.2; }
        .modal-close { background: transparent; border: none; color: white; font-size: 1.8rem; font-weight: bold; cursor: pointer; line-height: 1; padding: 0.2rem; opacity: 0.8; } .modal-close:hover { opacity: 1; }
        .modal-body { padding: 1.5rem; max-height: 70vh; overflow-y: auto;}
        .modal-footer { padding: 1rem 1.5rem; background-color: var(--light); border-top: 1px solid var(--border-color); display: flex; justify-content: flex-end; gap: 0.75rem; }
        @keyframes fadeInModal { from { opacity: 0; transform: translateY(-20px); } to { opacity: 1; transform: translateY(0); } }
        /* Toasts */
        #toast-container { position: fixed; top: 1rem; right: 1rem; z-index: 9999; width: 320px; }
        .toast { background-color: white; border-radius: var(--radius); box-shadow: var(--shadow-lg); margin-bottom: 0.75rem; overflow: hidden; border-left: 4px solid var(--dark); animation: slideInRight 0.3s ease-out, fadeOut 0.5s ease-out 4.5s forwards; }
        .toast-header { padding: 0.5rem 1rem; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--border-color); } .toast-title { font-weight: 600; font-size: 0.875rem; } .toast-close { background: transparent; border: none; font-size: 1.25rem; line-height: 1; cursor: pointer; color: var(--text-secondary); opacity: 0.7;} .toast-close:hover { opacity: 1; } .toast-body { padding: 0.75rem 1rem; font-size: 0.875rem;}
        .toast-success { border-left-color: var(--success); } .toast-error { border-left-color: var(--danger); } .toast-warning { border-left-color: var(--warning); } .toast-info { border-left-color: var(--info); }
        @keyframes slideInRight { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        @keyframes fadeOut { from { opacity: 1; } to { opacity: 0; } }
        /* Utilities */
        .mt-2 { margin-top: 0.5rem; } .mb-4 { margin-bottom: 1rem; }
        .text-right { text-align: right; } .text-center { text-align: center; }
        .font-semibold { font-weight: 600; } .text-sm { font-size: 0.875rem; } .text-xs { font-size: 0.75rem; }
        .text-muted { color: var(--text-muted); } .text-danger { color: var(--danger); } .text-primary-dark { color: var(--primary-dark); } .text-success { color: var(--success); }
        /* Specific to bank page */
        /* Default badge styles REMOVED as default is no longer relevant */
        @media (max-width: 768px) { /* Basic Responsive */
            .container { padding: 1rem; } .page-header { flex-direction: column; align-items: flex-start; gap: 0.5rem;} .user-menu { width: 100%; justify-content: flex-end; } .form-col { flex-basis: 100%; } .modal-content { width: 95%; margin: 5% auto;} #toast-container { width: 90%; right: 5%; left: 5%; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="page-header">
            <div class="page-title">
                <h1>Manage Bank Accounts</h1>
                <p>Add, edit, or remove bank accounts to select on invoices</p>
            </div>
            <div class="user-menu">
                 <a href="index.php" class="btn btn-outline btn-sm"><i class="fas fa-arrow-left btn-icon"></i> Dashboard</a>
                <span class="user-name" style="margin-left: 1rem;">User: <?php echo h($username); ?></span>
                <a href="logout.php" class="btn btn-outline btn-sm">Sign Out</a>
            </div>
        </div>

         <!-- Display any session messages -->
        <?php if (!empty($message)): ?> <div class="alert alert-success"><div class="alert-icon">✓</div><div><?php echo h($message); ?></div></div> <?php endif; ?>
        <?php if (!empty($error)): ?> <div class="alert alert-danger"><div class="alert-icon">✗</div><div><?php echo h($error); ?></div></div> <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <h2 class="card-title">Your Bank Accounts</h2>
                 <button type="button" class="btn btn-primary btn-sm" onclick="openBankModal()">
                     <i class="fas fa-plus btn-icon"></i> Add New Bank
                 </button>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="banks-table">
                        <thead>
                            <tr>
                                <!-- REMOVED Default Column Header -->
                                <th>Bank Name</th>
                                <th>Account Holder</th>
                                <th>Account Number</th>
                                <th>IFSC Code</th>
                                <th>Branch / UPI</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="banks-table-body">
                            <!-- Bank rows will be loaded here by JavaScript -->
                            <tr><td colspan="6" class="empty-table">Loading bank accounts...</td></tr> <!-- Updated colspan -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div> <!-- End Container -->

    <!-- Bank Account Add/Edit Modal -->
    <div id="bank-modal" class="modal">
        <div class="modal-content">
             <form id="bank-form" onsubmit="return false;">
                 <div class="modal-header"> <h2 class="modal-title" id="bank-modal-title">Add New Bank Account</h2> <button type="button" class="modal-close" onclick="closeBankModal()" aria-label="Close">×</button> </div>
                 <div class="modal-body">
                    <input type="hidden" id="bank_form_id" name="id" value="">
                    <div class="form-group"> <label for="bank_name">Bank Name <span class="text-danger">*</span></label> <input type="text" id="bank_name" name="bank_name" required> </div>
                    <div class="form-group"> <label for="account_holder_name">Account Holder Name</label> <input type="text" id="account_holder_name" name="account_holder_name" placeholder="(Optional)"> </div>
                    <div class="form-row"> <div class="form-col"> <label for="account_number">Account Number <span class="text-danger">*</span></label> <input type="text" id="account_number" name="account_number" required> </div> <div class="form-col"> <label for="ifsc_code">IFSC Code <span class="text-danger">*</span></label> <input type="text" id="ifsc_code" name="ifsc_code" required> </div> </div>
                    <div class="form-row"> <div class="form-col"> <label for="branch_name">Branch Name</label> <input type="text" id="branch_name" name="branch_name" placeholder="(Optional)"> </div> <div class="form-col"> <label for="upi_id">UPI ID</label> <input type="text" id="upi_id" name="upi_id" placeholder="(Optional)"> </div> </div>
                 </div>
                 <div class="modal-footer"> <button type="button" class="btn btn-outline" onclick="closeBankModal()">Cancel</button> <button type="button" class="btn btn-primary" id="save-bank-btn" onclick="saveBank(this)">Save Bank Account</button> </div>
             </form>
        </div>
    </div>

     <!-- Toast Container -->
    <div id="toast-container"></div>

     <script>
        // --- Elements Cache ---
        const bankModal = document.getElementById('bank-modal');
        const banksTableBody = document.getElementById('banks-table-body');
        const toastContainer = document.getElementById('toast-container');

        // --- Utility Functions ---
        function openModal(modalEl) { if (modalEl) modalEl.style.display = 'block'; }
        function closeModal(modalEl) { if (modalEl) modalEl.style.display = 'none'; }
        function escapeHtml(unsafe) { /* ... copy from index.php ... */ if(typeof unsafe !== 'string') return unsafe??''; const map={'&':'&','<':'<','>':'>','"':'"',"'":'&#039'}; return unsafe.replace(/[&<>"']/g, m => map[m]); }
        function showToast(title, message, type = 'info') { /* ... copy from index.php ... */ const t = document.createElement('div'); t.className=`toast toast-${type}`; let i = type==='success'?'✓':(type==='error'?'✗':(type==='warning'?'⚠️':'ℹ️')); t.innerHTML=`<div class="toast-header"><span class="toast-title">${i} ${escapeHtml(title)}</span><button type="button" class="toast-close" onclick="this.parentElement.parentElement.remove()">×</button></div><div class="toast-body">${escapeHtml(message)}</div>`; if(toastContainer)toastContainer.appendChild(t); document.querySelector('.alert-success')?.remove(); document.querySelector('.alert-danger')?.remove(); }

        // --- Bank Modal Control ---
        function openBankModal(bank = null) { /* ... unchanged ... */ const form = document.getElementById('bank-form'); if(!form) return; form.reset(); document.getElementById('bank_form_id').value=''; document.getElementById('bank-modal-title').textContent = 'Add New Bank Account'; if(bank && bank.id){ document.getElementById('bank-modal-title').textContent = 'Edit Bank Account'; document.getElementById('bank_form_id').value=bank.id; document.getElementById('bank_name').value=bank.bank_name||''; document.getElementById('account_holder_name').value=bank.account_holder_name||''; document.getElementById('account_number').value=bank.account_number||''; document.getElementById('ifsc_code').value=bank.ifsc_code||''; document.getElementById('branch_name').value=bank.branch_name||''; document.getElementById('upi_id').value=bank.upi_id||''; } openModal(bankModal); document.getElementById('bank_name')?.focus(); }
        function closeBankModal() { closeModal(bankModal); }
        window.addEventListener('click', (event) => { if (event.target === bankModal) { closeBankModal(); } });

        // --- Bank API Interactions ---
        function loadBanks() { /* ... unchanged ... */ if(!banksTableBody) return; banksTableBody.innerHTML='<tr><td colspan="6" class="empty-table">Loading bank accounts...</td></tr>'; fetch('api.php?action=get_banks').then(response => response.json()).then(data => { banksTableBody.innerHTML=''; if(data.success && data.banks?.length > 0) { renderBankTable(data.banks); } else if(data.success) { banksTableBody.innerHTML='<tr><td colspan="6" class="empty-table">No bank accounts added yet.</td></tr>'; } else { showToast('Error', data.message || 'Failed to load bank accounts.', 'error'); banksTableBody.innerHTML='<tr><td colspan="6" class="empty-table text-danger">Error loading accounts.</td></tr>'; } }).catch(error => { console.error('Error fetching banks:', error); showToast('Error', 'Network error loading bank accounts.', 'error'); banksTableBody.innerHTML='<tr><td colspan="6" class="empty-table text-danger">Network error.</td></tr>'; }); }

        // MODIFIED: renderBankTable - Removed Default logic/column
        function renderBankTable(banks) {
            if (!banksTableBody) return;
            banksTableBody.innerHTML = ''; // Clear previous content

             banks.forEach(bank => {
                 const row = banksTableBody.insertRow();
                 // REMOVED isDefault and defaultStar variables/logic

                 let branchUpi = escapeHtml(bank.branch_name || '');
                 if(bank.upi_id){ branchUpi += (branchUpi ? '<br>' : '') + `UPI: ${escapeHtml(bank.upi_id)}`; }
                 branchUpi = branchUpi || '-';

                 // REMOVED First TD (the star icon)
                row.innerHTML = `
                    <td>${escapeHtml(bank.bank_name)}</td>
                     <td>${escapeHtml(bank.account_holder_name || '-')}</td>
                    <td>${escapeHtml(bank.account_number)}</td>
                     <td>${escapeHtml(bank.ifsc_code)}</td>
                    <td class="text-xs">${branchUpi}</td>
                     <td class="text-center">
                         <div class="btn-group">
                             <button type="button" class="btn btn-outline btn-sm" title="Edit Account" onclick='openBankModal(${JSON.stringify(bank)})'><i class="fas fa-edit"></i> Edit</button>
                             <!-- REMOVED Set Default Button -->
                             <button type="button" class="btn btn-danger btn-sm" title="Delete Account" onclick="deleteBank(${bank.id}, this)"><i class="fas fa-trash"></i> Delete</button>
                         </div>
                     </td>
                 `;
             });
         }

        function saveBank(button) { /* ... unchanged from original saveBank logic... */ const form=document.getElementById('bank-form');if(!form||!form.checkValidity()){showToast('Warning','Please fill all required fields.','warning');form.reportValidity();return;}const formData=new FormData(form);formData.append('action','save_bank');const originalButtonText=button.textContent;button.disabled=true;button.textContent='Saving...';fetch('api.php',{method:'POST',body:formData}).then(r=>r.json()).then(d=>{if(d.success){showToast('Success',d.message,'success');closeBankModal();loadBanks();}else{showToast('Error',d.message||'Failed to save bank account.','error');}}).catch(e=>{console.error('Error saving bank:',e);showToast('Error','Network error saving bank account.','error');}).finally(()=>{button.disabled=false;button.textContent=originalButtonText;}); }
        function deleteBank(bankId, button) { /* ... unchanged from original deleteBank logic ... */ if (!confirm('Are you sure you want to delete this bank account? This cannot be undone.')){return;}const originalButtonHTML = button.innerHTML; button.disabled=true;button.textContent='...'; fetch(`api.php?action=delete_bank&id=${bankId}`).then(r=>r.json()).then(d=>{if(d.success){showToast('Success',d.message,'success');loadBanks();}else{showToast('Error',d.message||'Failed to delete bank account.','error');button.disabled=false;button.innerHTML=originalButtonHTML;}}).catch(e=>{console.error('Error deleting bank:',e);showToast('Error','Network error deleting bank account.','error');button.disabled=false;button.innerHTML=originalButtonHTML;}); }

        // --- DELETED setDefaultBank JavaScript function ---

        // --- Initial Load ---
         document.addEventListener('DOMContentLoaded', function() {
             loadBanks(); // Load bank accounts when the page is ready
             setTimeout(() => { document.querySelector('.alert-success')?.remove(); document.querySelector('.alert-danger')?.remove(); }, 7000); // Remove PHP flash messages
         });
     </script>
</body>
</html>