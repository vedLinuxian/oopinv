<?php
// Database configuration
$db_host = "localhost";      // Database host (Keep your actual value)
$db_user = "tysohusz_as";  // Database username (Keep your actual value)
$db_pass = "VedDev@101";  // Database password (Keep your actual value)
$db_name = "tysohusz_as";    // Database name (Keep your actual value)

// Connect to MySQL database
$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

// Check connection
if (!$conn) {
    // Log the error for debugging purposes. Avoid echoing sensitive info on live site.
    error_log("Database Connection Failed: " . mysqli_connect_error());
    // For critical pages or non-AJAX, you might want to stop execution.
    // For AJAX (often hitting index.php's handler now), functions should check query results.
    // You could have a global flag or check script name if needed for different behavior.
    die("Database connection error. Please check logs or contact support."); // Or a more user-friendly message
}

// Set character set to UTF-8
if ($conn) { // Only if connection succeeded
    if (!mysqli_set_charset($conn, "utf8mb4")) {
         error_log("Error loading character set utf8mb4: " . mysqli_error($conn));
    }
}

// Function to sanitize input (Handles arrays recursively)
function sanitize($conn, $input) {
    // If connection failed earlier, we can't sanitize, return raw input
    if (!$conn || mysqli_connect_errno()) return $input;

    if (is_array($input)) {
        $sanitized = [];
        foreach ($input as $key => $value) {
            // Sanitize both key and value if needed, but usually only value
            $sanitized[sanitize($conn, $key)] = sanitize($conn, $value);
        }
        return $sanitized;
    } elseif (is_string($input)) {
         // Trim, remove potential null bytes, basic HTML entity encoding, then escape for SQL
         $input = trim($input);
         $input = str_replace("\0", '', $input); // Remove null bytes
         $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
        return mysqli_real_escape_string($conn, $input);
    } elseif ($input === null) {
        return null; // Allow nulls through
    } elseif (is_int($input) || is_float($input) || is_bool($input)) {
        // Return numeric types and booleans directly - crucial for the query function fix
        return $input;
    } else {
         // For other types, attempt conversion to string and sanitize
         // This might be less safe - consider if you expect other types
        return mysqli_real_escape_string($conn, trim(htmlspecialchars((string)$input, ENT_QUOTES, 'UTF-8')));
    }
}

// Function to validate and sanitize email
function sanitize_email($email) {
    $email = filter_var(trim($email), FILTER_SANITIZE_EMAIL);
    // Return the sanitized email if it's a valid format, otherwise return null
     return filter_var($email, FILTER_VALIDATE_EMAIL) ? $email : null;
}


// ***** CORRECTED QUERY FUNCTION with Numeric Handling *****
function query($conn, $sql, $params = []) {
    if (!$conn || mysqli_connect_errno()) { // Check connection health again
        error_log("[db_config] Query attempted without a healthy database connection.");
        return false;
    }

    $sql_prepared = $sql; // Start with the template

    if (!empty($params)) {

        // Order parameters by key length descending to avoid partial replacements
        uksort($params, function ($a, $b) {
            return strlen($b) - strlen($a); // Sort longer keys first
        });

        $search = [];
        $replace = [];
        $replacements_log = []; // For debugging

        foreach ($params as $key => $value) {
            $placeholder = ":" . $key; // Corrected placeholder format

            // Ensure placeholder actually exists in the SQL to avoid unnecessary processing
            if (strpos($sql_prepared, $placeholder) === false) {
                 // Optional: Log if a provided param doesn't have a placeholder
                 // error_log("[db_config] Warning: Parameter '{$key}' provided but placeholder '{$placeholder}' not found in SQL: " . $sql);
                continue; // Skip this parameter if placeholder isn't found
            }

            $search[] = $placeholder;

            // Sanitize first - IMPORTANT: sanitize() MUST return original type for numbers/null
            $sanitized_value = sanitize($conn, $value);

            // Determine SQL replacement string ('value', NULL, number etc.)
            if ($sanitized_value === null) {
                $replacement = "NULL";
            } elseif (is_int($sanitized_value) || is_float($sanitized_value)) {
                // It's a number - use it directly without quotes
                $replacement = $sanitized_value;
            } elseif (is_bool($sanitized_value)) {
                 // Convert boolean to 1 or 0 for SQL
                 $replacement = $sanitized_value ? 1 : 0;
            } else {
                // It's a string (assume sanitize handled escaping), wrap in single quotes
                // $sanitized_value should already be escaped by sanitize()
                $replacement = "'" . $sanitized_value . "'";
            }
            $replace[] = $replacement;
            $replacements_log[$placeholder] = $replacement; // Log mapping
        }

        // Log planned replacements (useful for debugging)
        // error_log("[db_config] SQL Template: " . $sql);
        // error_log("[db_config] Parameters Array (Ordered): " . print_r($params, true));
        // error_log("[db_config] Planned Replacements: " . print_r($replacements_log, true));

        // Perform all replacements using the ordered search/replace arrays
        $sql_prepared = str_replace($search, $replace, $sql_prepared);

        // Check for unreplaced placeholders after replacement (more robust check)
        if (preg_match('/:([a-zA-Z0-9_]+)/', $sql_prepared, $matches)) {
             error_log("!!! CRITICAL WARNING: Unreplaced placeholder ':" . ($matches[1] ?? 'UNKNOWN') . "' detected in FINAL SQL !!!");
             error_log("[db_config Post-Replace Check] SQL Template: " . $sql);
             error_log("[db_config Post-Replace Check] Original Params Array: " . print_r($params, true));
             // Optionally return false or throw exception here to prevent execution
             // return false;
        }
    }

    // Log the final SQL before execution - VERY IMPORTANT FOR DEBUGGING
    // Consider commenting this out on a production server if logs become too large,
    // but leave it active during development/debugging.
    // --- DEBUG LINE - REMOVE OR COMMENT OUT IN PRODUCTION ---
    // error_log("[FINAL SQL to Execute]: " . $sql_prepared);
    // --- END DEBUG LINE ---

    $result = mysqli_query($conn, $sql_prepared); // Execute the query

    if (!$result) {
        // Log the error *and* the exact SQL that caused it
        $error_message = "SQL Error [" . mysqli_errno($conn) . "]: " . mysqli_error($conn);
        error_log($error_message); // Log error message first
        error_log("Failed SQL: " . $sql_prepared); // Log the failed SQL
        // Optionally, re-throw the exception to be caught higher up if needed
        // throw new mysqli_sql_exception($error_message, mysqli_errno($conn));
    }
    return $result;
}
// ***** END CORRECTED QUERY FUNCTION *****


// Function to get multiple rows from a result set
function fetch_all($result) {
    $rows = [];
    // Check if $result is a valid mysqli_result object and has rows
    if ($result instanceof mysqli_result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $rows[] = $row;
        }
    }
    return $rows;
}

// Function to get a single row from a result set
function fetch_one($result) {
    // Check if $result is a valid mysqli_result object and has rows
    if ($result instanceof mysqli_result && mysqli_num_rows($result) > 0) {
        return mysqli_fetch_assoc($result);
    }
    return null; // Return null if no row found or result invalid
}

// Function to count the rows in a result set
function fetch_count($conn, $result) { // conn is technically not needed here but kept for consistency
     // Check if $result is a valid mysqli_result object
     if ($result instanceof mysqli_result) {
        return mysqli_num_rows($result);
    }
     // Log if result is invalid?
     // error_log("[db_config] fetch_count called with invalid result object.");
     return 0; // Return 0 if result is invalid
}

// Function to get the last inserted ID
function last_id($conn) {
    if ($conn && !mysqli_connect_errno()) {
        return mysqli_insert_id($conn);
    }
    return 0; // Return 0 if connection invalid or no insert ID
}

// Function to begin a transaction
function begin_transaction($conn) {
     if ($conn && !mysqli_connect_errno()) {
         return mysqli_begin_transaction($conn);
     }
     return false;
}

// Function to commit a transaction
function commit_transaction($conn) {
     if ($conn && !mysqli_connect_errno()) {
         return mysqli_commit($conn);
     }
     return false;
}

// Function to rollback a transaction
function rollback_transaction($conn) {
    if ($conn && !mysqli_connect_errno()) {
        return mysqli_rollback($conn);
    }
    return false;
}

// Function to close database connection (optional, PHP usually handles this)
function close_connection($conn) {
     if ($conn && !mysqli_connect_errno()) {
         mysqli_close($conn);
     }
}

// Initialize session if not already started
// This ensures $_SESSION is available in all including files.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

?>
