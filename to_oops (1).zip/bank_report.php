<?php
// Include database configuration and start session
require_once 'db_config.php';

// Check if the user is logged in
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}

// Get user information
$user_id = $_SESSION["id"];
$username = $_SESSION["username"];

// --- Helper Functions ---
function h($text) { return htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8'); }
function validateDate($date, $format = 'Y-m-d') { $d = DateTime::createFromFormat($format, $date); return $d && $d->format($format) === $date; }

// --- Initial Data Fetching ---

// Fetch all bank accounts for the filter dropdown
$banks_list = [];
$sql_banks = "SELECT id, bank_name, account_number FROM user_banks WHERE user_id = :user_id ORDER BY bank_name ASC";
$banks_result = query($conn, $sql_banks, ['user_id' => $user_id]);
if ($banks_result) {
    $banks_list = fetch_all($banks_result);
}

// --- Report Generation Logic ---
$report_data = [];
$report_totals = [];
$bank_details = null;
$form_submitted = false;

// Check if the form has been submitted to generate a report
if (isset($_GET['start_date']) && isset($_GET['end_date']) && isset($_GET['bank_id'])) {
    $form_submitted = true;

    // Sanitize and validate inputs from GET request
    $bank_id = (int)$_GET['bank_id'];
    $start_date = validateDate($_GET['start_date']) ? $_GET['start_date'] : null;
    $end_date = validateDate($_GET['end_date']) ? $_GET['end_date'] : null;

    if ($bank_id && $start_date && $end_date) {
        // First, verify the user owns the selected bank to prevent unauthorized access
        $sql_verify_bank = "SELECT id, bank_name, account_number FROM user_banks WHERE id = :id AND user_id = :user_id";
        $bank_verify_result = query($conn, $sql_verify_bank, ['id' => $bank_id, 'user_id' => $user_id]);
        
        if ($bank_verify_result && fetch_count($conn, $bank_verify_result) > 0) {
            $bank_details = fetch_one($bank_verify_result);
            
            // --- Build and Execute the Main Report Query ---
            $sql_report = "SELECT i.id, i.invoice_number, i.invoice_date, i.total_amount, i.advance_paid, i.status, c.name as client_name,
                           GREATEST(0, i.total_amount - i.advance_paid) as amount_due
                           FROM invoices i
                           LEFT JOIN clients c ON i.client_id = c.id
                           WHERE i.user_id = :user_id
                             AND i.bank_account_id = :bank_id
                             AND i.invoice_date BETWEEN :start_date AND :end_date
                           ORDER BY i.invoice_date DESC, i.id DESC";
            
            $params = ['user_id' => $user_id, 'bank_id' => $bank_id, 'start_date' => $start_date, 'end_date' => $end_date];
            $report_result = query($conn, $sql_report, $params);
            $report_data = $report_result ? fetch_all($report_result) : [];

            // --- Server-Side Calculation of Totals ---
            $totals = ['total_billed' => 0, 'total_collected' => 0, 'total_due' => 0, 'count_paid' => 0, 'count_unpaid' => 0, 'count_partial' => 0, 'count_total' => 0];
            foreach($report_data as $invoice) {
                $totals['total_billed'] += (float)$invoice['total_amount'];
                $totals['total_collected'] += (float)$invoice['advance_paid'];
                $totals['total_due'] += (float)$invoice['amount_due'];
                if ($invoice['status'] === 'paid') $totals['count_paid']++;
                elseif ($invoice['status'] === 'unpaid') $totals['count_unpaid']++;
                elseif ($invoice['status'] === 'partially_paid') $totals['count_partial']++;
                $totals['count_total']++;
            }
            $report_totals = $totals;

            // --- Handle CSV Export Request ---
            if (isset($_GET['export']) && $_GET['export'] === 'csv') {
                $filename = "Bank_Report_" . str_replace(' ', '_', $bank_details['bank_name']) . "_" . $start_date . "_to_" . $end_date . ".csv";
                header('Content-Type: text/csv; charset=utf-8');
                header('Content-Disposition: attachment; filename="' . $filename . '"');
                $output = fopen('php://output', 'w');
                
                fputcsv($output, ['Invoice #', 'Date', 'Client', 'Total Amount', 'Collected Amount', 'Due Amount', 'Status']);
                
                foreach ($report_data as $invoice) {
                    fputcsv($output, [$invoice['invoice_number'], $invoice['invoice_date'], $invoice['client_name'], number_format((float)$invoice['total_amount'], 2), number_format((float)$invoice['advance_paid'], 2), number_format((float)$invoice['amount_due'], 2), ucfirst(str_replace('_', ' ', $invoice['status']))]);
                }
                
                fputcsv($output, []);
                fputcsv($output, ['Total Invoices:', $report_totals['count_total']]);
                fputcsv($output, ['Total Billed:', number_format($report_totals['total_billed'], 2)]);
                fputcsv($output, ['Total Collected:', number_format($report_totals['total_collected'], 2)]);

                fclose($output);
                exit; // Stop script execution after generating the file
            }
        } else {
            // Handle case where user tries to access a bank ID they don't own
            $error_message = "Error: Access to the selected bank account is denied.";
        }
    } else {
        $error_message = "Error: Invalid or missing filters. Please select a bank and a valid date range.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bank Transaction Report - GST Invoice Generator</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root{--primary:#1e40af;--primary-light:#3b82f6;--primary-dark:#1e3a8a;--secondary:#64748b;--danger:#ef4444;--success:#10b981;--light:#f8fafc;--body-bg:#f1f5f9;--card-bg:#ffffff;--border-color:#e2e8f0;--text-primary:#334155;--text-secondary:#64748b;--text-muted:#94a3b8;--shadow:0 1px 3px 0 rgba(0,0,0,0.1),0 1px 2px 0 rgba(0,0,0,0.06);--radius-lg:0.5rem;--status-paid-bg:#d1fae5;--status-paid-text:#065f46;--status-unpaid-bg:#fee2e2;--status-unpaid-text:#991b1b;--status-partial-bg:#fef3c7;--status-partial-text:#92400e;}
        *{margin:0;padding:0;box-sizing:border-box}
        body{font-family:'Poppins',sans-serif;background-color:var(--body-bg);color:var(--text-primary);font-size:14px;line-height:1.6}
        .container{max-width:1400px;margin:1.5rem auto;padding:0 1.5rem}
        .page-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;padding-bottom:1rem;border-bottom:1px solid var(--border-color)}
        .page-title h1{font-size:1.5rem;font-weight:600;color:var(--primary)}
        .card{background:var(--card-bg);border-radius:var(--radius-lg);box-shadow:var(--shadow);margin-bottom:1.5rem}
        .card-header{padding:.8rem 1.25rem;border-bottom:1px solid var(--border-color);display:flex;justify-content:space-between;align-items:center}
        .card-title{font-size:1rem;font-weight:600}
        .card-body{padding:1.25rem}
        .form-row{display:flex;flex-wrap:wrap;gap:1rem;align-items:flex-end}
        .form-col{flex:1 1 200px}
        label{display:block;font-weight:500;margin-bottom:.4rem;font-size:.8rem}
        input,select{width:100%;padding:.6rem .75rem;border:1px solid var(--border-color);border-radius:.25rem;font-size:.875rem}
        .btn{display:inline-flex;align-items:center;justify-content:center;padding:.6rem 1rem;border-radius:.25rem;font-weight:500;cursor:pointer;border:1px solid transparent;font-size:.875rem;text-decoration:none}
        .btn-primary{background-color:var(--primary);color:white} .btn-primary:hover{background-color:var(--primary-dark)}
        .btn-outline{border-color:var(--border-color);color:var(--text-primary)} .btn-outline:hover{border-color:var(--primary);color:var(--primary)}
        .btn-sm{padding:.3rem .7rem;font-size:.75rem}
        .btn-icon{margin-right:.4rem}
        .btn:disabled{opacity:.6;cursor:not-allowed}
        .summary-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:1rem;background-color:var(--light);padding:1rem;border:1px solid var(--border-color);border-radius:.5rem;margin-bottom:1.5rem}
        .summary-item{text-align:center;padding:.5rem}
        .summary-value{font-size:1.5rem;font-weight:600;display:block}
        .summary-label{font-size:.75rem;color:var(--text-secondary);text-transform:uppercase}
        .table-responsive{overflow-x:auto}
        .data-table{width:100%;border-collapse:collapse}
        .data-table th,.data-table td{padding:.6rem .8rem;border-bottom:1px solid var(--border-color);text-align:left;font-size:.85rem}
        .data-table thead th{background-color:var(--light);font-weight:600;white-space:nowrap}
        .currency{text-align:right} .centered{text-align:center}
        .status-badge{padding:.3em .7em;font-size:.7rem;font-weight:600;border-radius:.25rem;text-transform:uppercase}
        .status-paid{background-color:var(--status-paid-bg);color:var(--status-paid-text)}
        .status-unpaid{background-color:var(--status-unpaid-bg);color:var(--status-unpaid-text)}
        .status-partially_paid{background-color:var(--status-partial-bg);color:var(--status-partial-text)}
        .alert-danger{background-color:#fee2e2;color:#991b1b;padding:1rem;border-left:4px solid var(--danger);margin-bottom:1.5rem;border-radius:.25rem}
    </style>
</head>
<body>
    <div class="container">
        <div class="page-header">
            <div class="page-title"><h1>Bank Transaction Report</h1></div>
            <a href="index.php" class="btn btn-outline btn-sm"><i class="fas fa-arrow-left btn-icon"></i>Back to Dashboard</a>
        </div>
        
        <div class="card">
            <div class="card-header"><h2 class="card-title">Report Filters</h2></div>
            <div class="card-body">
                <form id="bank-report-form" method="GET" action="bank_report.php">
                    <div class="form-row">
                        <div class="form-col">
                            <label for="bank_id">Select Bank Account</label>
                            <select id="bank_id" name="bank_id" required>
                                <option value="">-- Please select a bank --</option>
                                <?php foreach($banks_list as $bank): ?>
                                    <option value="<?php echo h($bank['id']); ?>" <?php if ($form_submitted && $bank_id == $bank['id']) echo 'selected'; ?>>
                                        <?php echo h($bank['bank_name']) . ' (...' . substr($bank['account_number'], -4) . ')'; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-col">
                            <label for="start_date">Start Date</label>
                            <input type="date" id="start_date" name="start_date" value="<?php echo h($_GET['start_date'] ?? date('Y-m-01')); ?>" required>
                        </div>
                        <div class="form-col">
                            <label for="end_date">End Date</label>
                            <input type="date" id="end_date" name="end_date" value="<?php echo h($_GET['end_date'] ?? date('Y-m-d')); ?>" required>
                        </div>
                        <div class="form-col">
                            <label>&nbsp;</label>
                            <button type="submit" class="btn btn-primary" style="width: 100%;">Generate Report</button>
                        </div>
                        <div class="form-col">
                            <label>&nbsp;</label>
                            <button type="submit" name="export" value="csv" class="btn btn-outline" style="width: 100%;" <?php echo !$form_submitted || empty($report_data) ? 'disabled' : ''; ?>>
                                <i class="fas fa-file-csv btn-icon"></i>Export CSV
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <?php if ($form_submitted): ?>
            <?php if (isset($error_message)): ?>
                <div class="alert-danger"><?php echo h($error_message); ?></div>
            <?php elseif ($bank_details): ?>
                <div class="card">
                    <div class="card-header"><h2 class="card-title">Report for: <?php echo h($bank_details['bank_name']); ?></h2></div>
                    <div class="card-body">
                        <div class="summary-grid">
                            <div class="summary-item"><span class="summary-value">₹<?php echo number_format($report_totals['total_billed'], 2); ?></span><span class="summary-label">Total Billed</span></div>
                            <div class="summary-item"><span class="summary-value">₹<?php echo number_format($report_totals['total_collected'], 2); ?></span><span class="summary-label">Total Collected</span></div>
                            <div class="summary-item"><span class="summary-value">₹<?php echo number_format($report_totals['total_due'], 2); ?></span><span class="summary-label">Total Due</span></div>
                            <div class="summary-item"><span class="summary-value"><?php echo $report_totals['count_total']; ?></span><span class="summary-label">Total Invoices</span></div>
                        </div>

                        <div class="table-responsive">
                            <table class="data-table">
                                <thead><tr><th>Invoice #</th><th>Date</th><th>Client</th><th class="currency">Billed (₹)</th><th class="currency">Collected (₹)</th><th class="currency">Due (₹)</th><th class="centered">Status</th></tr></thead>
                                <tbody>
                                    <?php if (!empty($report_data)): ?>
                                        <?php foreach ($report_data as $invoice): ?>
                                            <tr>
                                                <td><a href="edit_invoice.php?id=<?php echo $invoice['id']; ?>" title="View Invoice"><?php echo h($invoice['invoice_number']); ?></a></td>
                                                <td><?php echo h(date('d-m-Y', strtotime($invoice['invoice_date']))); ?></td>
                                                <td><?php echo h($invoice['client_name']); ?></td>
                                                <td class="currency"><?php echo number_format((float)$invoice['total_amount'], 2); ?></td>
                                                <td class="currency"><?php echo number_format((float)$invoice['advance_paid'], 2); ?></td>
                                                <td class="currency"><?php echo number_format((float)$invoice['amount_due'], 2); ?></td>
                                                <td class="centered"><span class="status-badge status-<?php echo h($invoice['status']); ?>"><?php echo h(str_replace('_', ' ', $invoice['status'])); ?></span></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr><td colspan="7" style="text-align: center; padding: 2rem;">No invoices found for this bank in the selected date range.</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</body>
</html>